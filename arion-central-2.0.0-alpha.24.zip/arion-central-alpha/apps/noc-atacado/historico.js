/* historico.js — Histórico (lupa da Categorização).
 * Busca no OTRS: chamados antigos, links de internet e operadoras. Só LEITURA (GET).
 * Lógica da extensão "ARION Histórico OTRS" v0.2, com o visual da Central.
 * Cache local (IndexedDB): chamados 30 min, ICs 24 h. Senha/PPPoE nunca são salvos.
 */
(() => {
  'use strict';
  const BASE = 'https://suporte.grupoarion.com.br/otrs/index.pl';
  const CLASSE = { links: 131, operadoras: 132 };
  const CAMPO_SENSIVEL = /senha|password|ppoe/i;
  const CAMPOS_LINK = ['Designação ARION', 'Designação da Operadora', 'Circuito', 'ISP', 'Cliente', 'Endereço', 'Cidade', 'Estado', 'Velocidade', 'Tipo', 'Equipamento'];
  const OCULTAR_OPERADORA = /^(Nome|Estado de Implantação|Estado de Incidente)$/i;
  const COLUNAS_RUIDO = /^(Prioridade|Novo Artigo|Bloquear)$/i;
  const MAX_CIS = 5;
  const TTL = { tickets: 30 * 60e3, ic: 24 * 3600e3 };
  const ICONE_COPIAR =
    '<svg class="i-cp" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1"/></svg>' +
    '<svg class="i-ok" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg>';

  const txt = el => (el?.textContent || '').replace(/\s+/g, ' ').trim();
  const norm = s => (s || '').toString().normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();
  const esc = s => (s ?? '').toString().replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const urlCI = id => `${BASE}?Action=AgentITSMConfigItemZoom;ConfigItemID=${id}`;
  const urlTicket = id => `${BASE}?Action=AgentTicketZoom;TicketID=${id}`;
  const aviso = (m, erro) => { try { window.__noc.toast(m, erro); } catch (_) {} };

  // ---------- Cache (IndexedDB, formado pelo uso) ----------
  let dbP;
  const db = () => dbP ||= new Promise((ok, err) => {
    const r = indexedDB.open('arion-historico-v2', 1);
    r.onupgradeneeded = () => r.result.createObjectStore('cache', { keyPath: 'k' });
    r.onsuccess = () => ok(r.result);
    r.onerror = () => err(r.error);
  });
  const req = r => new Promise((ok, err) => { r.onsuccess = () => ok(r.result); r.onerror = () => err(r.error); });
  const os = async m => (await db()).transaction('cache', m).objectStore('cache');
  async function cacheGet(k, ttl) {
    try { const v = await req((await os('readonly')).get(k)); return v && Date.now() - v.em < ttl ? v.dados : null; } catch { return null; }
  }
  async function cachePut(k, dados) { try { await req((await os('readwrite')).put({ k, dados, em: Date.now() })); } catch {} }
  async function cacheLimpar() { await req((await os('readwrite')).clear()); }

  // ---------- Acesso ao OTRS (GET, com a sessão do navegador) ----------
  class SessaoExpirada extends Error {}
  async function pagina(params, signal) {
    const qs = Object.entries(params).map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join(';');
    const res = await fetch(`${BASE}?${qs}`, { method: 'GET', credentials: 'include', signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const doc = new DOMParser().parseFromString(await res.text(), 'text/html');
    if (doc.querySelector('#LoginBox, input[name="Password"]')) throw new SessaoExpirada('Sessão expirada. Faça login no OTRS.');
    return { doc, url: res.url };
  }

  // ---------- Chamados ----------
  const PERIODO = {
    '30d': { TimeSearchType: 'TimePoint', TicketCreateTimePointStart: 'Last', TicketCreateTimePoint: 30, TicketCreateTimePointFormat: 'day' },
    '12m': { TimeSearchType: 'TimePoint', TicketCreateTimePointStart: 'Last', TicketCreateTimePoint: 12, TicketCreateTimePointFormat: 'month' },
    'tudo': {}
  };

  function campoZoom(doc, nome) {
    const l = [...doc.querySelectorAll('label')].find(x => txt(x).replace(/:$/, '') === nome);
    return l ? txt(l.nextElementSibling) : '';
  }

  function lerChamados(doc, url) {
    if (/AgentTicketZoom/.test(url) || /Detalhes - Chamado/.test(doc.title)) {
      const num = (doc.title.match(/^(\d{6,})/) || [])[1] || '';
      const a = doc.querySelector('a[href*="TicketID="]');
      const id = doc.querySelector('input[name="TicketID"]')?.value || (a && (a.getAttribute('href').match(/TicketID=(\d+)/) || [])[1]) || '';
      return {
        colunas: ['Ticket#', 'Título', 'Estado', 'Fila', 'Criado'],
        linhas: [{ id, valores: [num, txt(doc.querySelector('.Headline h1, h1')).replace(/^Ticket#\d+\s*—\s*/, ''), campoZoom(doc, 'Estado'), campoZoom(doc, 'Fila'), campoZoom(doc, 'Criado')] }],
        total: 1
      };
    }
    const t = doc.querySelector('table.TableSmall');
    if (!t) return { colunas: [], linhas: [], total: 0 };
    const heads = [...t.querySelectorAll('thead th')].map(txt);
    const usar = heads.map((h, i) => (h && !COLUNAS_RUIDO.test(h) ? i : -1)).filter(i => i >= 0);
    const linhas = [...t.querySelectorAll('tbody tr')].map(tr => {
      const a = tr.querySelector('a[href*="TicketID="]');
      const td = tr.querySelectorAll('td');
      return { id: a ? (a.getAttribute('href').match(/TicketID=(\d+)/) || [])[1] : '', valores: usar.map(i => txt(td[i])) };
    }).filter(l => l.valores.some(Boolean));
    const total = +((txt(doc.querySelector('.Pagination')).match(/de\s+(\d+)/) || [])[1] || linhas.length);
    return { colunas: usar.map(i => heads[i]), linhas, total };
  }

  async function buscarChamados(termo, periodo, signal, porNumero = false) {
    const k = `tk:${periodo}:${porNumero ? 'n' : 'f'}:${norm(termo)}`;
    const c = await cacheGet(k, TTL.tickets);
    if (c) return { ...c, cache: true };
    const params = { Action: 'AgentTicketSearch', Subaction: 'Search', ...(porNumero ? { TicketNumber: termo } : { Fulltext: termo, ...PERIODO[periodo] }) };
    const t0 = performance.now();
    const { doc, url } = await pagina(params, signal);
    const r = { ...lerChamados(doc, url), ms: Math.round(performance.now() - t0) };
    await cachePut(k, r);
    return r;
  }

  // ---------- Itens de configuração ----------
  function lerListaIC(doc) {
    const t = doc.querySelector('table.TableSmall');
    if (!t) return [];
    const heads = [...t.querySelectorAll('thead th')].map(txt);
    const iNome = heads.findIndex(h => /^Nome$/i.test(h));
    const iNum = heads.findIndex(h => /ConfigItem#/i.test(h));
    return [...t.querySelectorAll('tbody tr')].map(tr => {
      const a = tr.querySelector('a[href*="ConfigItemID="]');
      const id = a && (a.getAttribute('href').match(/ConfigItemID=(\d+)/) || [])[1];
      const td = tr.querySelectorAll('td');
      return id ? { id, nome: txt(td[iNome]), numero: txt(td[iNum]) } : null;
    }).filter(Boolean);
  }

  function lerCampos(doc) {
    const t = [...doc.querySelectorAll('table')].find(x => /Propriedade/.test(txt(x.querySelector('thead'))));
    const campos = {};
    if (!t) return campos;
    for (const tr of t.querySelectorAll('tbody tr')) {
      const td = tr.querySelectorAll('td');
      const k = txt(td[0]).replace(/:$/, '');
      if (!k || CAMPO_SENSIVEL.test(k) || /^Anexos$/i.test(k)) continue;
      const v = txt(td[1]);
      if (v && !/^(-+|N\/A)$/i.test(v)) campos[k] = v;
    }
    return campos;
  }

  async function buscarIC(classe, termo, signal) {
    const k = `ic:${classe}:${norm(termo)}`;
    const c = await cacheGet(k, TTL.ic);
    if (c) return { ...c, cache: true };
    const t0 = performance.now();
    const { doc } = await pagina({ Action: 'SearchICAJAXHandler', Subaction: 'Search', ClassIDSearch: classe, Search: termo }, signal);
    const lista = lerListaIC(doc);
    const itens = await Promise.all(lista.slice(0, MAX_CIS).map(async it => {
      const z = await pagina({ Action: 'AgentITSMConfigItemZoom', ConfigItemID: it.id }, signal);
      return { ...it, campos: lerCampos(z.doc) };
    }));
    const r = { itens, total: lista.length, ms: Math.round(performance.now() - t0) };
    await cachePut(k, r);
    return r;
  }

  const tipoTermo = t => /^\d{10,}$/.test(t) ? 'numero' : (/^[\w-]+(\.[\w-]+){1,}$/.test(t) && /\d/.test(t)) ? 'designacao' : 'texto';

  // ---------- Interface (padrão da Central) ----------
  const $ = id => document.getElementById(id);
  const out = () => $('h-out');

  function abrir(on) {
    $('hist').hidden = !on;
    document.body.classList.toggle('modo-hist', on);
    if (on) setTimeout(() => $('h-q').focus(), 30);
  }
  $('b-hist').addEventListener('click', () => abrir($('hist').hidden));
  $('h-fechar').addEventListener('click', () => abrir(false));
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('hist').hidden) abrir(false); });

  out().addEventListener('click', e => {
    const cp = e.target.closest('.h-cp');
    if (cp) {
      const valor = cp.dataset.v || '';
      navigator.clipboard?.writeText(valor).then(() => {
        aviso('Copiado');
        cp.classList.add('ok'); setTimeout(() => cp.classList.remove('ok'), 1000);
      });
      return;
    }
    const b = e.target.closest('[data-buscar]');
    if (b) {
      $('h-q').value = b.dataset.buscar;
      if (b.dataset.modo && $('h-modo').value !== b.dataset.modo) { $('h-modo').value = b.dataset.modo; $('h-modo').dispatchEvent(new Event('change')); }
      else buscar();
    }
  });

  const msg = e => e?.name === 'AbortError' ? '' : `<p class="h-err">${esc(e instanceof SessaoExpirada ? e.message : 'Erro: ' + e.message)}</p>`;
  const meta = r => `${r.cache ? 'cache' : r.ms + ' ms'}`;
  const cp = (v, rotulo) => `<button class="h-cp" type="button" data-v="${esc(v)}" title="Copiar ${esc(rotulo)}" aria-label="Copiar ${esc(rotulo)}">${ICONE_COPIAR}</button>`;

  // Chamados como cartões (cabem na largura da Central)
  function htmlChamados(r) {
    if (!r.linhas.length) return '<p class="a-empty">Nenhum chamado.</p>';
    const idx = n => r.colunas.findIndex(c => new RegExp(n, 'i').test(c));
    const [iN, iT, iE, iF, iC] = ['Ticket#', 'T[íi]tulo', 'Estado', 'Fila', 'Criado'].map(idx);
    return r.linhas.map(l => {
      const v = i => (i >= 0 ? l.valores[i] : '') || '';
      const resto = [v(iE), v(iF), v(iC)].filter(Boolean).join(' · ');
      return `<div class="h-tk">
        <div class="h-tk__t">${cp(v(iN), 'Ticket#')}${l.id ? `<a href="${urlTicket(l.id)}" target="_blank" rel="noopener">${esc(v(iN))}</a>` : `<b>${esc(v(iN))}</b>`}</div>
        <div class="h-tk__n">${esc(v(iT))}</div>
        ${resto ? `<small>${esc(resto)}</small>` : ''}</div>`;
    }).join('');
  }

  function htmlCI(ci, tipo) {
    const chaves = tipo === 'links'
      ? CAMPOS_LINK.filter(k => ci.campos[k])
      : Object.keys(ci.campos).filter(k => !OCULTAR_OPERADORA.test(k));
    const isp = tipo === 'links' && ci.campos['ISP'] ? ci.campos['ISP'].replace(/\s*\(.*\)\s*$/, '') : '';
    const desig = ci.campos['Designação ARION'] || '';
    return `<div class="h-card">
      <div class="h-card__t"><b>${esc(ci.nome)}</b><span class="a-empty">CI ${esc(ci.numero)}</span></div>
      <dl class="h-dl">${chaves.map(k => `<dt>${cp(ci.campos[k], k)}${esc(k)}</dt><dd>${esc(ci.campos[k])}</dd>`).join('')}</dl>
      <div class="h-acts">
        <a class="a-chip" href="${urlCI(ci.id)}" target="_blank" rel="noopener">Abrir CI</a>
        ${isp ? `<button class="a-chip" type="button" data-modo="operadoras" data-buscar="${esc(isp)}">Operadora: ${esc(isp)}</button>` : ''}
        ${desig ? `<button class="a-chip" type="button" data-modo="chamados" data-buscar="${esc(desig)}">Chamados desta designação</button>` : ''}
      </div></div>`;
  }

  let controle;
  async function buscar() {
    const termo = $('h-q').value.trim();
    if (!termo) return;
    controle?.abort();
    controle = new AbortController();
    const sig = controle.signal;
    const tipo = tipoTermo(termo);
    const modo = $('h-modo').value;
    const tInicio = performance.now();

    const blocos = [modo];
    const titulos = { chamados: 'Chamados', links: 'Links de internet', operadoras: 'Operadoras' };
    out().innerHTML = blocos.map(b => `<section class="a-card a-card--col h-bloco" id="hb-${b}">
      <div class="a-sec"><span>${titulos[b]}</span><span class="h-st"></span></div><div class="h-c"><p class="a-empty">Buscando…</p></div></section>`).join('') +
      `<p class="a-empty" id="h-tempo"></p>`;
    const bloco = b => ({ st: document.querySelector(`#hb-${b} .h-st`), c: document.querySelector(`#hb-${b} .h-c`) });
    let primeira = false;
    const marca = () => { if (!primeira) { primeira = true; const t = $('h-tempo'); if (t) t.textContent = `Primeira resposta em ${Math.round(performance.now() - tInicio)} ms`; } };

    const tarefas = [];

    if (blocos.includes('chamados')) tarefas.push((async () => {
      const { st, c } = bloco('chamados');
      try {
        if (tipo === 'numero') {
          const r = await buscarChamados(termo, 'tudo', sig, true);
          c.innerHTML = htmlChamados(r); st.textContent = meta(r); marca();
          return;
        }
        const p30 = buscarChamados(termo, '30d', sig);
        const p12 = buscarChamados(termo, '12m', sig);
        const r30 = await p30;
        c.innerHTML = htmlChamados(r30); st.textContent = `30 dias · ${r30.total} · ${meta(r30)} · 12 meses…`; marca();
        const r12 = await p12;
        c.innerHTML = htmlChamados(r12) +
          (r12.total > r12.linhas.length ? `<p class="a-empty">Mostrando ${r12.linhas.length} de ${r12.total}.</p>` : '') +
          `<div class="h-acts"><button class="a-chip" type="button" id="h-tudo">Histórico completo (~15 s)</button></div>`;
        st.textContent = `12 meses · ${r12.total} · ${meta(r12)}`;
        $('h-tudo').onclick = async ev => {
          ev.target.disabled = true; ev.target.textContent = 'Buscando histórico completo…';
          try {
            const rt = await buscarChamados(termo, 'tudo', sig);
            const todos = `${BASE}?Action=AgentTicketSearch;Subaction=Search;Fulltext=${encodeURIComponent(termo)}`;
            c.innerHTML = htmlChamados(rt) + (rt.total > rt.linhas.length
              ? `<p class="a-empty">Mostrando ${rt.linhas.length} de ${rt.total} · <a href="${todos}" target="_blank" rel="noopener">ver todos no OTRS</a></p>` : '');
            st.textContent = `completo · ${rt.total} · ${meta(rt)}`;
          } catch (e) { c.insertAdjacentHTML('beforeend', msg(e)); }
        };
      } catch (e) { c.innerHTML = msg(e); st.textContent = ''; }
    })());

    for (const b of blocos.filter(x => x !== 'chamados')) {
      tarefas.push((async () => {
        const { st, c } = bloco(b);
        try {
          const r = await buscarIC(CLASSE[b], termo, sig);
          c.innerHTML = r.itens.length
            ? r.itens.map(ci => htmlCI(ci, b)).join('') + (r.total > r.itens.length ? `<p class="a-empty">Mostrando ${r.itens.length} de ${r.total}. Refine a busca.</p>` : '')
            : '<p class="a-empty">Nada encontrado.</p>';
          st.textContent = `${r.total} · ${meta(r)}`;
          if (r.itens.length) marca();
        } catch (e) { c.innerHTML = msg(e); }
      })());
    }

    await Promise.allSettled(tarefas);
    const t = $('h-tempo');
    if (t && !sig.aborted) t.textContent += ` · tudo em ${Math.round(performance.now() - tInicio)} ms`;
  }

  chrome.storage.local.get('hist_modo', o => {
    if (['operadoras', 'chamados', 'links'].includes(o.hist_modo)) { $('h-modo').value = o.hist_modo; $('h-modo').dispatchEvent(new Event('change')); }
  });
  $('h-modo').addEventListener('change', () => {
    chrome.storage.local.set({ hist_modo: $('h-modo').value });
    $('h-q').focus();
    if ($('h-q').value.trim()) buscar();
  });
  $('h-buscar').addEventListener('click', buscar);
  $('h-q').addEventListener('keydown', e => { if (e.key === 'Enter') buscar(); });
  $('h-limpar').addEventListener('click', async () => { await cacheLimpar(); aviso('Cache limpo'); });
})();
