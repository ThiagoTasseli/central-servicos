<div align="center">

# ✈️ ARION · Central de Voos 🚀

### Menos digitação, mais voos no horário 🕒

![Manifest](https://img.shields.io/badge/Manifest-V3-FF8440?style=for-the-badge)
![Versão](https://img.shields.io/badge/vers%C3%A3o-4.0.0-00BF9A?style=for-the-badge)
![Chrome](https://img.shields.io/badge/Chrome-✔-6D6E71?style=for-the-badge&logo=googlechrome&logoColor=white)
![Edge](https://img.shields.io/badge/Edge-✔-6D6E71?style=for-the-badge&logo=microsoftedge&logoColor=white)
![Firefox](https://img.shields.io/badge/Firefox_121+-✔-6D6E71?style=for-the-badge&logo=firefoxbrowser&logoColor=white)
![Dados](https://img.shields.io/badge/dados-100%25_locais-00BF9A?style=for-the-badge)

**📥 Importa a planilha → 🧮 calcula os horários → ⏰ avisa na hora certa → 📋 preenche o ServiceAide → 🧾 gera o informe**

</div>

---

## 🧭 Navegue por aqui

[🎯 O que é](#-o-que-é) · [✨ Recursos](#-recursos) · [⚙️ Como funciona](#️-como-funciona) · [🛠️ Tecnologias](#️-tecnologias) · [🗂️ Arquivos](#️-arquivos) · [📦 Instalação](#-instalação) · [🎮 Como usar](#-como-usar) · [🔧 Configurações](#-configurações) · [🔒 Privacidade](#-privacidade) · [🌐 Navegadores](#-navegadores) · [🩺 Problemas](#-problemas-comuns) · [🗓️ Versões](#️-versões)

---

## 🎯 O que é

Uma extensão feita para quem faz a **inspeção e o acompanhamento técnico de voos internacionais de partida** (CUPPS) ✈️.

Para **cada voo**, a rotina era:

- 🔍 abrir chamado de **Inspeção** → **4 horas** antes da partida
- 👀 abrir chamado de **Acompanhamento** → **1 hora** antes da partida
- 🧾 escrever o **informe** de cada um

Agora a extensão faz o trabalho pesado:

| 😩 Antes | 😎 Agora |
|---|---|
| Filtrar a planilha na mão | 📥 Importa e já mostra os voos do dia |
| Calcular −4 h e −1 h | 🧮 Calculado sozinho |
| Lembrar de abrir o chamado | ⏰ Alarme com adiar e silenciar |
| Preencher o ServiceAide campo a campo | 📋 **Um clique** em **Colar** |
| Montar o informe | 🧾 **Um clique** em **Copiar informe** |

---

## ✨ Recursos

### 📊 Consulta de voos
- 📥 Aceita `.xlsx`, `.xls` e `.csv`, por arraste ou clique
- 🧠 Entende colunas mesmo com acento, maiúscula ou espaço diferente
- 🔎 Acha o cabeçalho mesmo fora da primeira linha
- 🎛️ Filtra sozinho: **Partida** + **Internacional** + **data escolhida**
- 🌙 Horários que passam da meia-noite? Sem problema

### 📋 Colar no ServiceAide
Um clique, e o formulário se preenche:

| 🏷️ Campo | ✍️ O que a extensão faz |
|---|---|
| 👤 **Nome** | Digita a busca, aperta Enter, clica na pessoa e espera o E-mail aparecer |
| 📞 **Telefone** | Preenche só depois do Nome |
| 📝 **Descrição** | Máscara do chamado |
| 📄 **Detalhes** | Texto da descrição |
| 🪪 **Matrícula** | `N/A` |
| 🏢 **Departamento** | Abre a lista e clica: **Azul**, **Tap**, **Latam**; as outras vão para **Operações** |
| 📍 **Localização** | `CHECK IN <COMPANHIA>` e clica na sugestão |
| 🧰 **Identificação do equipamento** | `N/A` |

✅ Os campos preenchidos **piscam em verde**. Você só revisa e clica em **Salvar**.

### 🧾 Copiar informe
Com o chamado aberto no ServiceAide, um clique captura a tela e copia:

```
[INSPECAO][CUPPS] Suporte/Outros LATAM INSPEÇÃO 19:40 - 23:40

CHAMADO: 100-28152
ATENDENTE: <seu nome>
SOLICITANTE: Nome Sobrenome
RAMAL: <telefone>
E-MAIL: <e-mail>
LOCALIZAÇÃO: CHECK IN LATAM
VIOLAÇÃO SLA: 09/10/2026 04:14
DESCRIÇÃO: <detalhes do chamado>
```

⏱️ O **SLA** vem direto da tela do ServiceAide. Se não tiver, usa a hora do clique.

### ⏰ Alarmes
- 🔔 Aviso **15 min** antes da Inspeção e **10 min** antes do Acompanhamento (ajustável)
- 🎚️ Cada alarme tem **horário próprio** e **liga/desliga**, igual despertador de celular 📱
- 😴 **Adiar 5 min** ou ❌ **Desativar**
- 🪟 Funciona **com o painel fechado**
- 🔇 **Silenciar:** sino no topo, ou por **30 min · 1 h · 2 h · até reativar**
- 🛑 **Parar som** e 🔊 **Testar som**

### 🎨 Visual
- 🖤 Grafite + 🧡 laranja `#FF8440` + 💚 verde `#00BF9A` com o logo ARION em branco
- 🌗 Tema escuro (padrão) e claro
- ♿ Foco visível e respeito a `prefers-reduced-motion`

---

## ⚙️ Como funciona

```mermaid
flowchart LR
    A[📥 Planilha] --> B[🧠 Leitura e<br/>normalização]
    B --> C[(💾 Storage local<br/>voos por dia)]
    C --> D[🎛️ Filtro<br/>Partida + Internacional + data]
    D --> E[🧮 Inspeção −4h<br/>Acompanhamento −1h]
    E --> F[🃏 Cards de voo]
    E --> G[⏰ Alarmes]
    F -->|📋 Colar| H[🌐 ServiceAide<br/>preenche o formulário]
    H -->|💾 chamado salvo| I[🧾 Copiar informe<br/>captura a tela]
    I --> J[📎 Informe copiado]
```

<details>
<summary><b>📋 Por baixo do capô: o Colar</b> (clique para abrir)</summary>

1. 🔎 Acha a aba do ServiceAide (`https://*.serviceaide.com/*`) e a traz para a frente
2. 💉 Injeta `modules/sa-page.js` em todos os frames, com `chrome.scripting.executeScript`
3. 🎯 Localiza cada campo: primeiro pelos **seletores internos** (`autoidentifier`, `name`), depois pelo **rótulo visível**
4. ⌨️ Simula a digitação e dispara `input`, `change`, `keydown`, `keyup` e `blur`
5. 🪟 **Nome:** digita, Enter, clica na pessoa na janela e espera o E-mail
6. 📜 **Departamento:** abre a lista, rola até a opção, clica e confere
7. 💡 **Localização:** digita, espera as sugestões e clica na certa
8. 📊 Devolve o que foi preenchido e o que falhou

</details>

<details>
<summary><b>🧾 Por baixo do capô: o Copiar informe</b> (clique para abrir)</summary>

1. 💉 Injeta o mesmo script e lê os campos do chamado
2. 🔢 Extrai o número do chamado com `\d{3}-\d{5,}`
3. 🔤 Converte "Sobrenome, Nome" em "Nome Sobrenome" e ajusta as maiúsculas
4. ⏱️ Lê o SLA do bloco "Resolver em"
5. 📎 Monta o texto e copia com `navigator.clipboard.writeText`

</details>

---

## 🛠️ Tecnologias

| 🧱 Camada | 🔧 Tecnologia | 🎯 Para quê |
|---|---|---|
| 🧩 Plataforma | **WebExtensions · Manifest V3** | Chrome, Edge, Brave e Firefox |
| 💛 Linguagem | **JavaScript (ES2020+)**, sem frameworks | Toda a lógica, sem build e sem dependências em execução |
| 🎨 Interface | **HTML5 + CSS3** | *CSS custom properties*, grid, flexbox, temas claro e escuro |
| 📊 Planilhas | **SheetJS** (`xlsx.full.min.js`) | Lê `.xlsx`, `.xls` e `.csv` localmente |
| 💾 Dados | **`chrome.storage.local`** | Voos por dia, configurações, status, alarmes e tema |
| ⏰ Agenda | **`chrome.alarms`** | Alarmes que sobrevivem ao painel fechado |
| 🔔 Alertas | **`chrome.notifications`** | Notificação do sistema |
| 🔊 Som | **`offscreen`** (Chromium) · `Audio` (Firefox) | Toque em repetição |
| 🪟 Painel | **`sidePanel`** (Chromium) · **`sidebar_action`** (Firefox) | Interface que não fecha ao trocar de janela |
| 🌐 Integração | **`chrome.scripting`** + script injetado | Ler e preencher o ServiceAide |
| 📎 Cópia | **Clipboard API** | Campos, chamados e informes |
| 🧬 Módulos | **IIFE + `self.*`** | Mesmo código no painel e no background |

**🧪 Como foi validado**
- ✅ **Mozilla `addons-linter`**: manifesto do Firefox sem erros
- ✅ **Playwright + Chromium**: teste ponta a ponta num ServiceAide simulado (Colar com 8 campos, lista de Departamento, janela do Nome, autocomplete da Localização, Copiar informe e silenciar)

---

## 🗂️ Arquivos

```
📁 VoosBH-Extension/
├── 📜 manifest.json            Manifesto MV3 (+ ajustes do Firefox)
├── ⚙️ background.js            Alarmes, notificações, som, mudo, barra lateral do Firefox
├── 🖼️ popup.html / .css / .js  Interface: abas Voos · Configurações · Alarme
├── 📐 mode.js                  Detecta painel, barra lateral, aba ou popup
├── 🔈 offscreen.html / .js     Toca o som (Chromium)
├── 🎨 assets/                  Logo ARION em branco
├── 🔖 icons/                   Ícones 16 · 48 · 128
├── 🔔 sounds/alert.wav         Som do alerta
├── 📚 libs/xlsx.full.min.js    SheetJS
└── 📁 modules/
    ├── 🕒 formatters.js        Datas, horas, normalização de texto
    ├── 📊 spreadsheet.js       Colunas, leitura, filtro, cálculo de horários
    ├── 📝 templates.js         Chamados, campos do ServiceAide, informe, regra de departamento
    ├── 💾 storage.js           Acesso único ao storage + estado de mudo
    ├── ⏰ alarms.js            Cálculo puro dos alarmes
    ├── 📎 clipboard.js         Cópia com tratamento de erro
    ├── 🌉 autofill.js          Ponte painel ↔ ServiceAide
    └── 💉 sa-page.js           Script injetado: acha campos, preenche e captura
```

---

## 📦 Instalação

### 🟢 Chrome · Edge · Brave
1. 📂 Descompacte o `.zip`
2. 🌐 Abra `chrome://extensions` (ou `edge://extensions`)
3. 🛠️ Ative o **Modo do desenvolvedor**
4. 📥 **Carregar sem compactação** → escolha a pasta com o `manifest.json`
5. 🖱️ Clique no ícone: o **painel lateral** abre

### 🦊 Firefox (temporária)
1. 🧰 Abra `about:debugging` → **Este Firefox**
2. 📥 **Carregar extensão temporária** → escolha o `manifest.json`
3. 🔑 Em `about:addons` → extensão → **Permissões** → ative `serviceaide.com`
4. 🖱️ Clique no ícone: a **barra lateral** abre e fica aberta

> ⚠️ Extensão temporária some quando o Firefox fecha. Veja abaixo como deixar fixa.

### 🦊 Firefox (permanente)
- ✍️ **Assinar na Mozilla** (grátis): envie o `.zip` ao addons.mozilla.org como **não listada** e instale o `.xpi` assinado. O ID já está no manifesto: `voosbh@grupoarion.com.br`
- 🧪 **Developer Edition ou ESR**: em `about:config`, `xpinstall.signatures.required` = `false`

---

## 🎮 Como usar

- [ ] 📥 **1.** Importe a planilha na aba **Voos**
- [ ] 📅 **2.** Escolha a data
- [ ] 🌐 **3.** Abra o formulário "Acompanhamento técnico de voo" no ServiceAide
- [ ] 📋 **4.** No card do voo, clique em **Colar Inspeção** ou **Colar Acomp.**
- [ ] 👀 **5.** Revise e clique em **Salvar** no ServiceAide
- [ ] 🧾 **6.** Com o chamado salvo, clique em **Copiar informe** e cole onde precisar
- [ ] ✏️ **7.** Quer mudar algum texto? Use **Editar / copiar campos**
- [ ] ⏰ **8.** Ajuste os alarmes na aba **Alarme** (e use o 🔇 quando precisar de silêncio)

### 🎛️ Botões do card de voo

| 🔘 Botão | 💡 O que faz |
|---|---|
| 🟧 **Colar Inspeção** | Preenche o ServiceAide com a Inspeção |
| 🟩 **Colar Acomp.** | Preenche o ServiceAide com o Acompanhamento |
| ✏️ **Editar / copiar campos** | Mostra e edita os campos; copia um por um |
| 🧾 **Copiar informe** | Captura o chamado aberto e copia o informe |
| 📚 **Copiar todos os chamados** | Copia os chamados de todos os voos do dia |

---

## 🔧 Configurações

Na aba **Configurações** (tudo fica salvo no seu navegador):

| 📂 Grupo | 🏷️ Campo | 📝 Para quê |
|---|---|---|
| 🧑‍💼 Chamados | Atendente, Solicitante, Ramais, E-mail | Textos dos chamados e do informe |
| 🌐 ServiceAide | Matrícula · Identificação do equipamento | Valores fixos (`N/A`) |
| 🌐 ServiceAide | Prefixo da Localização | Padrão `CHECK IN` |
| 🌐 ServiceAide | Nome: busca / clicar em | O que digitar e em quem clicar |
| 🌐 ServiceAide | Telefone | Preenchido depois do Nome |
| 🌐 ServiceAide | Departamento = companhia / demais | Quem tem departamento próprio e o padrão das outras |
| 🧾 Informe | Violação SLA, horas | Horas somadas ao clique, se a tela não trouxer o SLA |
| ⏰ Alarme | Minutos de antecedência | 15 min (Inspeção) · 10 min (Acompanhamento) |

---

## 🔒 Privacidade

- 🏠 **Tudo é local.** Nenhum dado vai para servidores
- 📊 A planilha é lida **dentro do navegador**
- 🎯 A extensão só age em `serviceaide.com`, e só quando **você clica**
- 🦊 Declara `data_collection_permissions: none` para o Firefox
- 🧹 **Limpar dados** (no rodapé) apaga planilha, status e alarmes

<details>
<summary><b>🔑 Permissões usadas</b></summary>

| 🔐 Permissão | 🎯 Motivo |
|---|---|
| `storage` · `unlimitedStorage` | Guardar voos e configurações |
| `alarms` | Agendar os alertas |
| `notifications` | Exibir os alertas |
| `offscreen` | Tocar o som (Chromium) |
| `sidePanel` | Painel lateral (Chromium) |
| `scripting` | Ler e preencher o ServiceAide |
| `https://*.serviceaide.com/*` | Único site em que a extensão atua |

</details>

---

## 🌐 Navegadores

| 🧩 Recurso | 🟢 Chrome · Edge · Brave | 🦊 Firefox 121+ |
|---|---|---|
| 🪟 Interface | Painel lateral fixo | Barra lateral fixa |
| 📋 Colar e 🧾 Copiar informe | ✅ | ✅ (liberar `serviceaide.com`) |
| ⏰ Alarmes e 🔊 som | ✅ mesmo com painel fechado | ✅ com o Firefox aberto |
| 🔔 Botões Adiar e Desativar na notificação | ✅ | ❌ use os botões do card no painel |
| 📌 Instalação permanente | Carregar a pasta | Precisa de assinatura da Mozilla |

---

## 🩺 Problemas comuns

| 😕 Sintoma | 🔍 Causa provável | 🛠️ O que fazer |
|---|---|---|
| "ServiceAide não está aberto" | Sem aba do ServiceAide | Abra o formulário e tente de novo |
| "Sem acesso à aba do ServiceAide" | Permissão não liberada | Firefox: `about:addons` → Permissões. Em qualquer um: recarregue a extensão e a página |
| Campo não preencheu | Rótulo ou seletor mudou | A mensagem diz qual campo. Preencha à mão e avise para ajustar |
| "Departamento: opção não encontrada" | Nome diferente na lista | Ajuste o nome em Configurações |
| Nome sem E-mail | Pessoa não escolhida na janela | Escolha à mão; confira "clicar em" nas Configurações |
| Informe sem nº do chamado | Chamado não salvo | Salve, ou digite o número quando a extensão perguntar |
| Planilha não reconhecida | Cabeçalho diferente | A extensão diz qual coluna faltou |
| Alarme sem som | Alarmes silenciados | Veja o 🔔 no topo e a aba Alarme |
| Firefox: extensão some | Extensão temporária | Assine na Mozilla |

---

## 🧠 Decisões técnicas

- 📌 **Painel fixo, não popup.** Popup fecha ao arrastar arquivo ou trocar de janela. No Firefox, por isso, o ícone abre a barra lateral
- 🎯 **Seletores primeiro, rótulo de reserva.** Precisão quando o site é o mesmo, resiliência se ele mudar
- 🔢 **Ordem importa.** Nome antes (completa o E-mail), Telefone depois
- 🚧 **Campo bloqueado não é pulado**, para nunca escrever no campo errado
- 🕰️ **Datas com `Date` e milissegundos**, para tratar a meia-noite
- ♻️ **Alarmes recriados do zero** a cada mudança: sem duplicidade
- 🗓️ **Voos guardados por dia** (`flightsByDate::AAAA-MM-DD`): carrega só o dia em uso
- 🧬 **Módulos compartilhados** entre painel e background
- 📝 **Textos fiéis à especificação**, inclusive "INDENTIFICAR" (Inspeção) × "IDENTIFICAR" (Acompanhamento), que é proposital

---

## ⚠️ Limitações

- 🌐 Depende da estrutura atual do ServiceAide; mudanças no site podem pedir ajuste de seletores
- 🧪 Validado num formulário simulado e na lógica da extensão arion-plugin; confirme no ambiente real
- 🦊 No Firefox: instalação permanente exige assinatura e notificações não têm botões
- 🪟 O ServiceAide precisa estar aberto em uma aba comum

---

## 🗓️ Versões

| 🏷️ Versão | 🆕 Novidades |
|---|---|
| 🚀 **4.0.0** | 🦊 Firefox abre a barra lateral fixa · 🧾 "Copiar informe" no estilo de "Editar / copiar campos" |
| 3.1.0 | 🧾 Copiar informe com a lógica da arion-plugin · 🎯 Colar com seletores reais · 🦊 popup do Firefox corrigido |
| 3.0.1 | 🏢 Departamento como lista de seleção |
| 3.0.0 | 👤 Nome (janela de busca), 📞 Telefone, 🏢 Departamento · informes INS e AC |
| 2.2.0 | 📋 Colar no ServiceAide · 🔇 silenciar alarmes · 🎨 visual ARION |
| 2.1.0 | ✈️ Base: voos, chamados e alarmes |

---

<div align="center">

**💚 Feito para a operação ARION 🧡**

✈️ Bons voos! ✈️

</div>
