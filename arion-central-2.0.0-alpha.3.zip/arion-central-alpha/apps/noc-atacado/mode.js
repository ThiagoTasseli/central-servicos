/* mode.js — carregado no <head>, antes de desenhar a tela.
 * Define como o painel está aberto, para o CSS ajustar o tamanho:
 *   panel   → painel lateral do Chrome/Edge (altura da janela)
 *   sidebar → barra lateral do Firefox
 *   tab     → aba inteira
 *   popup   → popup do Firefox (precisa de largura/altura fixas,
 *             senão o Firefox abre o popup "achatado")
 */
(function () {
  var params = new URLSearchParams(location.search);
  var mode = params.get("mode");
  if (!mode) {
    var api = typeof chrome !== "undefined" ? chrome : null;
    mode = api && api.sidePanel ? "panel" : "popup";
  }
  document.documentElement.setAttribute("data-mode", mode);
})();
