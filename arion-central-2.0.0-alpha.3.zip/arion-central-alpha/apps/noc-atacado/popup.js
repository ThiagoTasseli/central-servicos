/* popup.js — painel lateral do NOC (Atacado e Suporte TI). */
(function () {

const R = self.Regras;
const $ = id => document.getElementById(id);

const NOMES = {
  tipo: 'Tipo', localidade: 'Localidade', razao: 'Razão social', fantasia: 'Nome fantasia',
  servicoSgf: 'Serviço SGF', subServico: 'Sub serviço SGF', servico: 'Serviço', sla: 'SLA',
  site: 'Site', links: 'Links de internet', titulo: 'Título', assunto: 'Assunto', texto: 'Texto',
  aberturaIsp: 'Abertura chamado ISP'
};

let ticket = null;     // { ticketId, numero, titulo, texto }
let d = null;          // dados extraídos + edições
let prog = { cat: '', enc: '', etapas: [] };
let confirmandoMover = null;
let tipoGlobal = 'atacado';   // último tipo escolhido (vale para chamados novos)

const ehSuporte = () => d && d.tipoCh === 'suporte';
const filaAtual = () => ehSuporte() ? R.SUPORTE.filaEncaminhar : R.FILA;

// ---------------- storage ----------------
// Escapa texto vindo da página do OTRS antes de ir para innerHTML.
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const get = k => new Promise(r => chrome.storage.local.get(k, v => r(v[k])));
const set = (k, v) => new Promise(r => chrome.storage.local.set({ [k]: v }, r));
const chave = () => 'tk_' + ticket.ticketId;
// ts: usado pela limpeza automática (dados com mais de 7 dias são apagados).
const salvar = () => ticket && set(chave(), { d, prog, ts: Date.now() });

// ---------------- toast ----------------
let toastTimer;
function toast(msg, erro = false) {
  const t = $('toast');
  t.textContent = msg;
  t.className = 'toast' + (erro ? ' erro' : '');
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.hidden = true), 2400);
}

// ---------------- tema ----------------
function aplicarTema(tema) {
  document.documentElement.setAttribute('data-theme', tema);
  $('i-sol').hidden = tema === 'dark';
  $('i-lua').hidden = tema !== 'dark';
}
$('b-tema').onclick = async () => {
  const novo = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
  aplicarTema(novo);
  await set('tema', novo);
};

// ---------------- formulário ----------------
$('tipoCh').innerHTML = Object.entries(R.TIPOS).map(([k, t]) => `<option value="${k}">${t.nome}</option>`).join('');
$('grupo').innerHTML = '<option value="">—</option>' +
  Object.entries(R.MODELOS).map(([k, m]) => `<option value="${k}">${m.nome}</option>`).join('');
$('motivo').innerHTML = R.MOTIVOS.map(m => `<option value="${m}">${m}</option>`).join('');

// Cliente e operadora mostram só o que vale para o modelo escolhido.
function opcoes(id, itens) {
  const el = $(id), atual = el.value;
  const html = '<option value="">—</option>' + itens.map(([k, n]) => `<option value="${k}">${n}</option>`).join('');
  if (el.dataset.html === html) return;
  el.dataset.html = html;
  el.innerHTML = html;
  el.value = itens.some(([k]) => k === atual) ? atual : '';
}
function atualizarOpcoes() {
  const g = R.MODELOS[d && d.grupo];
  const clientes = g && g.clientes ? g.clientes : Object.keys(R.CLIENTES);
  opcoes('cliente', clientes.map(k => [k, R.CLIENTES[k].nome]));
  const ops = d ? R.operadorasPermitidas(d) : Object.keys(R.OPERADORAS);
  opcoes('operadora', ops.map(k => [k, R.OPERADORAS[k].nome]));
}
atualizarOpcoes();

$('uf').innerHTML = '<option value="">Selecione o estado</option>' +
  R.UFS.map(u => `<option value="${u}">${u}</option>`).join('');

const CAMPOS = ['tipoCh', 'grupo', 'motivo', 'cliente', 'operadora', 'designacao', 'identificador', 'uf', 'op'];

function lerForm() {
  CAMPOS.forEach(c => (d[c] = $(c).value.trim()));
  d.designacao = d.designacao.toUpperCase();
  d.uf = d.uf.toUpperCase();
  d.op = d.op.toUpperCase();
  R.completar(d);
}

function preencherForm() {
  atualizarOpcoes();
  CAMPOS.forEach(c => ($(c).value = d[c] || ''));
}

CAMPOS.forEach(c => $(c).addEventListener('input', () => {
  // Trocou o tipo ou o modelo: refaz as listas antes de ler.
  if (c === 'tipoCh') { tipoGlobal = $('tipoCh').value; set('noc_tipo', tipoGlobal); prog = { cat: '', enc: '', etapas: [] }; }
  if (c === 'grupo') { $('cliente').value = ''; atualizarOpcoes(); }
  lerForm();
  d.editado = true;
  atualizarOpcoes();
  // Mudou o cliente/modelo: a operadora pode ficar inválida.
  const ops = R.operadorasPermitidas(d);
  if ((c === 'cliente' || c === 'grupo') && !ops.includes(d.operadora)) {
    $('operadora').value = ops.length === 1 ? ops[0] : '';
    lerForm();
  }
  salvar();
  render();
}));

// ---------------- tipo (controle segmentado) ----------------
function segTipo(tipo) {
  document.querySelectorAll('#aTipo button').forEach(b => b.classList.toggle('on', b.dataset.tipo === tipo));
}
document.querySelectorAll('#aTipo button').forEach(b => b.addEventListener('click', () => {
  if (!d) {
    tipoGlobal = b.dataset.tipo;
    set('noc_tipo', tipoGlobal);
    segTipo(tipoGlobal);
    return;
  }
  $('tipoCh').value = b.dataset.tipo;
  $('tipoCh').dispatchEvent(new Event('input', { bubbles: true }));
}));

// ---------------- render ----------------
function render() {
  const tem = !!ticket;
  $('vazio').hidden = tem;
  $('conteudo').hidden = !tem;
  $('h-ticket').textContent = tem ? 'Ticket#' + (ticket.numero || ticket.ticketId) : 'Nenhum chamado';
  if (!tem) return;

  $('titulo').textContent = ticket.titulo || '';
  $('titulo').title = ticket.titulo || '';

  const sup = ehSuporte();
  const so = !sup && d.soMascara;
  segTipo(d.tipoCh);
  atualizarOpcoes();
  ['tipoCh', 'grupo', 'motivo', 'cliente', 'operadora', 'uf'].forEach(id => {
    const v = d[id] || '';
    if ($(id).value !== v) $(id).value = v;
  });
  $('w-grupo').hidden = sup;
  $('w-motivo').hidden = !sup;
  const gAtual = R.MODELOS[d.grupo];
  const umCliente = !!(gAtual && gAtual.clientes && gAtual.clientes.length === 1);
  $('w-cliente').hidden = sup || so || umCliente;
  $('a-reloc').hidden = sup || so || !umCliente || !d.mascara;
  $('loc-status').hidden = sup || so || !$('loc-status').textContent;
  $('w-operadora').hidden = sup;
  $('w-designacao').hidden = sup;
  $('w-ident').hidden = sup;
  $('w-op').hidden = sup || d.grupo !== 'canc';
  $('so-mascara').hidden = !so;
  $('acoes').hidden = so;
  $('b-reloc').hidden = sup;

  $('l-ident').textContent = { ci: 'CI', inc: 'INC (Vivo)', agencia: 'BRAD', sigla: 'SIGLA', brad: 'BRAD', np: 'NP' }[d.tipoSufixo] || R.SUFIXOS[d.tipoSufixo].rotulo;
  $('w-uf').hidden = sup || d.cliente !== 'algar';
  $('uf-preview').textContent = d.cliente === 'algar' && d.uf ? '→ ' + d.localidadeOpcao : '';

  const falta = d.faltando;
  const marcaErro = (id, cond) => $(id).closest('.f').classList.toggle('erro', cond);
  marcaErro('grupo', falta.includes('modelo'));
  marcaErro('cliente', falta.includes('cliente'));
  marcaErro('op', falta.includes('OP'));
  marcaErro('operadora', falta.some(f => f.startsWith('operadora')));
  marcaErro('designacao', falta.includes('designação'));
  marcaErro('identificador', falta.includes(R.SUFIXOS[d.tipoSufixo].rotulo.toLowerCase()));
  marcaErro('uf', falta.includes('UF'));

  $('mask').textContent = d.mascara || '—';
  $('mask').closest('.mask').classList.toggle('ok', !!d.mascara);
  $('falta').hidden = !falta.length;
  $('falta').textContent = 'Sem informações do cliente: ' + falta.join(', ') + '.';

  const pronto = !!d.mascara;
  if (!$('b-reloc').classList.contains('run')) $('b-reloc').disabled = !pronto;
  const bCat = $('b-cat');
  bCat.disabled = !pronto || bCat.classList.contains('carregando');
  if (!bCat.classList.contains('carregando')) {
    const feito = prog.cat === 'ok';
    bCat.className = 'a-btn ' + (feito ? 'a-btn--done' : 'a-btn--pri');
    bCat.innerHTML = feito ? '<span class="a-n">✓</span>Categorizado' : '<span class="a-n">1</span>Categorizar';
    bCat.title = feito ? 'Clique para categorizar de novo' : '';
  }

  const FILA = filaAtual();
  const bEnc = $('b-enc');
  bEnc.disabled = !pronto || bEnc.classList.contains('carregando') || prog.enc === 'ok';
  const carregandoEnc = bEnc.classList.contains('carregando');
  bEnc.className = 'a-btn ' + (prog.enc === 'ok' ? 'a-btn--done' : prog.enc === 'nota' ? 'a-btn--perigo' : 'a-btn--acc') + (carregandoEnc ? ' carregando' : '');
  if (!carregandoEnc) {
    bEnc.innerHTML =
      prog.enc === 'ok' ? '<span class="a-n">✓</span>Encaminhado'
      : prog.enc === 'nota' ? (confirmandoMover ? 'Confirmar' : 'Mover p/ fila')
      : '<span class="a-n">2</span>Encaminhar';
    bEnc.title = `Fila: ${FILA}`;
  }
  $('a-fila').textContent = prog.enc === 'nota' ? `Clique em Mover para enviar à fila ${FILA}.` : `Fila: ${FILA}`;
  $('a-fila').hidden = so;

  const ol = $('etapas');
  ol.hidden = !prog.etapas.length;
  ol.innerHTML = prog.etapas.map(e => `<li class="${esc(e.st)}">${esc(e.nome)}<em>${esc(e.msg)}</em></li>`).join('');
}

function etapas(lista) { prog.etapas = lista.map(nome => ({ nome, st: '', msg: '' })); render(); }
function etapa(i, st, msg = '') { Object.assign(prog.etapas[i], { st, msg }); salvar(); render(); }

function carregando(id, on) {
  $(id).classList.toggle('carregando', on);
  if (on) $(id).textContent = 'Executando';
  render();
}

function falhasLegiveis(r) {
  return (r.falhas || []).map(f => NOMES[f] || f).join(', ');
}

// ---------------- leitura ----------------
async function ler(forcar = false) {
  $('b-ler').classList.add('girando');
  const r = await OTRS.ler();
  $('b-ler').classList.remove('girando');

  if (!r.ok) {
    if (forcar) toast(r.erro, true);
    $('vazio-motivo').textContent = r.erro || '';
    $('b-permitir').hidden = !/Sem acesso|permission/i.test(r.erro || '');
    if (!ticket) render();
    return;
  }
  // Mesmo ticket já carregado: mantém edições do analista.
  if (!forcar && ticket && ticket.ticketId === r.ticketId) return;

  ticket = r;
  const salvo = await get(chave());
  const novo = R.extrair(r);
  novo.tipoCh = tipoGlobal;
  R.completar(novo);
  // Reabrir o painel mantém edições; "Ler chamado" refaz a extração.
  // Só reaproveita o salvo se o analista editou algo; senão, lê de novo do chamado.
  d = salvo && salvo.d && salvo.d.editado && !forcar ? R.completar({ ...novo, ...salvo.d, tipoCh: tipoGlobal }) : novo;
  prog = { cat: '', enc: '', etapas: [], ...(salvo && salvo.prog) };
  preencherForm();
  statusLink('', '');
  statusLoc('', '');
  await salvar();
  render();
  if (forcar) toast('Chamado lido');
}

$('b-ler').onclick = () => ler(true);
$('a-reloc').onclick = () => $('b-reloc').click();

// Firefox (MV3) não libera o domínio na instalação: pede no clique.
$('b-permitir').onclick = async () => {
  const ok = await chrome.permissions.request({ origins: chrome.runtime.getManifest().host_permissions });
  if (ok) { $('b-permitir').hidden = true; ler(true); }
};

// ---------------- 1 · categorizar ----------------
function statusLoc(tipo, msg) {
  const el = $('loc-status');
  el.className = 'link-status f--full ' + tipo;
  el.textContent = msg;
  el.hidden = !msg;
}

function payloadCat(auto) {
  return { d, fixos: R.FIXOS, texto: R.textoCategorizacao(d), enviar: auto };
}

function payloadSuporte(auto) {
  return { d, fixos: R.SUPORTE.fixos, texto: R.textoCategorizacaoSuporte(), enviar: auto };
}

// Suporte TI (Engenharia): Campos Livres sem Localidade nem Links.
async function categorizarSuporte() {
  const auto = $('auto').checked;
  etapas(['Abrir Campos Livres', 'Preencher campos', auto ? 'Enviar' : 'Conferir e clicar em Enviar']);
  carregando('b-cat', true);
  etapa(0, 'run');
  const r = await OTRS.categorizarSuporte(ticket.ticketId, payloadSuporte(auto)).catch(e => ({ ok: false, erro: e.message }));
  carregando('b-cat', false);
  if (r && r.erro) { etapa(0, 'erro', r.erro); return toast(r.erro, true); }
  etapa(0, 'ok', r.versao ? 'código v' + r.versao : '');
  if (!r.ok) { etapa(1, 'erro', falhasLegiveis(r)); return toast('Campos não preenchidos', true); }
  etapa(1, 'ok', r.slaAlternativo ? `SLA "Sem SLA" indisponível: usado "${r.slaAlternativo}"` : '');
  prog.cat = 'ok';
  if (r.enviado) { etapa(2, 'ok'); toast('Chamado categorizado'); }
  else { etapa(2, 'vez', 'sua vez'); toast('Confira e clique em Enviar'); }
  await salvar();
  render();
}

// Resultado do Categorizar e do ↻ da Localidade (mesma sequência de campos).
async function tratarCategorizacao(r) {
  if (r && r.erro) { etapa(0, 'erro', r.erro); return toast(r.erro, true); }
  // Mostra qual versão do código rodou no OTRS (diagnóstico).
  const versaoExt = chrome.runtime.getManifest().version;
  const versaoOtrs = r && r.versao;
  etapa(0, 'ok', versaoOtrs ? 'código v' + versaoOtrs : '');
  if (versaoOtrs && versaoOtrs !== versaoExt) toast(`Código no OTRS (v${versaoOtrs}) ≠ extensão (v${versaoExt}). Dê F5 no OTRS.`, true);

  if (r.paradoEm === 'localidade') {
    etapa(1, 'erro', 'Localidade não confirmada');
    statusLoc('erro', '! Localidade não confirmada. A lista ficou aberta: escolha no OTRS ou clique em ↻.');
    await salvar();
    render();
    return toast('Localidade não confirmada', true);
  }
  statusLoc('ok', '✓ Localidade: ' + d.localidadeOpcao);

  if (!r.ok) {
    etapa(1, 'erro', falhasLegiveis(r));
    return toast('Campos não preenchidos', true);
  }
  const soTexto = r.campos.links === 'texto' ? 'link sem sugestão, ficou o texto' : '';
  if (r.campos.links === true) statusLink('ok', '✓ ' + (r.linkOpcao || 'Opção selecionada'));
  else if (r.campos.links === 'texto') statusLink('texto', '! Nenhuma opção apareceu. Ficou só o texto. Use ↻ para tentar de novo.');
  const avisos = [soTexto, r.slaAlternativo ? `SLA sem 24x7: usado "${r.slaAlternativo}"` : ''].filter(Boolean).join(' · ');
  etapa(1, 'ok', avisos);
  if (r.slaAlternativo) toast(`SLA 24x7 indisponível: usado "${r.slaAlternativo}"`);

  if (r.enviado) { etapa(2, 'ok'); prog.cat = 'ok'; toast('Chamado categorizado'); }
  else { etapa(2, 'vez', 'sua vez'); prog.cat = 'ok'; toast('Confira e clique em Enviar'); }
  await salvar();
  render();
}

$('b-cat').onclick = async () => {
  if (ehSuporte()) return categorizarSuporte();
  const auto = $('auto').checked;
  etapas(['Abrir Campos Livres', 'Localidade e campos', auto ? 'Enviar' : 'Conferir e clicar em Enviar']);
  carregando('b-cat', true);
  statusLoc('run', 'Selecionando a Localidade…');
  etapa(0, 'run');
  const r = await OTRS.categorizar(ticket.ticketId, payloadCat(auto)).catch(e => ({ ok: false, erro: e.message }));
  carregando('b-cat', false);
  await tratarCategorizacao(r);
};

// ↻ da Localidade: refaz a Localidade e retoma o Categorizar até o fim.
$('b-reloc').onclick = async () => {
  if (!ticket || !d.mascara) return toast('Complete os dados do chamado', true);
  const auto = $('auto').checked;
  const b = $('b-reloc');
  b.disabled = true;
  b.classList.add('run');
  etapas(['Abrir Campos Livres', 'Localidade e campos (de novo)', auto ? 'Enviar' : 'Conferir e clicar em Enviar']);
  statusLoc('run', 'Tentando a Localidade de novo…');
  etapa(0, 'run');
  const r = await OTRS.refazerLocalidade(ticket.ticketId, payloadCat(auto)).catch(e => ({ ok: false, erro: e.message }));
  b.disabled = false;
  b.classList.remove('run');
  await tratarCategorizacao(r);
};

// ---------------- ↻ buscar de novo no Links de internet ----------------
function statusLink(tipo, msg) {
  const el = $('link-status');
  el.className = 'link-status ' + tipo;
  el.textContent = msg;
  el.hidden = !msg;
}

$('b-rebusca').onclick = async () => {
  if (!ticket || !d.designacao) return toast('Informe a designação', true);
  const b = $('b-rebusca');
  b.disabled = true;
  b.classList.add('run');
  statusLink('run', 'Apagando e digitando de novo…');

  const r = await OTRS.rebuscarLink(ticket.ticketId, d.designacao).catch(e => ({ ok: false, erro: e.message }));

  b.disabled = false;
  b.classList.remove('run');
  if (!r || r.erro) return statusLink('erro', '! ' + ((r && r.erro) || 'Falhou'));
  if (r.resultado === 'opcao') statusLink('ok', '✓ ' + (r.opcao || 'Opção selecionada'));
  else if (r.resultado === 'texto') statusLink('texto', '! Nenhuma opção apareceu. Ficou só o texto.');
  else statusLink('erro', '! Campo Links de internet não encontrado.');
};

// ---------------- 2 · encaminhar ----------------
$('b-enc').onclick = async () => {
  if (prog.enc === 'nota') return mover();

  const auto = $('auto').checked;
  const sup = ehSuporte();
  etapas(['Abrir Nota', 'Preencher nota', auto ? 'Enviar nota' : 'Conferir e clicar em Enviar', `Mover para ${filaAtual()}`]);
  carregando('b-enc', true);
  etapa(0, 'run');

  const r = await OTRS.nota(ticket.ticketId, {
    assunto: R.ASSUNTO_NOTA, texto: sup ? R.textoNotaSuporte() : R.textoNota(), enviar: auto, isp: !sup
  }).catch(e => ({ ok: false, erro: e.message }));

  carregando('b-enc', false);
  if (r && r.erro) { etapa(0, 'erro', r.erro); return toast(r.erro, true); }
  etapa(0, 'ok');
  if (!r.ok) { etapa(1, 'erro', falhasLegiveis(r)); return toast('Nota não preenchida', true); }
  etapa(1, 'ok');
  etapa(2, r.enviado ? 'ok' : 'vez', r.enviado ? '' : 'sua vez');
  etapa(3, 'vez', 'confirme no botão');
  prog.enc = 'nota';
  await salvar();
  render();
};

// Mover não tem desfazer: exige dois cliques em até 4 s.
async function mover() {
  if (!confirmandoMover) {
    confirmandoMover = setTimeout(() => { confirmandoMover = null; render(); }, 4000);
    return render();
  }
  clearTimeout(confirmandoMover);
  confirmandoMover = null;

  const i = prog.etapas.length - 1;
  carregando('b-enc', true);
  if (i >= 0) etapa(i, 'run');
  const r = await OTRS.mover(ticket.ticketId, filaAtual()).catch(e => ({ ok: false, erro: e.message }));
  carregando('b-enc', false);

  if (!r || !r.ok) {
    const msg = (r && (r.erro || falhasLegiveis(r))) || 'falhou';
    if (i >= 0) etapa(i, 'erro', msg);
    return toast(msg, true);
  }
  if (i >= 0) etapa(i, 'ok');
  prog.enc = 'ok';
  await salvar();
  render();
  toast(`Movido para ${filaAtual()}`);
}

// ---------------- rodapé ----------------
$('auto').onchange = e => set('auto', e.target.checked);

$('b-limpar').onclick = async () => {
  if (!ticket) return;
  await chrome.storage.local.remove(chave());
  prog = { cat: '', enc: '', etapas: [] };
  await ler(true);
};

$('b-copiar').onclick = async () => {
  if (!d || !d.mascara) return;
  await navigator.clipboard.writeText(d.mascara);
  toast('Copiado');
};

// ---------------- init ----------------
(async () => {
  aplicarTema((await get('tema')) || 'light');
  tipoGlobal = (await get('noc_tipo')) === 'suporte' ? 'suporte' : 'atacado';
  segTipo(tipoGlobal);
  const auto = await get('auto');
  $('auto').checked = auto === undefined ? true : !!auto;
  render();
  await ler();

  // Troca de aba ou página: lê o chamado novo.
  chrome.tabs.onActivated.addListener(() => ler());
  chrome.tabs.onUpdated.addListener((_, info) => { if (info.status === 'complete') ler(); });
  chrome.windows.onFocusChanged.addListener(() => ler());
})();

})();
