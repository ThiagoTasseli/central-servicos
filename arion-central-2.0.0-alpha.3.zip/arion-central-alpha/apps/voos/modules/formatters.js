/* modules/formatters.js
 * Funções puras de data/hora e normalização de texto.
 * Compartilhado entre popup e background via importScripts / <script>.
 */
(function () {

// ---------- Normalização de texto ----------

/** remove acentos, baixa para minúsculo, colapsa espaços e underscores */
function normalizeHeader(str) {
  return String(str ?? "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "") // remove acentos
    .trim()
    .toLowerCase()
    .replace(/_/g, " ")
    .replace(/\s+/g, " ");
}

// ---------- Conversão de valores de célula ----------

/** Converte valor de célula (serial Excel, string ou Date) em "HH:mm" */
function toHHMM(value) {
  if (value == null || value === "") return null;

  if (typeof value === "number") {
    const totalMinutes = Math.round((value % 1) * 24 * 60);
    const h = Math.floor(totalMinutes / 60) % 24;
    const m = totalMinutes % 60;
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
  }

  if (value instanceof Date) {
    // SheetJS sempre constrói o Date de células numéricas (data/hora) usando
    // UTC como referência, independente do fuso do navegador. Usar getters
    // locais aqui deslocaria o horário quando o fuso do usuário não for UTC.
    return `${String(value.getUTCHours()).padStart(2, "0")}:${String(value.getUTCMinutes()).padStart(2, "0")}`;
  }

  const str = String(value).trim();
  const match = str.match(/^(\d{1,2})[:h](\d{2})/);
  if (match) {
    return `${match[1].padStart(2, "0")}:${match[2]}`;
  }
  return null;
}

/** Converte valor de célula (serial Excel, string dd/mm/yyyy, ou Date) em "yyyy-mm-dd" */
function toISODate(value) {
  if (value == null || value === "") return null;

  if (typeof value === "number") {
    const utcDays = Math.floor(value - 25569);
    const d = new Date(utcDays * 86400 * 1000);
    return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-${String(d.getUTCDate()).padStart(2, "0")}`;
  }

  if (value instanceof Date) {
    // Mesmo motivo do toHHMM: célula de data do Excel é sempre meia-noite
    // UTC. Em fusos negativos (ex.: America/Sao_Paulo, UTC-3), getters
    // locais "voltam" a data em 1 dia.
    return `${value.getUTCFullYear()}-${String(value.getUTCMonth() + 1).padStart(2, "0")}-${String(value.getUTCDate()).padStart(2, "0")}`;
  }

  const str = String(value).trim();
  let m = str.match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (m) return `${m[1]}-${m[2]}-${m[3]}`;

  // Formato pedido explicitamente pela planilha: DD/MM/AAAA
  m = str.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})/);
  if (m) {
    let [, d, mo, y] = m;
    if (y.length === 2) y = `20${y}`;
    return `${y}-${mo.padStart(2, "0")}-${d.padStart(2, "0")}`;
  }
  return null;
}

/** Retorna "yyyy-mm-dd" de hoje, no fuso local */
function todayISO() {
  const d = new Date();
  return formatISODate(d);
}

/** Cria um Date local a partir de "yyyy-mm-dd" + "HH:mm" */
function dateFromISOAndHHMM(iso, hhmm) {
  const [y, mo, d] = iso.split("-").map(Number);
  const [h, m] = hhmm.split(":").map(Number);
  return new Date(y, mo - 1, d, h, m, 0, 0);
}

/** "HH:mm" de um objeto Date, no fuso local */
function formatHHMM(date) {
  return `${String(date.getHours()).padStart(2, "0")}:${String(date.getMinutes()).padStart(2, "0")}`;
}

/** "yyyy-mm-dd" de um objeto Date, no fuso local */
function formatISODate(date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

/** "DD/MM/AAAA" a partir de "yyyy-mm-dd" */
function isoToBR(iso) {
  if (!iso) return "";
  const [y, mo, d] = iso.split("-");
  return `${d}/${mo}/${y}`;
}

/** "DD/MM" a partir de "yyyy-mm-dd" */
function isoToShortBR(iso) {
  if (!iso) return "";
  const [, mo, d] = iso.split("-");
  return `${d}/${mo}`;
}

/**
 * Rótulo de exibição de um horário de evento (Inspeção/Acompanhamento),
 * incluindo a data entre parênteses quando o evento cai em dia diferente
 * do voo (ex.: inspeção da madrugada calculada no dia anterior).
 */
function eventTimeLabel(eventHHMM, eventISODate, flightISODate) {
  if (!eventHHMM) return "";
  if (eventISODate && flightISODate && eventISODate !== flightISODate) {
    return `${eventHHMM} (${isoToShortBR(eventISODate)})`;
  }
  return eventHHMM;
}

// ---------- Numeração circulada ①②③ ----------
const CIRCLED_DIGITS = "①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳";
function circledNumber(n) {
  if (n >= 1 && n <= CIRCLED_DIGITS.length) return CIRCLED_DIGITS[n - 1];
  return `(${n})`;
}

/* Exporta para uso via importScripts no service worker (self) e no popup (window) */
if (typeof self !== "undefined") {
  self.Fmt = {
    normalizeHeader,
    toHHMM,
    toISODate,
    todayISO,
    dateFromISOAndHHMM,
    formatHHMM,
    formatISODate,
    isoToBR,
    isoToShortBR,
    eventTimeLabel,
    circledNumber,
  };
}

})();
