/* modules/clipboard.js
 * Wrapper único para navigator.clipboard.writeText, com tratamento de erro
 * consistente. Usado apenas no popup (contexto com DOM/foco de página).
 */
(function () {

/**
 * Copia texto para a área de transferência.
 * Retorna { ok: true } ou { ok: false, error }.
 */
async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
    return { ok: true };
  } catch (err) {
    console.error("Falha ao copiar para a área de transferência:", err);
    return { ok: false, error: err };
  }
}

if (typeof self !== "undefined") {
  self.Clipboard = { copyText };
}

})();
