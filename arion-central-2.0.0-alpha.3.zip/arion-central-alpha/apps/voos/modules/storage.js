/* modules/storage.js
 * Encapsula todo o acesso ao chrome.storage.local em um único lugar, com
 * chaves e valores padrão bem definidos. Compartilhado entre popup e
 * background (via importScripts / <script>).
 */
(function () {

const { DEFAULT_SETTINGS, DEFAULT_ALARM_SETTINGS } = self.Templates;
const { todayISO } = self.Fmt;

const KEYS = {
  RAW_ROWS: "rawFlightRows", // todas as linhas normalizadas, sem filtro de data
  FILE_NAME: "importedFileName",
  SETTINGS: "settings",
  ALARM_SETTINGS: "alarmSettings",
  SELECTED_DATE: "selectedDate",
  FLIGHT_STATUS: "flightStatus", // { [flightId]: { inspecao, acompanhamento } }
  ALARM_OVERRIDES: "alarmOverrides", // { [alarmEntryId]: { enabled: bool, hhmm: "HH:mm"|null } }
  FLIGHTS_DATE_PREFIX: "flightsByDate::", // + dataISO -> voos normalizados só daquele dia
  TOTAL_COUNT: "flightsTotalCount", // total de voos reconhecidos na planilha (todas as datas)
  FLIGHT_DATES: "flightDates", // lista de dataISO que têm voos, para saber o que existe sem carregar tudo
  THEME: "theme", // "light" | "dark"
  ALARM_SOUND: "alarmSound", // id do som escolhido (ver sounds/sons.js)
  CUSTOM_ALARMS: "customAlarms", // [{ id, tipo, titulo, hhmm, repetir, obs, enabled, data, snoozeUntil }]
  MUTE_UNTIL: "alarmMuteUntil", // 0 = som ativo · -1 = silenciado até reativar · timestamp = silenciado até
};

// ---------- Silenciar alarmes ----------
const MUTE_FOREVER = -1;

function isMutedValue(muteUntil, now = Date.now()) {
  return muteUntil === MUTE_FOREVER || (muteUntil > 0 && now < muteUntil);
}

async function getMuteUntil() {
  const { [KEYS.MUTE_UNTIL]: v } = await chrome.storage.local.get(KEYS.MUTE_UNTIL);
  const n = Number(v || 0);
  // Silêncio temporário já expirado volta a 0 sozinho
  return n > 0 && Date.now() >= n ? 0 : n;
}

async function setMuteUntil(value) {
  await chrome.storage.local.set({ [KEYS.MUTE_UNTIL]: Number(value) || 0 });
}

async function isMuted() {
  return isMutedValue(await getMuteUntil());
}

async function getTheme() {
  const { [KEYS.THEME]: theme } = await chrome.storage.local.get(KEYS.THEME);
  return theme || "light";
}

async function setTheme(theme) {
  await chrome.storage.local.set({ [KEYS.THEME]: theme });
}

async function getSettings() {
  const { [KEYS.SETTINGS]: settings } = await chrome.storage.local.get(KEYS.SETTINGS);
  return { ...DEFAULT_SETTINGS, ...(settings || {}) };
}

async function setSettings(settings) {
  await chrome.storage.local.set({ [KEYS.SETTINGS]: settings });
}

async function getAlarmSettings() {
  const { [KEYS.ALARM_SETTINGS]: alarmSettings } = await chrome.storage.local.get(KEYS.ALARM_SETTINGS);
  return { ...DEFAULT_ALARM_SETTINGS, ...(alarmSettings || {}) };
}

async function setAlarmSettings(alarmSettings) {
  await chrome.storage.local.set({ [KEYS.ALARM_SETTINGS]: alarmSettings });
}

async function getSelectedDate() {
  const { [KEYS.SELECTED_DATE]: date } = await chrome.storage.local.get(KEYS.SELECTED_DATE);
  return date || todayISO();
}

async function setSelectedDate(dateISO) {
  await chrome.storage.local.set({ [KEYS.SELECTED_DATE]: dateISO });
}

async function getRawRows() {
  const { [KEYS.RAW_ROWS]: rows } = await chrome.storage.local.get(KEYS.RAW_ROWS);
  return rows || [];
}

async function setRawRows(rows, fileName) {
  await chrome.storage.local.set({ [KEYS.RAW_ROWS]: rows, [KEYS.FILE_NAME]: fileName || "" });
}

async function getFileName() {
  const { [KEYS.FILE_NAME]: name } = await chrome.storage.local.get(KEYS.FILE_NAME);
  return name || "";
}

function dateStorageKey(dataISO) {
  return `${KEYS.FLIGHTS_DATE_PREFIX}${dataISO}`;
}

/** Grava os voos agrupados por data, um key por dia — permite carregar só o dia em uso. */
async function setFlightsData(flights, fileName) {
  const byDate = {};
  (flights || []).forEach((f) => {
    if (!byDate[f.dataVoo]) byDate[f.dataVoo] = [];
    byDate[f.dataVoo].push(f);
  });

  const toSet = { [KEYS.FILE_NAME]: fileName || "", [KEYS.TOTAL_COUNT]: (flights || []).length };
  const dates = Object.keys(byDate);
  dates.forEach((date) => {
    toSet[dateStorageKey(date)] = byDate[date];
  });
  toSet[KEYS.FLIGHT_DATES] = dates;

  await chrome.storage.local.set(toSet);
}

/** Lê só os voos de UMA data — evita carregar a planilha inteira a cada abertura. */
async function getFlightsForDate(dataISO) {
  const key = dateStorageKey(dataISO);
  const res = await chrome.storage.local.get(key);
  return res[key] || [];
}

async function getTotalFlightCount() {
  const { [KEYS.TOTAL_COUNT]: n } = await chrome.storage.local.get(KEYS.TOTAL_COUNT);
  return n || 0;
}

async function getFlightDates() {
  const { [KEYS.FLIGHT_DATES]: dates } = await chrome.storage.local.get(KEYS.FLIGHT_DATES);
  return dates || [];
}

/** Migra dados antigos (planilha inteira em uma única chave) para o formato por dia. Sem efeito se já migrado. */
async function migrateLegacyRawRows() {
  const { [KEYS.RAW_ROWS]: legacy } = await chrome.storage.local.get(KEYS.RAW_ROWS);
  if (!legacy || !legacy.length) return;
  const fileName = await getFileName();
  await setFlightsData(legacy, fileName);
  await chrome.storage.local.remove(KEYS.RAW_ROWS);
}

async function getFlightStatusMap() {
  const { [KEYS.FLIGHT_STATUS]: map } = await chrome.storage.local.get(KEYS.FLIGHT_STATUS);
  return map || {};
}

async function setFlightStatus(flightId, kind) {
  const map = await getFlightStatusMap();
  map[flightId] = map[flightId] || { inspecao: "pendente", acompanhamento: "pendente" };
  map[flightId][kind] = "copiado";
  await chrome.storage.local.set({ [KEYS.FLIGHT_STATUS]: map });
  return map;
}

async function setAllFlightStatus(flightIds) {
  const map = await getFlightStatusMap();
  flightIds.forEach((id) => {
    map[id] = { inspecao: "copiado", acompanhamento: "copiado" };
  });
  await chrome.storage.local.set({ [KEYS.FLIGHT_STATUS]: map });
  return map;
}

async function getAlarmOverrides() {
  const { [KEYS.ALARM_OVERRIDES]: overrides } = await chrome.storage.local.get(KEYS.ALARM_OVERRIDES);
  return overrides || {};
}

/** Grava o ajuste individual (horário próprio e/ou ativado/desativado) de UM alarme. */
async function setAlarmOverride(alarmId, override) {
  const overrides = await getAlarmOverrides();
  overrides[alarmId] = { ...(overrides[alarmId] || {}), ...override };
  await chrome.storage.local.set({ [KEYS.ALARM_OVERRIDES]: overrides });
  return overrides;
}

/** Remove o ajuste individual de UM alarme, voltando-o ao horário padrão calculado. */
async function clearAlarmOverride(alarmId) {
  const overrides = await getAlarmOverrides();
  delete overrides[alarmId];
  await chrome.storage.local.set({ [KEYS.ALARM_OVERRIDES]: overrides });
  return overrides;
}

// ---------- Alarmes próprios (tarefas e lembretes) ----------
async function getCustomAlarms() {
  const { [KEYS.CUSTOM_ALARMS]: list } = await chrome.storage.local.get(KEYS.CUSTOM_ALARMS);
  return Array.isArray(list) ? list : [];
}

async function setCustomAlarms(list) {
  await chrome.storage.local.set({ [KEYS.CUSTOM_ALARMS]: list });
  return list;
}

/** Cria ou atualiza (mesmo id) um alarme próprio. */
async function upsertCustomAlarm(alarm) {
  const list = await getCustomAlarms();
  const i = list.findIndex((a) => a.id === alarm.id);
  if (i === -1) list.push(alarm);
  else list[i] = { ...list[i], ...alarm };
  return setCustomAlarms(list);
}

async function getAlarmSound() {
  const { [KEYS.ALARM_SOUND]: id } = await chrome.storage.local.get(KEYS.ALARM_SOUND);
  return id || "classico";
}

async function setAlarmSound(id) {
  await chrome.storage.local.set({ [KEYS.ALARM_SOUND]: String(id || "classico") });
}

async function deleteCustomAlarm(id) {
  return setCustomAlarms((await getCustomAlarms()).filter((a) => a.id !== id));
}

/** Remove tudo que diz respeito à planilha/voos importados, preservando Configurações e Alarme. */
async function clearFlightData() {
  const dates = await getFlightDates();
  await chrome.storage.local.remove([
    KEYS.RAW_ROWS,
    KEYS.FILE_NAME,
    KEYS.FLIGHT_STATUS,
    KEYS.ALARM_OVERRIDES,
    KEYS.TOTAL_COUNT,
    KEYS.FLIGHT_DATES,
    ...dates.map(dateStorageKey),
  ]);
}

if (typeof self !== "undefined") {
  self.Storage = {
    KEYS,
    getSettings,
    setSettings,
    getAlarmSettings,
    setAlarmSettings,
    getSelectedDate,
    setSelectedDate,
    getRawRows,
    setRawRows,
    getFileName,
    setFlightsData,
    getFlightsForDate,
    getTotalFlightCount,
    getFlightDates,
    migrateLegacyRawRows,
    getFlightStatusMap,
    setFlightStatus,
    setAllFlightStatus,
    getAlarmOverrides,
    setAlarmOverride,
    clearAlarmOverride,
    clearFlightData,
    getCustomAlarms,
    setCustomAlarms,
    upsertCustomAlarm,
    deleteCustomAlarm,
    getAlarmSound,
    setAlarmSound,
    getTheme,
    setTheme,
    MUTE_FOREVER,
    isMutedValue,
    getMuteUntil,
    setMuteUntil,
    isMuted,
  };
}

})();
