/* modules/templates.js
 * Geração dos textos dos chamados (Inspeção/Acompanhamento) e do informe
 * de voo. Mantém os textos padronizados EXATAMENTE como especificado,
 * pois são usados para abertura de chamados reais.
 */
(function () {

const { eventTimeLabel } = self.Fmt;

// ---------- Configurações padrão ----------
const DEFAULT_SETTINGS = {
  atendente: "Thiago Tasseli",
  solicitante: "Gregory Felipe de Freitas Santos",
  ramalInspecao: "31 93500-0908",
  ramalAcompanhamento: "31 93500-090",
  email: "gregory.santos@grupoarion.com.br",
  // Campos fixos do formulário do ServiceAide (botão "Colar")
  saMatricula: "N/A",
  saEquipamento: "N/A",
  saLocalPrefixo: "CHECK IN",
  // Solicitante: digita o texto de busca, Enter, e clica no nome na janela
  saNomeBusca: "Gregory",
  saNomeSelecionar: "Felipe de Freitas Santos",
  saTelefone: "31 93500-0908",
  // Departamento: companhias com departamento próprio; as demais → padrão
  saDeptCompanhias: "AZUL, TAP, LATAM",
  saDeptPadrao: "Operações",
  // Informe: VIOLAÇÃO SLA = horário do clique + X horas
  slaHoras: 0,
};

const DEFAULT_ALARM_SETTINGS = {
  minutosInspecao: 15,
  minutosAcompanhamento: 10,
};

// ---------- Mapeamento de destinos (sigla -> país / cidade) ----------
// Estrutura simples e fácil de ampliar.
const DESTINATIONS = {
  PTY: "Panamá",
  SCL: "Santiago, Chile",
  LIS: "Lisboa, Portugal",
  CUR: "Curaçao",
  BRC: "Bariloche, Argentina",
  MVD: "Montevidéu, Uruguai",
  MIA: "Miami, EUA",
  MAD: "Madri, Espanha",
  CDG: "Paris, França",
  FRA: "Frankfurt, Alemanha",
};

/**
 * Extrai a sigla IATA de destino de um valor de "Rota" (ex.: "GRU-PTY",
 * "GRU/PTY", "PTY", "PTY - Cidade do Panamá"). Usa o último código de 3
 * letras maiúsculas encontrado; se nada for encontrado, usa o texto bruto.
 */
function resolveDestino(rotaRaw) {
  const raw = String(rotaRaw || "").trim();
  if (!raw) return { sigla: "", pais: "", display: "" };

  const matches = raw.toUpperCase().match(/\b[A-Z]{3}\b/g);
  const sigla = matches && matches.length ? matches[matches.length - 1] : raw.toUpperCase();
  const pais = DESTINATIONS[sigla] || "";
  const display = pais ? `${sigla} (${pais})` : sigla;
  return { sigla, pais, display };
}

// ---------- Rótulos / ordem dos campos (para "copiar tudo abaixo") ----------
const INSPECAO_FIELD_ORDER = ["mascara", "atendente", "solicitante", "ramal", "descricao"];
const ACOMPANHAMENTO_FIELD_ORDER = [
  "mascara",
  "atendente",
  "solicitante",
  "ramal",
  "email",
  "descricao",
];

const FIELD_LABELS = {
  mascara: null, // a máscara é copiada crua, sem rótulo
  atendente: "ATENDENTE",
  solicitante: "SOLICITANTE",
  ramal: "RAMAL",
  email: "E-MAIL",
  descricao: "DESCRIÇÃO",
};

function fieldOrderFor(kind) {
  return kind === "acompanhamento" ? ACOMPANHAMENTO_FIELD_ORDER : INSPECAO_FIELD_ORDER;
}

// ---------- Construção dos campos do chamado ----------

/** Campos editáveis do chamado de Inspeção */
function buildInspecaoFields(flight, settings) {
  const s = { ...DEFAULT_SETTINGS, ...(settings || {}) };
  const companhia = String(flight.empresa || "").toUpperCase();
  const horaInspecao = flight.inspecaoTime;
  const horaPartida = flight.horarioVoo;

  return {
    mascara: `[INSPECAO][CUPPS] Suporte/Outros ${companhia} INSPEÇÃO ${horaInspecao} - ${horaPartida}`,
    atendente: s.atendente,
    solicitante: s.solicitante,
    // Mesmo ramal configurado em Acompanhamento, replicado automaticamente aqui.
    ramal: s.ramalAcompanhamento,
    // Texto EXATO da especificação — "INDENTIFICAR" (com D) é intencional
    // e não deve ser "corrigido" para "IDENTIFICAR" nesta descrição.
    descricao:
      `REALIZAR A INSPEÇÃO NO CHECK IN DA COMPANHIA AÉREA ${companhia}. ` +
      `DESCRIMINAR NA RAT O SERVIÇO EXECUTADO DURANTE O ACOMPANHAMENTO. ` +
      `CASO NÃO CONSIGA INDENTIFICAR NENHUMA FALHA, PREENCHER COMO "OPERACIONAL".`,
  };
}

/** Campos editáveis do chamado de Acompanhamento (inclui e-mail) */
function buildAcompanhamentoFields(flight, settings) {
  const s = { ...DEFAULT_SETTINGS, ...(settings || {}) };
  const companhia = String(flight.empresa || "").toUpperCase();
  const horaAcomp = flight.acompanhamentoTime;
  const horaPartida = flight.horarioVoo;

  return {
    mascara: `[ACOMPANHAMENTO][CUPPS] Suporte/Outros ${companhia} ACOMPANHAMENTO - ${horaAcomp} - ${horaPartida}`,
    atendente: s.atendente,
    solicitante: s.solicitante,
    ramal: s.ramalAcompanhamento,
    email: s.email,
    // "IDENTIFICAR" sem D aqui é intencional (diferente da Inspeção).
    descricao:
      `REALIZAR O ACOMPANHAMENTO NO CHECK IN DA COMPANHIA AÉREA ${companhia}. ` +
      `DESCRIMINAR NA RAT O SERVIÇO EXECUTADO DURANTE O ACOMPANHAMENTO. ` +
      `CASO NÃO CONSIGA IDENTIFICAR NENHUMA FALHA, PREENCHER COMO "OPERACIONAL".\n\n` +
      `ACOMPANHAR O CHECK-IN E EMBARQUE`,
  };
}

// ---------- Composição de texto ----------

/** Recompõe o texto completo do chamado (botão "Copiar" laranja) */
function composeChamadoText(fields, kind) {
  const order = fieldOrderFor(kind);
  return order.map((key) => formatFieldLine(key, fields[key])).join("\n");
}

/** Uma linha rotulada (ou crua, no caso da máscara) */
function formatFieldLine(key, value) {
  const label = FIELD_LABELS[key];
  const val = value ?? "";
  return label ? `${label}: ${val}` : val;
}

/** Valor cru de um único campo (para o botão "copiar campo") */
function copyFieldValue(fields, key) {
  return fields[key] ?? "";
}

/** Campo selecionado + todos os campos abaixo dele, respeitando a ordem visual */
function copyFieldAndBelow(fields, kind, fromKey) {
  const order = fieldOrderFor(kind);
  const startIdx = order.indexOf(fromKey);
  if (startIdx === -1) return formatFieldLine(fromKey, fields[fromKey]);
  return order
    .slice(startIdx)
    .map((key) => formatFieldLine(key, fields[key]))
    .join("\n");
}

/**
 * Campos do formulário "Acompanhamento técnico de voo" no ServiceAide,
 * usados pelo botão "Colar". `fields` são os campos (já editados) do
 * chamado de Inspeção ou Acompanhamento.
 *   Descrição  ← máscara do chamado
 *   Detalhes   ← texto da descrição
 *   Matrícula / Localização / Identificação do equipamento ← Configurações
 */
function departamentoPara(companhia, settings) {
  const s = { ...DEFAULT_SETTINGS, ...(settings || {}) };
  const lista = String(s.saDeptCompanhias || "")
    .split(/[,;]/)
    .map((c) => c.trim().toUpperCase())
    .filter(Boolean);
  const cia = String(companhia || "").trim().toUpperCase();
  // Opções da lista têm a 1ª letra maiúscula: Azul, Tap, Latam, Operações
  const valor = lista.includes(cia) ? cia : s.saDeptPadrao;
  return titleCase(valor);
}

function buildServiceAideFields(fields, flight, settings) {
  const s = { ...DEFAULT_SETTINGS, ...(settings || {}) };
  const companhia = String(flight.empresa || "").toUpperCase();
  // ORDEM IMPORTA: Nome primeiro (a janela de busca preenche o E-mail),
  // Telefone só depois do nome selecionado.
  return [
    {
      key: "nome",
      label: "Nome",
      labels: ["Nome"],
      mode: "modal",
      search: s.saNomeBusca,
      pick: s.saNomeSelecionar,
      waitFor: ["Email", "E-mail"],
      value: s.saNomeSelecionar,
    },
    { key: "telefone", label: "Telefone", labels: ["Telefone"], value: s.saTelefone },
    { key: "descricao", label: "Descrição", labels: ["Descrição"], value: fields.mascara || "" },
    { key: "detalhes", label: "Detalhes", labels: ["Detalhes", "Detalhe"], value: fields.descricao || "" },
    { key: "matricula", label: "Matrícula", labels: ["Matrícula"], value: s.saMatricula },
    {
      key: "departamento",
      label: "Departamento",
      labels: ["Departamento"],
      value: departamentoPara(companhia, s),
      mode: "select",
    },
    {
      key: "localizacao",
      label: "Localização",
      labels: ["Localização"],
      value: `${s.saLocalPrefixo} ${companhia}`.trim(),
      mode: "autocomplete",
    },
    {
      key: "equipamento",
      label: "Identificação do equipamento",
      labels: ["Identificação do equipamento", "Identificação do equip."],
      value: s.saEquipamento,
    },
  ];
}

/** Campos lidos da tela do ServiceAide para montar o informe INS / AC */
const SERVICEAIDE_READ_FIELDS = [
  { key: "nome", labels: ["Nome"] },
  { key: "telefone", labels: ["Telefone"] },
  { key: "email", labels: ["Email", "E-mail"] },
  { key: "localizacao", labels: ["Localização"] },
  { key: "descricao", labels: ["Descrição"] },
  { key: "detalhes", labels: ["Detalhes", "Detalhe"] },
];

function formatDateTimeBR(date) {
  const p = (n) => String(n).padStart(2, "0");
  return `${p(date.getDate())}/${p(date.getMonth() + 1)}/${date.getFullYear()} ${p(date.getHours())}:${p(date.getMinutes())}`;
}

/** Título no modelo: [INSPECAO][CUPPS] Suporte/Outros [TAP] [INSPEÇÃO 13:25 - 17:25] */
function informeTitulo(kind, flight) {
  const companhia = String(flight.empresa || "").toUpperCase();
  const isAcomp = kind === "acompanhamento";
  const tag = isAcomp ? "ACOMPANHAMENTO" : "INSPECAO";
  const nome = isAcomp ? "ACOMPANHAMENTO" : "INSPEÇÃO";
  const hora = isAcomp ? flight.acompanhamentoTime : flight.inspecaoTime;
  return `[${tag}][CUPPS] Suporte/Outros [${companhia}] [${nome} ${hora} - ${flight.horarioVoo}]`;
}

/** Descrição do informe: sem linhas em branco extras e aspas “ ” como no modelo */
function informeDescricao(text) {
  return String(text || "")
    .replace(/\r/g, "")
    .replace(/\n{2,}/g, "\n")
    .replace(/"([^"]*)"/g, "“$1”")
    .trim();
}

/** Primeira letra de cada palavra maiúscula: GREGORY FELIPE DE … → Gregory Felipe De … */
function titleCase(text) {
  return String(text || "")
    .toLowerCase()
    .replace(/(^|\s)(\S)/g, (m, sp, ch) => sp + ch.toUpperCase());
}

/**
 * Informe INS / AC.
 * `page` = valores lidos do ServiceAide (podem vir vazios); `fields` = campos
 * do chamado na extensão (usados como reserva).
 */
function buildInformeChamado(kind, flight, fields, settings, page, now = new Date()) {
  const s = { ...DEFAULT_SETTINGS, ...(settings || {}) };
  const p = page || {};
  const companhia = String(flight.empresa || "").toUpperCase();
  const sla = new Date(now.getTime() + Number(s.slaHoras || 0) * 3600 * 1000);

  const lines = [
    informeTitulo(kind, flight),
    "",
    `CHAMADO: ${p.chamado || ""}`,
    `ATENDENTE: ${s.atendente}`,
    `SOLICITANTE: ${titleCase(p.nome || s.solicitante)}`,
    `RAMAL: ${p.telefone || s.saTelefone}`,
    `E-MAIL: ${p.email || s.email}`,
    `LOCALIZAÇÃO: ${p.localizacao || `${s.saLocalPrefixo} ${companhia}`.trim()}`,
    `VIOLAÇÃO SLA: ${formatDateTimeBR(sla)}`,
    `DESCRIÇÃO: ${informeDescricao(p.detalhes || fields.descricao)}`,
  ];
  return lines.join("\n");
}

/** Número do chamado limpo (ex.: "Solicitação 100-28152" → "100-28152") */
function cleanChamado(value) {
  const text = String(value || "").trim();
  const m = text.match(/\b\d{3}-\d{5,}\b/);
  return m ? m[0] : text;
}

/** "Sobrenome, Nome" → "Nome Sobrenome" (igual à arion-plugin) */
function normalizeRequester(value) {
  const partes = String(value || "").split(",");
  return partes.length === 2 ? `${partes[1].trim()} ${partes[0].trim()}` : String(value || "").trim();
}

/**
 * Informe a partir dos dados capturados do ServiceAide — mesmo modelo da
 * arion-plugin. SLA vem da tela; se não houver, usa o horário do clique.
 */
function buildInformeServiceAide(data, settings, now = new Date()) {
  const s = { ...DEFAULT_SETTINGS, ...(settings || {}) };
  const d = data || {};
  const sla = d.sla || formatDateTimeBR(new Date(now.getTime() + Number(s.slaHoras || 0) * 3600 * 1000));
  return `${String(d.descricao || "").trim()}

CHAMADO: ${cleanChamado(d.chamado)}
ATENDENTE: ${s.atendente}
SOLICITANTE: ${titleCase(normalizeRequester(d.nome))}
RAMAL: ${String(d.telefone || "").trim()}
E-MAIL: ${String(d.email || "").trim()}
LOCALIZAÇÃO: ${String(d.localizacao || "").trim()}
VIOLAÇÃO SLA: ${String(sla).trim()}
DESCRIÇÃO: ${String(d.detalhes || "").trim()}`;
}

/** Informe do voo (seção 16 da especificação) */
function buildInformeText(flight) {
  const companhia = String(flight.empresa || "").toUpperCase();
  const destino = resolveDestino(flight.destinoRaw);
  const inspecaoLabel = eventTimeLabel(flight.inspecaoTime, flight.inspecaoDate, flight.dataVoo);
  const acompanhamentoLabel = eventTimeLabel(
    flight.acompanhamentoTime,
    flight.acompanhamentoDate,
    flight.dataVoo
  );

  const lines = [
    `Data: ${self.Fmt.isoToBR(flight.dataVoo)}`,
    `Voo: ${companhia} ${flight.numeroVoo}`.trim(),
    `Origem/Destino: ${destino.display || "—"}`,
    `Partida: ${flight.horarioVoo}`,
    `Inspeção: ${inspecaoLabel}`,
    `Acompanhamento: ${acompanhamentoLabel}`,
  ];
  if (flight.assentos) lines.push(`Assentos: ${flight.assentos}`);
  lines.push(`Natureza: Internacional`);
  return lines.join("\n");
}

/** Informe + chamado de Inspeção + chamado de Acompanhamento de UM voo */
function buildFlightBundle(flight, settings) {
  const informe = buildInformeText(flight);
  const inspecao = composeChamadoText(buildInspecaoFields(flight, settings), "inspecao");
  const acompanhamento = composeChamadoText(buildAcompanhamentoFields(flight, settings), "acompanhamento");
  return [informe, inspecao, acompanhamento].join("\n\n" + "-".repeat(40) + "\n\n");
}

/** Todos os chamados de todos os voos filtrados, em ordem cronológica */
function buildAllFlightsText(flights, settings) {
  return flights.map((f) => buildFlightBundle(f, settings)).join("\n\n" + "-".repeat(40) + "\n\n");
}

if (typeof self !== "undefined") {
  self.Templates = {
    DEFAULT_SETTINGS,
    DEFAULT_ALARM_SETTINGS,
    DESTINATIONS,
    resolveDestino,
    INSPECAO_FIELD_ORDER,
    ACOMPANHAMENTO_FIELD_ORDER,
    FIELD_LABELS,
    fieldOrderFor,
    buildInspecaoFields,
    buildAcompanhamentoFields,
    composeChamadoText,
    formatFieldLine,
    copyFieldValue,
    copyFieldAndBelow,
    buildServiceAideFields,
    departamentoPara,
    SERVICEAIDE_READ_FIELDS,
    buildInformeChamado,
    buildInformeServiceAide,
    cleanChamado,
    formatDateTimeBR,
    buildInformeText,
    buildFlightBundle,
    buildAllFlightsText,
  };
}

})();
