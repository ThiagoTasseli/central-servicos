/* alpha-chamados.js — visual minimalista (Alpha). A lógica fica no sidebar.js. */
(function () {
  const $ = (id) => document.getElementById(id);

  // Menu ⋯ do cabeçalho
  const menu = $('aMenu');
  $('aMore').addEventListener('click', (e) => { e.stopPropagation(); menu.hidden = !menu.hidden; });
  document.addEventListener('click', (e) => { if (!menu.hidden && !menu.contains(e.target)) menu.hidden = true; });
  menu.addEventListener('click', () => setTimeout(() => (menu.hidden = true), 0));
  $('cfgToggle').addEventListener('click', () => setTimeout(() => !$('cfg').hidden && $('cfgNew').focus(), 0));

  // Solicitação | Incidente → select #tipo (usado pelo sidebar.js)
  const tipo = $('tipo');
  const seg = document.querySelectorAll('#aTipo button');
  const syncSeg = () => {
    seg.forEach((b) => b.classList.toggle('on', b.dataset.v === tipo.value));
    $('aTipo').classList.toggle('invalid', tipo.classList.contains('invalid'));
  };
  seg.forEach((b) => b.addEventListener('click', () => {
    tipo.value = b.dataset.v;
    tipo.classList.remove('invalid');
    tipo.dispatchEvent(new Event('input', { bubbles: true }));
    tipo.dispatchEvent(new Event('change', { bubbles: true }));
    syncSeg();
  }));
  new MutationObserver(syncSeg).observe(tipo, { attributes: true, attributeFilter: ['class'] });
  setInterval(syncSeg, 600); // valor restaurado do storage sem evento

  // Nome localizado: o botão vira "Localizado"
  const nome = $('nome'), find = $('nomeFind');
  new MutationObserver(() => {
    const ok = nome.classList.contains('found');
    find.classList.toggle('a-chip--ok', ok);
    find.querySelector('span').textContent = ok ? 'Localizado' : 'Localizar';
    find.querySelector('svg').innerHTML = ok ? '<path d="m5 12 5 5 9-10"/>' : '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>';
  }).observe(nome, { attributes: true, attributeFilter: ['class'] });

  // Texto do chamado: aviso some quando o texto aparece
  new MutationObserver(() => ($('aTextoVazio').hidden = !$('result').hidden))
    .observe($('result'), { attributes: true, attributeFilter: ['hidden'] });
  $('aTextoVazio').hidden = !$('result').hidden;
  syncSeg();
})();
