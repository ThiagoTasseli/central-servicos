// ========================================
// GRUPO ARION - popup.js
// ========================================

const SITE_DEFINITIONS = {
  // Cada modulo de site expõe seus seletores, campos e regra de mascara no window.
  serviceAide: window.ServiceAideSite,
};

const CAPTURE_SELECTORS = Object.fromEntries(
  // Monta um objeto menor para enviar ao script injetado na pagina aberta.
  Object.entries(SITE_DEFINITIONS).map(([key, site]) => [
    key,
    {
      fields: site.selectors,
      iframeSelector: site.iframeSelector || '',
    },
  ])
);

function $(id) {
  // Atalho para buscar elementos do popup pelo id.
  return document.getElementById(id);
}

function captureScript(site, selectors) {
  // Esta funcao roda dentro da aba ativa do navegador, nao dentro do popup.
  const siteConfig = selectors[site] || {};
  const siteSelectors = siteConfig.fields || {};
  const searchRoots = getSearchRoots(siteConfig.iframeSelector);

  function getSearchRoots(iframeSelector) {
    // Comeca procurando no documento principal e, quando configurado, tambem tenta o iframe do sistema.
    const roots = [document];

    if (iframeSelector) {
      try {
        const iframe = document.querySelector(iframeSelector);
        const iframeDocument = iframe?.contentDocument || iframe?.contentWindow?.document;
        if (iframeDocument && iframeDocument !== document) roots.push(iframeDocument);
      } catch (_) {
        // Cross-origin iframes are handled by injecting this script into all frames.
      }
    }

    return roots;
  }

  function readElement(el) {
    // Normaliza a leitura de valor para inputs, textareas, selects e elementos comuns.
    if (!el) return '';

    const tag = el.tagName.toLowerCase();
    if (tag === 'input' || tag === 'textarea' || tag === 'select') {
      return el.value?.trim() || el.getAttribute('title')?.trim() || el.textContent?.trim() || '';
    }

    return el.getAttribute('title')?.trim() || el.textContent?.trim() || '';
  }

  function tryGet(selectorList) {
    // Testa os seletores em ordem de prioridade e retorna o primeiro valor encontrado.
    for (const sel of selectorList || []) {
      for (const root of searchRoots) {
        try {
          const value = readElement(root.querySelector(sel));
          if (value) return value;
        } catch (_) {
          // Ignora seletores indisponiveis ou invalidos na pagina de origem.
        }
      }
    }
    return '';
  }

  function getServiceAideSla() {
    // O SLA do Service Aide pode aparecer dentro de um bloco especifico; quando nao aparecer, usa fallback.
    const root = searchRoots
      .map(searchRoot => searchRoot.querySelector('[data-caid="slaInnerData"]'))
      .find(Boolean);

    if (root?.textContent?.includes('Resolver em')) {
      const dateLabels = Array.from(root.querySelectorAll('label'))
        .map(label => label.textContent?.trim() || '')
        .filter(text => /\d{2}\/\d{2}\/\d{4}/.test(text));

      if (dateLabels.length) return dateLabels[dateLabels.length - 1];
    }

    return tryGet(siteSelectors.slaFallback);
  }

  const data = {};

  Object.entries(siteSelectors).forEach(([key, selectorList]) => {
    // slaFallback e apenas apoio interno para o Service Aide, por isso nao vira campo direto.
    if (key === 'slaFallback') return;
    data[key] = tryGet(selectorList);
  });

  if (site === 'serviceAide') data.sla = getServiceAideSla();

  return data;
}

const tabBtns = document.querySelectorAll('.tab');
const tabContents = document.querySelectorAll('.tab-content');
const settingAtendente = $('settingAtendente');
const settingGroups = $('settingGroups');
const btnSaveSettings = $('btnSaveSettings');
const settingsToast = $('settingsToast');

const sites = Object.fromEntries(
  Object.entries(SITE_DEFINITIONS).map(([key, definition]) => {
    // Converte ids declarados em service-aide.js para referencias reais do DOM.
    const fields = Object.fromEntries(
      Object.entries(definition.fieldIds).map(([field, id]) => [field, $(id)])
    );

    return [key, {
      ...definition,
      fields,
      group: $(definition.groupId),
      maskOutput: $(definition.maskOutputId),
      toast: $(definition.toastId),
    }];
  })
);

tabBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    // Remove o estado ativo de todas as abas e ativa apenas a aba clicada.
    tabBtns.forEach(b => b.classList.remove('active'));
    tabContents.forEach(c => c.classList.remove('active'));
    btn.classList.add('active');
    $('tab-' + btn.dataset.tab).classList.add('active');
  });
});

function showToast(el, msg, type = 'success', duration = 2500) {
  // Exibe mensagens curtas de sucesso, erro ou informacao perto da aba atual.
  el.textContent = msg;
  el.className = `toast show ${type}`;
  setTimeout(() => { el.className = 'toast'; }, duration);
}

function flashField(input) {
  // Reinicia a animacao visual para destacar campos preenchidos pela captura.
  input.classList.remove('captured');
  void input.offsetWidth;
  input.classList.add('captured');
}

function fillDatalist(id, items) {
  // Popula listas de sugestao usadas por campos como tecnico e titulo.
  const datalist = $(id);
  if (!datalist) return;
  datalist.innerHTML = '';

  items.forEach(item => {
    const opt = document.createElement('option');
    opt.value = item;
    datalist.appendChild(opt);
  });
}

function bindAutocomplete({ inputId, listId, items = [] }, site) {
  // Liga um campo de texto a uma lista customizada sem obrigar o usuario a escolher uma opcao.
  const input = $(inputId);
  const list = $(listId);
  if (!input || !list) return;

  let activeIndex = -1;
  let visibleItems = [];

  function normalizeText(value) {
    // Normaliza texto para filtrar sem diferenciar maiusculas, minusculas ou acentos.
    return (value || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLocaleLowerCase('pt-BR');
  }

  function closeList() {
    // Fecha a lista e limpa o indice usado pela navegacao de teclado.
    activeIndex = -1;
    list.classList.remove('open');
    list.innerHTML = '';
  }

  function selectItem(value) {
    // Ao escolher uma opcao, o campo recebe o texto e a mascara e atualizada pelo evento input.
    input.value = value;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    closeList();
  }

  function setActiveOption(nextIndex) {
    // Marca visualmente a opcao ativa quando o usuario navega com as setas.
    const options = Array.from(list.querySelectorAll('.autocomplete-option'));
    if (!options.length) return;

    activeIndex = (nextIndex + options.length) % options.length;
    options.forEach((option, index) => {
      option.classList.toggle('active', index === activeIndex);
    });
    options[activeIndex].scrollIntoView({ block: 'nearest' });
  }

  function renderList() {
    // Mostra todas as opcoes ao clicar no campo e filtra conforme o usuario digita.
    const query = normalizeText(input.value.trim());
    visibleItems = items.filter(item => normalizeText(item).includes(query));
    activeIndex = -1;
    list.innerHTML = '';

    if (!visibleItems.length) {
      closeList();
      return;
    }

    visibleItems.forEach(item => {
      const option = document.createElement('div');
      option.className = 'autocomplete-option';
      option.textContent = item;
      option.addEventListener('mousedown', event => {
        // mousedown evita que o blur do input feche a lista antes da selecao.
        event.preventDefault();
        selectItem(item);
      });
      list.appendChild(option);
    });

    list.classList.add('open');
  }

  input.addEventListener('focus', renderList);
  input.addEventListener('click', renderList);
  input.addEventListener('input', () => {
    // Mesmo sem correspondencia, o valor digitado fica no input e segue para generateMask.
    renderList();
    generateMask(site);
  });
  input.addEventListener('keydown', event => {
    if (!list.classList.contains('open')) return;

    if (event.key === 'ArrowDown') {
      event.preventDefault();
      setActiveOption(activeIndex + 1);
    }

    if (event.key === 'ArrowUp') {
      event.preventDefault();
      setActiveOption(activeIndex - 1);
    }

    if (event.key === 'Enter' && activeIndex >= 0) {
      event.preventDefault();
      selectItem(visibleItems[activeIndex]);
    }

    if (event.key === 'Escape') closeList();
  });

  document.addEventListener('click', event => {
    // Clique fora do autocomplete fecha apenas a lista visual, sem apagar o texto digitado.
    if (!input.contains(event.target) && !list.contains(event.target)) closeList();
  });
}

function getAtendente() {
  // Quando o atendente nao foi configurado, usa '-' para manter a mascara completa.
  return settingAtendente.value.trim() || '-';
}

function generateMask(site) {
  // Gera a mascara do sistema informado usando a regra definida no modulo correspondente.
  const config = sites[site];
  config.maskOutput.value = config.generateMask(config.fields, getAtendente);
}

function generateAllMasks() {
  // Atualiza todas as mascaras quando uma configuracao compartilhada muda.
  Object.keys(sites).forEach(generateMask);
}

function bindMaskUpdates() {
  // Qualquer alteracao manual nos campos recalcula a mascara automaticamente.
  Object.entries(sites).forEach(([site, config]) => {
    [...Object.values(config.fields), config.group].forEach(el => {
      el.addEventListener('input', () => generateMask(site));
      el.addEventListener('change', () => generateMask(site));
    });
  });

  settingAtendente.addEventListener('input', generateAllMasks);
}

function setField(input, value) {
  // Preenche um campo somente quando existe valor capturado e retorna 1 para contagem.
  if (!value) return 0;
  input.value = value;
  flashField(input);
  return 1;
}

function countCapturedValues(data) {
  // Conta quantos valores vieram de um frame para escolher o resultado mais completo.
  if (!data) return 0;

  return Object.values(data)
    .filter(value => typeof value === 'string' && value.trim())
    .length;
}

function getBestCaptureResult(results) {
  // Como a extensao injeta em todos os frames, escolhemos o frame com mais campos preenchidos.
  console.log('RESULTADOS DOS FRAMES:', results);

  return (results || [])
    .map(item => ({
      frameId: item.frameId,
      result: item.result,
      count: countCapturedValues(item.result),
    }))
    .sort((a, b) => b.count - a.count)[0];
}

async function captureSite(site) {
  // Fluxo principal de captura: injeta script, escolhe o melhor frame, aplica dados e gera mascara.
  const config = sites[site];
  const captureButton = document.querySelector(`[data-action="capture"][data-site="${site}"]`);
  const originalHtml = captureButton.innerHTML;

  captureButton.textContent = 'Capturando...';
  captureButton.disabled = true;

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab?.id) {
      showToast(config.toast, 'Nenhuma aba ativa encontrada.', 'error');
      return;
    }

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      func: captureScript,
      args: [site, CAPTURE_SELECTORS],
    });

    const best = getBestCaptureResult(results);
    console.log('FRAME ESCOLHIDO PARA CAPTURA:', best);

    const data = best?.result;
    if (!data) {
      showToast(config.toast, `Nenhum dado capturado para ${config.label}.`, 'error');
      return;
    }

    const capturedCount = config.applyCapture(config, data, setField);
    generateMask(site);

    if (capturedCount === 0) {
      showToast(config.toast, 'Campos nao encontrados. Verifique a pagina.', 'info');
    } else {
      showToast(config.toast, `${capturedCount} campo(s) capturado(s) com sucesso!`, 'success');
    }
  } catch (err) {
    console.error(err);
    showToast(config.toast, 'Erro ao capturar: ' + (err.message || 'desconhecido'), 'error');
  } finally {
    captureButton.innerHTML = originalHtml;
    captureButton.disabled = false;
  }
}

function clearSite(site) {
  // Limpa somente os campos do sistema atual e remove a animacao de captura.
  const config = sites[site];

  Object.values(config.fields).forEach(el => {
    el.value = '';
    el.classList.remove('captured');
  });

  config.group.selectedIndex = 0;
  config.maskOutput.value = '';
  showToast(config.toast, 'Campos limpos.', 'info');
}

async function copySite(site) {
  // Copia a mascara para a area de transferencia, com fallback para navegadores mais restritos.
  const config = sites[site];
  const text = config.maskOutput.value.trim();

  if (!text) {
    showToast(config.toast, 'A mascara esta vazia.', 'info');
    return;
  }

  try {
    await navigator.clipboard.writeText(text);
    showToast(config.toast, 'Mascara copiada!', 'success');
  } catch (_) {
    config.maskOutput.select();
    document.execCommand('copy');
    showToast(config.toast, 'Copiado pelo modo alternativo!', 'success');
  }
}

async function openWhatsApp(site) {
  // Apenas foca uma aba do WhatsApp ja aberta; a extensao nao envia mensagem automaticamente.
  const config = sites[site];
  const text = config.maskOutput.value.trim();

  if (!text) {
    showToast(config.toast, 'Gere a mascara primeiro.', 'info');
    return;
  }

  const tabs = await chrome.tabs.query({
    url: [
      'https://web.whatsapp.com/*',
      'https://api.whatsapp.com/*'
    ]
  });

  if (tabs.length > 0) {
    const waTab = tabs[0];

    await chrome.tabs.update(waTab.id, { active: true });
    await chrome.windows.update(waTab.windowId, { focused: true });
    return;
  }

  return;
}

function bindActions() {
  // Centraliza os cliques dos botoes atraves dos atributos data-action e data-site.
  document.querySelectorAll('[data-action]').forEach(button => {
    button.addEventListener('click', () => {
      const { action, site } = button.dataset;

      if (action === 'capture') captureSite(site);
      if (action === 'clear') clearSite(site);
      if (action === 'copy') copySite(site);
      if (action === 'whatsapp') openWhatsApp(site);
    });
  });
}

function updateServiceGroupDropdown(grupos) {
  // Reconstrui o dropdown do Service Aide a partir das configuracoes salvas.
  const current = sites.serviceAide.group.value;
  sites.serviceAide.group.innerHTML = '<option value="">Selecione o grupo</option>';

  grupos.forEach(g => {
    const group = g.trim();
    if (!group) return;

    const opt = document.createElement('option');
    opt.value = group;
    opt.textContent = group;
    sites.serviceAide.group.appendChild(opt);
  });

  if (current) sites.serviceAide.group.value = current;
}

function loadSettings() {
  // Carrega configuracoes persistidas no storage local da extensao.
  chrome.storage.local.get(['atendente', 'grupos'], data => {
    if (data.atendente) settingAtendente.value = data.atendente;

    const grupos = Array.isArray(data.grupos) && data.grupos.length
      ? data.grupos
      : sites.serviceAide.defaultGroups;

    settingGroups.value = grupos.join('\n');
    updateServiceGroupDropdown(grupos);
    generateAllMasks();
  });
}

btnSaveSettings.addEventListener('click', () => {
  // Salva atendente e grupos configuraveis, depois atualiza a tela imediatamente.
  const atendente = settingAtendente.value.trim();
  const grupos = settingGroups.value
    .split('\n')
    .map(g => g.trim())
    .filter(Boolean);

  chrome.storage.local.set({ atendente, grupos }, () => {
    updateServiceGroupDropdown(grupos);
    generateAllMasks();
    showToast(settingsToast, 'Configuracoes salvas!', 'success');
  });
});

const btnSidePanel = $('btnSidePanel');

if (btnSidePanel) {
  btnSidePanel.addEventListener('click', async () => {
    // Abre o painel lateral da extensao para manter o formulario fixo durante o trabalho.
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.windowId) {
      await chrome.sidePanel.open({ windowId: tab.windowId });
      window.close();
    }
  });
}

Object.values(SITE_DEFINITIONS).forEach(site => {
  // Inicializa todas as listas de sugestao declaradas pelos modulos de site.
  site.datalists?.forEach(({ id, items }) => fillDatalist(id, items));
});

Object.entries(SITE_DEFINITIONS).forEach(([siteKey, site]) => {
  // Inicializa autocompletes customizados declarados pelos modulos de site.
  site.autocompletes?.forEach(config => bindAutocomplete(config, siteKey));
});

// Inicializacao do popup: eventos, configuracoes e primeira geracao das mascaras.
bindMaskUpdates();
bindActions();
loadSettings();
generateAllMasks();
