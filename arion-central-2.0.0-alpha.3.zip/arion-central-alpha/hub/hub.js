/* hub.js — navegação da Central ARION.
 * Cada ferramenta roda na própria página (iframe), carregada só no primeiro
 * clique e mantida viva depois: trocar de ícone não perde o que foi preenchido.
 */
(function () {
  const TOOLS = self.ARION_TOOLS;
  const $ = (id) => document.getElementById(id);
  const stage = $("stage");
  const railList = $("railList");
  const params = new URLSearchParams(location.search);
  const hubMode = params.get("mode") || "panel";
  const frameMode = hubMode === "sidebar" ? "sidebar" : "panel";
  const LAST_KEY = "hub:lastTool";
  let current = "guia";

  // Escapa texto vindo de fora (planilha, páginas, storage) antes de ir para innerHTML.
  const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const svg = (inner) => `<svg viewBox="0 0 24 24" aria-hidden="true">${inner}</svg>`;
  const store = {
    get: (k) => new Promise((r) => { try { chrome.storage.local.get(k, (v) => r(v ? v[k] : undefined)); } catch (_) { r(undefined); } }),
    set: (k, v) => { try { chrome.storage.local.set({ [k]: v }); } catch (_) {} },
  };

  document.documentElement.dataset.mode = hubMode;
  let manifest = {};
  try { manifest = chrome.runtime.getManifest(); } catch (_) {}
  const versao = manifest.version_name || manifest.version || "";
  const ehTeste = /teste|alpha|beta/i.test(versao);
  $("ver").textContent = "v" + versao.replace(/-?(teste|alpha|beta).*$/i, "");
  $("badgeTeste").hidden = !ehTeste;
  $("testeBanner").hidden = true; // Alpha: relatar fica no menu ⋯

  // ---------- Abas (embaixo) ----------
  const CURTO = {
    mascara: "Máscara para o WhatsApp",
    noc: "Categorizar e encaminhar no OTRS",
    chamados: "Preencher no ServiceAide",
    voos: "Planilha, alarmes e informes",
  };
  const ICON_HOME = '<path d="M4 11 12 4l8 7v8a1 1 0 0 1-1 1h-4v-6H9v6H5a1 1 0 0 1-1-1z"/>';
  const ICON_MORE = '<circle cx="5" cy="12" r="1.3" fill="currentColor"/><circle cx="12" cy="12" r="1.3" fill="currentColor"/><circle cx="19" cy="12" r="1.3" fill="currentColor"/>';
  const ICON_GO = '<path d="M9 6l6 6-6 6"/>';

  const homeBtn = document.createElement("button");
  homeBtn.className = "rail-btn";
  homeBtn.dataset.tool = "guia";
  homeBtn.setAttribute("role", "tab");
  homeBtn.title = "Início (Alt+1)";
  homeBtn.innerHTML = svg(ICON_HOME) + "<span>Início</span>";
  railList.appendChild(homeBtn);

  TOOLS.forEach((t, i) => {
    const b = document.createElement("button");
    b.className = "rail-btn";
    b.dataset.tool = t.id;
    b.setAttribute("role", "tab");
    b.title = `${t.nome} (Alt+${i + 2})`;
    b.innerHTML = svg(t.icon) + `<span>${t.curto}</span><i class="dot" aria-hidden="true"></i>`;
    railList.appendChild(b);
  });

  const moreBtn = $("btnMore");

  document.querySelectorAll(".rail-btn[data-tool]").forEach((b) =>
    b.addEventListener("click", () => show(b.dataset.tool))
  );

  // ---------- Menu ⋯ ----------
  const menu = $("menu");
  function closeMenu() { menu.hidden = true; moreBtn.classList.remove("open"); }
  moreBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    menu.hidden = !menu.hidden;
    moreBtn.classList.toggle("open", !menu.hidden);
  });
  document.addEventListener("click", (e) => { if (!menu.hidden && !menu.contains(e.target)) closeMenu(); });
  menu.addEventListener("click", (e) => { if (e.target.closest(".mi")) setTimeout(closeMenu, 0); });

  // ---------- Início: lista de ferramentas ----------
  $("cards").innerHTML = TOOLS.map((t) => `
    <button class="tool" data-open="${t.id}" type="button">
      <span class="tool-ic">${svg(t.icon)}</span>
      <span class="tool-tx"><b>${t.curto}</b><small data-sub="${t.id}">${CURTO[t.id] || ""}</small></span>
      <span class="tool-tag" hidden>Sugerida</span>
      <span class="tool-go">${svg(ICON_GO)}</span>
    </button>`).join("");
  document.querySelectorAll("[data-open]").forEach((b) =>
    b.addEventListener("click", () => show(b.dataset.open))
  );

  // ---------- Troca de ferramenta ----------
  function ensureFrame(t) {
    let view = document.querySelector(`.view[data-view="${t.id}"]`);
    if (view) return view;
    view = document.createElement("section");
    view.className = "view tool-view";
    view.dataset.view = t.id;
    view.hidden = true;
    const f = document.createElement("iframe");
    f.title = t.nome;
    f.setAttribute("allow", "clipboard-read; clipboard-write");
    f.src = `${t.page}?mode=${frameMode}`;
    view.appendChild(f);
    stage.appendChild(view);
    return view;
  }

  function show(id) {
    const t = TOOLS.find((x) => x.id === id);
    if (!t) id = "guia";
    current = id;
    if (t) ensureFrame(t);
    document.querySelectorAll(".view").forEach((v) => (v.hidden = v.dataset.view !== id));
    document.querySelectorAll(".rail-btn").forEach((b) => {
      const on = b.dataset.tool === id;
      b.classList.toggle("active", on);
      b.setAttribute("aria-selected", on);
    });
    document.documentElement.style.setProperty("--active-c", t ? t.cor : "#3a3a3a");
    if (id === "voos") clearAlarmDot();
    closeDrawer();
    store.set(LAST_KEY, id);
    if (t) {
      const f = document.querySelector(`.view[data-view="${id}"] iframe`);
      setTimeout(() => f && f.focus(), 30);
    }
  }

  // ---------- Atalhos ----------
  function onKey(e) {
    if (e.altKey && !e.shiftKey && /^[1-5]$/.test(e.key)) {
      e.preventDefault();
      show(["guia", ...TOOLS.map((t) => t.id)][Number(e.key) - 1]);
    } else if (e.key === "Escape") {
      closeDrawer();
      closeMenu();
    }
  }
  document.addEventListener("keydown", onKey);
  // Repassa os atalhos também quando o foco está dentro de uma ferramenta.
  stage.addEventListener("load", (e) => {
    try { e.target.contentWindow.addEventListener("keydown", onKey); } catch (_) {}
  }, true);

  // ---------- Ajuda contextual (?) ----------
  const drawer = $("drawer");
  function openDrawer() {
    const t = TOOLS.find((x) => x.id === current);
    if (!t) {
      $("drawerBody").innerHTML = `
        <div class="drawer-head"><div class="tool-ic">${svg(ICON_HOME)}</div><h3>Como usar</h3><button class="drawer-x" aria-label="Fechar">✕</button></div>
        <p class="card-goal">A ferramenta da aba aberta aparece como <b style="display:inline">Sugerida</b>. <kbd>Alt</kbd>+<kbd>1</kbd>…<kbd>5</kbd> troca de aba.</p>
        ${TOOLS.map((x) => `<details class="help-tool"><summary><span class="tool-ic">${svg(x.icon)}</span>${x.nome}</summary>
          <p class="card-goal"><b>Objetivo</b> ${x.objetivo}</p><p class="drawer-where"><b>Onde usar</b> ${x.onde.join(" · ")}</p>
          <ol>${x.passos.map((p) => `<li>${p}</li>`).join("")}</ol></details>`).join("")}`;
      drawer.hidden = false;
      drawer.querySelector(".drawer-x").onclick = closeDrawer;
      return;
    }
    $("drawerBody").innerHTML = `
      <div class="drawer-head">
        <div class="tool-ic">${svg(t.icon)}</div>
        <h3>${t.nome}</h3>
        <button class="drawer-x" aria-label="Fechar">✕</button>
      </div>
      <p class="card-goal"><b>Objetivo</b> ${t.objetivo}</p>
      <p class="drawer-where"><b>Onde usar</b> ${t.onde.join(" · ")}</p>
      <ol>${t.passos.map((p) => `<li>${p}</li>`).join("")}</ol>`;
    $("drawerBody").style.setProperty("--c", t.cor);
    drawer.hidden = false;
    drawer.querySelector(".drawer-x").onclick = closeDrawer;
  }
  function closeDrawer() { drawer.hidden = true; }
  $("btnHelp").addEventListener("click", () => (drawer.hidden ? openDrawer() : closeDrawer()));
  drawer.addEventListener("click", (e) => { if (e.target === drawer) closeDrawer(); });

  $("btnTab").addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("hub/index.html?mode=tab") });
  });
  if (hubMode === "tab") $("btnTab").hidden = true;

  // ---------- Bandeja ⇄ Lateral ----------
  // Bandeja = popup que abre no ícone ARION (fecha ao clicar fora).
  // Lateral = painel fixo ao lado da página (não fecha ao trocar de foco).
  const VIEW_KEY = "hub:viewMode";
  const sidebarApi = (typeof browser !== "undefined" && browser.sidebarAction) || chrome.sidebarAction || null;
  const btnMode = $("btnMode");
  const isTray = hubMode === "popup";
  const ICON_PIN = '<path d="M9 4h6l-1 5 3 3v2H7v-2l3-3z"/><path d="M12 14v6"/>';
  const ICON_TRAY = '<rect x="3.5" y="4" width="17" height="16" rx="2"/><path d="M3.5 9h17M8 13.5h8"/>';
  let windowId = null;
  try { chrome.windows.getCurrent((w) => { windowId = w && w.id; }); } catch (_) {}

  if (hubMode === "tab") btnMode.hidden = true;
  btnMode.innerHTML = isTray
    ? svg(ICON_PIN) + "<span>Fixar na lateral</span>"
    : svg(ICON_TRAY) + "<span>Mudar para bandeja</span>";
  btnMode.title = isTray
    ? "Fixar na lateral — o painel fica aberto ao lado da página"
    : "Mudar para bandeja — abre como janelinha no ícone ARION";

  function modeMsg(text) {
    const m = document.createElement("div");
    m.className = "mode-msg";
    m.innerHTML = text;
    document.querySelector(".shell").appendChild(m);
  }

  btnMode.addEventListener("click", async () => {
    if (isTray) {
      // Bandeja → Lateral: abre o painel ainda dentro do clique (exige gesto do usuário).
      let opened = null;
      try {
        if (chrome.sidePanel && chrome.sidePanel.open && windowId != null) opened = chrome.sidePanel.open({ windowId });
        else if (sidebarApi) opened = sidebarApi.open();
      } catch (_) {}
      chrome.storage.local.set({ [VIEW_KEY]: "lateral" });
      try { await chrome.runtime.sendMessage({ type: "SET_VIEW_MODE", mode: "lateral" }); } catch (_) {}
      try { await opened; } catch (_) {}
      window.close();
      return;
    }
    // Lateral → Bandeja
    try { await chrome.runtime.sendMessage({ type: "SET_VIEW_MODE", mode: "bandeja" }); }
    catch (_) { chrome.storage.local.set({ [VIEW_KEY]: "bandeja" }); }
    let popupOk = false;
    try { if (chrome.action.openPopup) { await chrome.action.openPopup(); popupOk = true; } } catch (_) {}
    if (!popupOk) {
      modeMsg("<b>Modo bandeja ativado.</b><br>Clique no ícone ARION na barra do navegador para abrir.");
      await new Promise((r) => setTimeout(r, 2200));
    }
    try {
      if (chrome.sidePanel && chrome.sidePanel.close && windowId != null) await chrome.sidePanel.close({ windowId });
      else if (sidebarApi && hubMode === "sidebar") await sidebarApi.close();
    } catch (_) {}
    window.close();
  });

  // ---------- Site detectado na aba ativa ----------
  async function detect() {
    let url = "";
    try {
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      url = (tab && tab.url) || "";
    } catch (_) {}
    let host = "";
    try { host = new URL(url).hostname; } catch (_) {}
    const hits = TOOLS.filter((t) => host && t.hosts.some((re) => re.test(host)));
    const sug = (id) => hits.some((t) => t.id === id);
    document.querySelectorAll(".rail-btn").forEach((b) => b.classList.toggle("suggested", sug(b.dataset.tool)));
    // Início: a ferramenta da aba aberta sobe para o topo, marcada como Sugerida.
    const lista = $("cards");
    [...lista.querySelectorAll(".tool")].forEach((c) => {
      const on = sug(c.dataset.open);
      c.classList.toggle("sug", on);
      c.querySelector(".tool-tag").hidden = !on;
      c.querySelector(".tool-go").hidden = on;
    });
    TOOLS.slice().reverse().forEach((t) => { if (sug(t.id)) lista.prepend(lista.querySelector(`[data-open="${t.id}"]`)); });
    TOOLS.forEach((t) => { if (!sug(t.id)) lista.appendChild(lista.querySelector(`[data-open="${t.id}"]`)); });
    const box = $("detected");
    if (!hits.length) { box.hidden = true; return; }
    box.hidden = false;
    box.innerHTML = `<span class="pulse"></span><span>Aba atual:</span> <b>${esc(host)}</b>`;
  }
  try {
    chrome.tabs.onActivated.addListener(detect);
    chrome.tabs.onUpdated.addListener((_id, info, tab) => { if (tab.active && (info.url || info.status === "complete")) detect(); });
    chrome.windows && chrome.windows.onFocusChanged && chrome.windows.onFocusChanged.addListener(detect);
  } catch (_) {}
  detect();

  // ---------- Alarmes da Central de Voos ----------
  const toast = $("alarmToast");
  function clearAlarmDot() {
    const b = document.querySelector('.rail-btn[data-tool="voos"]');
    b && b.classList.remove("alarm");
  }
  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg || msg.type !== "ALARM_FIRED") return;
    const b = document.querySelector('.rail-btn[data-tool="voos"]');
    // Com a Central de Voos na tela, o próprio módulo mostra o card do alarme.
    if (current === "voos") return;
    b && b.classList.add("alarm");
    toast.innerHTML = `
      <div class="toast-title">✈ ${esc(msg.title || "Alarme de voo")}</div>
      <div class="toast-msg">${esc(msg.message).replace(/\n+/g, "<br>")}</div>
      <div class="toast-actions">
        <button data-a="open">Abrir Voos</button>
        <button data-a="SNOOZE_ALARM">Adiar 5 min</button>
        <button data-a="DISMISS_ALARM">Desativar</button>
      </div>`;
    toast.hidden = false;
    toast.querySelectorAll("button").forEach((btn) =>
      btn.addEventListener("click", () => {
        const a = btn.dataset.a;
        if (a === "open") show("voos");
        else chrome.runtime.sendMessage({ type: a, alarmId: String(msg.alarmId || "") }).catch(() => {});
        if (a !== "open") clearAlarmDot();
        toast.hidden = true;
      })
    );
  });

  // ---------- Tema único (claro/escuro) ----------
  // Grava a chave comum e as chaves antigas de cada ferramenta, para todas abrirem iguais.
  const themeLabel = () => ($("themeLabel").textContent = document.documentElement.getAttribute("data-theme") === "dark" ? "Tema claro" : "Tema escuro");
  themeLabel();
  new MutationObserver(themeLabel).observe(document.documentElement, { attributes: true, attributeFilter: ["data-theme"] });
  $("btnTheme").addEventListener("click", () => {
    const novo = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
    try { chrome.storage.local.set({ "arion:tema": novo, tema: novo, theme: novo }); } catch (_) {}
  });

  // ---------- Novidades ----------
  const LOG = self.ARION_CHANGELOG || [];
  $("changelog").innerHTML = LOG.slice(0, 4).map((v) =>
    `<li><b>${esc(v.versao)}</b><ul>${v.itens.map((i) => `<li>${esc(i)}</li>`).join("")}</ul></li>`
  ).join("");
  if (LOG[0]) {
    $("novTit").textContent = "Novidades da " + LOG[0].versao;
    $("novResumo").textContent = LOG[0].resumo || LOG[0].itens.slice(0, 3).map((i) => i.replace(/\.$/, "")).join(" · ");
  }
  $("btnNov").addEventListener("click", () => {
    const abrir = $("changelog").hidden;
    $("changelog").hidden = !abrir;
    $("novResumo").hidden = abrir;
    $("btnNov").textContent = abrir ? "Resumo" : "Ver tudo";
  });
  $("btnUpd2").addEventListener("click", () => { show("guia"); $("foldUpd").open = true; $("updUrl").focus(); });

  // ---------- Relatar problema (versão de teste) ----------
  $("btnDiag").addEventListener("click", async () => {
    const tudo = await new Promise((r) => { try { chrome.storage.local.get(null, r); } catch (_) { r({}); } });
    const info = [
      "Central ARION — relato de teste",
      "Versão: " + versao,
      "Data: " + new Date().toLocaleString("pt-BR"),
      "Navegador: " + navigator.userAgent,
      "Modo: " + hubMode + " · Ferramenta aberta: " + current,
      "Tema: " + (document.documentElement.getAttribute("data-theme") || "light"),
      "Chamados NOC guardados: " + Object.keys(tudo).filter((k) => k.startsWith("tk_")).length,
      "Planilha de voos: " + (tudo.importedFileName ? "carregada" : "não carregada"),
      "",
      "O que aconteceu:",
      "",
      "O que era esperado:",
      "",
    ].join("\n");
    try { await navigator.clipboard.writeText(info); $("btnDiag").textContent = "Copiado — cole no seu relato"; }
    catch (_) { $("btnDiag").textContent = "Não foi possível copiar"; }
    setTimeout(() => ($("btnDiag").textContent = "Relatar problema"), 2500);
  });
  // Mesmas ações pelo menu ⋯
  $("btnDiag2").addEventListener("click", () => { show("guia"); $("btnDiag").click(); });
  $("btnClean2").addEventListener("click", () => { show("guia"); $("foldUpd").open = true; $("btnClean").click(); });

  // ---------- Limpeza manual ----------
  $("btnClean").addEventListener("click", async () => {
    try {
      const r = await chrome.runtime.sendMessage({ type: "LIMPAR_DADOS_ANTIGOS" });
      $("btnClean").textContent = `Feito (${(r && r.removidos) || 0} itens antigos removidos)`;
    } catch (_) { $("btnClean").textContent = "Falhou — tente de novo"; }
  });

  // ---------- Aviso de versão nova (intranet) ----------
  // versao.json esperado: { "versao": "1.3.1", "download": "https://… ou \\servidor\pasta", "notas": "…" }
  const UPD_KEY = "hub:updUrl";
  const cmp = (a, b) => {
    const pa = String(a).match(/\d+/g) || [], pb = String(b).match(/\d+/g) || [];
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      const d = (+pa[i] || 0) - (+pb[i] || 0);
      if (d) return d;
    }
    return 0;
  };
  // A verificação roda no background (a cada 6 h). Aqui só mostra o resultado.
  const UPD_PADRAO = "https://raw.githubusercontent.com/ThiagoTasseli/central-servicos/alpha/versao.json";
  function mostrarAtualizacao(info) {
    const st = $("updStatus"), ban = $("updateBanner");
    if (!info) return;
    const quando = new Date(info.ts).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });
    if (info.nova) {
      ban.hidden = false;
      ban.innerHTML = `<b>Versão ${esc(info.nome || info.versao)} disponível.</b> ${esc(info.notas || "")}` +
        `<div class="upd-acts"><button class="a-chip" id="btnBaixar" type="button">Baixar</button>` +
        `<span>Extraia na mesma pasta e recarregue em chrome://extensions.</span></div>`;
      $("btnBaixar").onclick = () => chrome.runtime.sendMessage({ type: "BAIXAR_ATUALIZACAO" });
      const g = document.querySelector('.rail-btn[data-tool="guia"]');
      g && g.classList.add("suggested");
      st.textContent = `Há versão nova. Verificado em ${quando}.`;
    } else {
      ban.hidden = true;
      st.textContent = `Você está na versão mais recente. Verificado em ${quando}.`;
    }
  }
  store.get("upd:info").then(mostrarAtualizacao);
  try {
    chrome.storage.onChanged.addListener((ch, area) => { if (area === "local" && ch["upd:info"]) mostrarAtualizacao(ch["upd:info"].newValue); });
  } catch (_) {}
  store.get(UPD_KEY).then((u) => { $("updUrl").value = u || UPD_PADRAO; });
  $("btnUpd").addEventListener("click", async () => {
    const url = $("updUrl").value.trim();
    store.set(UPD_KEY, url === UPD_PADRAO ? "" : url);
    if (url && url !== UPD_PADRAO && /^https?:/i.test(url) && chrome.permissions) {
      // Outro servidor: pede acesso só a ele (permissão opcional).
      try {
        const origin = new URL(url).origin + "/*";
        const ok = await chrome.permissions.request({ origins: [origin] });
        if (!ok) { $("updStatus").textContent = "Acesso ao servidor negado."; return; }
      } catch (_) {}
    }
    $("updStatus").textContent = "Verificando…";
    const r = await chrome.runtime.sendMessage({ type: "VERIFICAR_ATUALIZACAO", manual: true }).catch(() => null);
    if (!r || !r.ok) $("updStatus").textContent = "Não foi possível ler o arquivo de versão. " + ((r && r.erro) || "");
  });

  // ---------- Voos: próximo alarme no cartão do Início ----------
  async function proximoAlarme() {
    const el = document.querySelector('[data-sub="voos"]');
    if (!el) return;
    try {
      const todos = await chrome.alarms.getAll();
      const prox = todos.filter((a) => /^(flight|custom)-alert::/.test(a.name) && a.scheduledTime > Date.now())
        .sort((a, b) => a.scheduledTime - b.scheduledTime)[0];
      el.textContent = prox
        ? "Próximo alarme " + new Date(prox.scheduledTime).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })
        : CURTO.voos;
    } catch (_) {}
  }
  proximoAlarme();
  setInterval(proximoAlarme, 30000);

  // ---------- Início ----------
  store.get(LAST_KEY).then((last) => show(last || "guia"));
})();
