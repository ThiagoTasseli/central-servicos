/* ARION · Central de Ferramentas — background único.
 * Junta o background das extensões:
 *   - Máscara de Chamado (não tinha background)
 *   - NOC Atacado / Preenchimento de Chamados (só abriam o painel lateral)
 *   - Central de Voos (alarmes, notificações e som)
 * O clique no ícone abre o painel lateral (Chrome/Edge) ou a barra lateral (Firefox).
 */
// importScripts só existe dentro de um service worker (Chrome/Edge). No
// Firefox, os mesmos módulos já são carregados via "background.scripts" no
// manifest, então este bloco é ignorado lá.
if (typeof importScripts === "function") {
  importScripts(
    "apps/voos/modules/formatters.js",
    "apps/voos/modules/templates.js",
    "apps/voos/modules/storage.js",
    "apps/voos/modules/spreadsheet.js", // só as partes que não dependem de XLSX/File são usadas aqui (filterFlights)
    "apps/voos/modules/alarms.js",
    "sounds/sons.js"
  );
}

const { todayISO } = self.Fmt;
const { filterFlights } = self.Spreadsheet;
const {
  computeAlarmEntries,
  futureAlarmEntries,
  parseAlarmName,
  ALARM_PREFIX,
  CUSTOM_PREFIX,
  TIPO_LABEL,
  customAlarmName,
  parseCustomAlarmName,
  customFireTimestamp,
} = self.Alarms;
const Storage = self.Storage;

// ---------- Modo de exibição: BANDEJA (popup) ou LATERAL (painel fixo) ----------
// O usuário escolhe pelo botão no trilho da Central. A escolha fica salva em
// "hub:viewMode" ("lateral" | "bandeja") e vale para o clique no ícone ARION.
//  - Lateral: Chrome/Edge abrem o side panel; Firefox abre/fecha a barra lateral.
//  - Bandeja: o ícone abre o popup (fecha ao clicar fora).
const VIEW_KEY = "hub:viewMode";
const POPUP_URL = "hub/index.html?mode=popup";
const ffSidebar =
  (typeof browser !== "undefined" && browser.sidebarAction) || chrome.sidebarAction || null;
let currentViewMode = "lateral";

async function applyViewMode(mode) {
  currentViewMode = mode === "bandeja" ? "bandeja" : "lateral";
  const bandeja = currentViewMode === "bandeja";
  try { await chrome.action.setPopup({ popup: bandeja ? POPUP_URL : "" }); } catch (_) {}
  if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: !bandeja }).catch((err) => {
      console.error("Falha ao configurar o side panel:", err);
    });
  }
}

// Firefox: sem popup definido, o clique chega aqui e abre/fecha a barra lateral.
if (!chrome.sidePanel && ffSidebar) {
  chrome.action.onClicked.addListener(() => {
    // toggle() precisa ser chamado direto no clique (gesto do usuário)
    if (currentViewMode === "lateral") ffSidebar.toggle();
  });
}

chrome.storage.local.get(VIEW_KEY).then((v) => applyViewMode(v[VIEW_KEY]));
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && changes[VIEW_KEY]) applyViewMode(changes[VIEW_KEY].newValue);
});

chrome.runtime.onInstalled.addListener(() => rescheduleFromStorage());
chrome.runtime.onStartup.addListener(() => rescheduleFromStorage());

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "SET_VIEW_MODE") {
    chrome.storage.local
      .set({ [VIEW_KEY]: message.mode })
      .then(() => applyViewMode(message.mode))
      .then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message.type === "RESCHEDULE_ALARMS") {
    rescheduleFromStorage().then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message.type === "CLEAR_ALARMS") {
    clearAllAlarms().then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message.type === "SNOOZE_ALARM") {
    snoozeAlarm(message.alarmId).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message.type === "SET_MUTE") {
    Storage.setMuteUntil(message.muteUntil).then(async () => {
      if (Storage.isMutedValue(Number(message.muteUntil))) stopSound();
      sendResponse({ ok: true });
    });
    return true;
  }
  if (message.type === "STOP_SOUND") {
    stopSound();
    sendResponse({ ok: true });
    return false;
  }
  if (message.type === "TEST_SOUND") {
    playSound(message.soundId).then(() => {
      setTimeout(stopSound, 3000);
      sendResponse({ ok: true });
    });
    return true;
  }
  if (message.type === "DISMISS_ALARM") {
    dismissAlarm(message.alarmId).then(() => sendResponse({ ok: true }));
    return true;
  }
});

/**
 * Recalcula os voos filtrados (data selecionada) a partir das linhas cruas
 * salvas no storage e reagenda os alarmes de acordo com os minutos de
 * antecedência configurados na aba Alarme.
 *
 * Chamado ao instalar/iniciar o navegador, e sempre que o popup avisa que
 * a planilha, a data selecionada ou os minutos de alerta mudaram.
 */
async function rescheduleFromStorage() {
  await Storage.migrateLegacyRawRows();
  const selectedDate = await Storage.getSelectedDate();
  const [dayRows, alarmSettings, overrides] = await Promise.all([
    Storage.getFlightsForDate(selectedDate),
    Storage.getAlarmSettings(),
    Storage.getAlarmOverrides(),
  ]);

  const flights = filterFlights(dayRows, selectedDate);
  await scheduleAlarms(flights, alarmSettings, overrides);
  await scheduleCustomAlarms();
}

/** Recria os alarmes próprios (tarefas e lembretes). Não dependem da planilha. */
async function scheduleCustomAlarms() {
  const all = await chrome.alarms.getAll();
  await Promise.all(all.filter((a) => a.name.startsWith(CUSTOM_PREFIX)).map((a) => chrome.alarms.clear(a.name)));
  const list = await Storage.getCustomAlarms();
  for (const alarm of list) {
    const when = customFireTimestamp(alarm);
    if (when) chrome.alarms.create(customAlarmName(alarm.id), { when });
  }
}

async function clearAllAlarms() {
  const alarms = await chrome.alarms.getAll();
  await Promise.all(
    alarms.filter((a) => a.name.startsWith(ALARM_PREFIX)).map((a) => chrome.alarms.clear(a.name))
  );
}

/**
 * Cancela e recria TODOS os alarmes de voo a partir do zero — mais simples
 * e seguro do que tentar reconciliar incrementalmente, e evita alarmes
 * duplicados quando a planilha, a data ou os minutos de alerta mudam.
 * Só agenda (som + notificação) para horários de alarme ainda no futuro.
 */
async function scheduleAlarms(flights, alarmSettings, overrides) {
  await clearAllAlarms();
  const entries = computeAlarmEntries(flights, alarmSettings, overrides);
  const future = futureAlarmEntries(entries);
  for (const entry of future) {
    chrome.alarms.create(entry.id, { when: entry.alarmeTimestamp });
  }
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  const customId = parseCustomAlarmName(alarm.name);
  if (customId) return fireCustomAlarm(alarm.name, customId);
  const parsed = parseAlarmName(alarm.name);
  if (!parsed) return;
  const { flightId, kind } = parsed;

  const selectedDate = await Storage.getSelectedDate();
  const dayRows = await Storage.getFlightsForDate(selectedDate);
  const flights = filterFlights(dayRows, selectedDate);
  const flight = flights.find((f) => f.id === flightId);
  if (!flight) return;

  const isInspecao = kind === "inspecao";
  const horarioEvento = isInspecao ? flight.inspecaoTime : flight.acompanhamentoTime;
  const companhia = String(flight.empresa || "").toUpperCase();
  const numeroVoo = flight.numeroVoo || "";

  const title = isInspecao
    ? `ALERTA: INSPEÇÃO - Voo ${companhia} ${numeroVoo}`.trim()
    : `ALERTA: ACOMPANHAMENTO - Voo ${companhia} ${numeroVoo}`.trim();

  const message =
    `O horário do evento está se aproximando.\n\n` +
    `Partida: ${flight.horarioVoo}\n` +
    `Evento: ${horarioEvento}`;

  const muted = await Storage.isMuted();

  // Botões / requireInteraction / silent só existem no Chrome/Edge — o
  // Firefox recusa a notificação inteira se receber essas opções.
  const isChromium = !!chrome.offscreen;
  const notifOptions = { type: "basic", iconUrl: "icons/icon128.png", title, message };
  if (isChromium) {
    Object.assign(notifOptions, {
      priority: 2,
      requireInteraction: true,
      buttons: [{ title: "Adiar 5 min" }, { title: "Desativar" }],
      ...(muted ? { silent: true } : {}),
    });
  }
  try {
    await chrome.notifications.create(alarm.name, notifOptions);
  } catch (err) {
    console.error("Falha ao criar notificação:", err);
  }

  // Silenciado: só a notificação visual (e o card no painel), sem som.
  if (!muted) playSound();

  // Além da notificação do SO, avisa o painel (side panel) — se estiver
  // aberto — pra mostrar ali também um card com os mesmos botões. Se não
  // houver painel aberto pra receber, sendMessage rejeita e é ignorado.
  chrome.runtime.sendMessage({ type: "ALARM_FIRED", alarmId: alarm.name, title, message, muted }).catch(() => {});
});

/** Notificação + som + card no painel — usado pelos alarmes próprios. */
async function notifyAlarm(alarmName, title, message) {
  const muted = await Storage.isMuted();
  const isChromium = !!chrome.offscreen;
  const notifOptions = { type: "basic", iconUrl: "icons/icon128.png", title, message };
  if (isChromium) {
    Object.assign(notifOptions, {
      priority: 2,
      requireInteraction: true,
      buttons: [{ title: "Adiar 5 min" }, { title: "Desativar" }],
      ...(muted ? { silent: true } : {}),
    });
  }
  try {
    await chrome.notifications.create(alarmName, notifOptions);
  } catch (err) {
    console.error("Falha ao criar notificação:", err);
  }
  if (!muted) playSound();
  chrome.runtime.sendMessage({ type: "ALARM_FIRED", alarmId: alarmName, title, message, muted }).catch(() => {});
}

async function fireCustomAlarm(alarmName, id) {
  const list = await Storage.getCustomAlarms();
  const item = list.find((a) => a.id === id);
  if (!item) return;
  const tipo = (TIPO_LABEL[item.tipo] || "Alarme").toUpperCase();
  const title = `${tipo}: ${item.titulo}`;
  const message = [`Horário: ${item.hhmm}`, item.obs].filter(Boolean).join("\n");

  // Disparou: limpa adiamento; "uma vez" desliga (como despertador do celular).
  const patch = { snoozeUntil: 0 };
  if (!item.repetir || item.repetir === "nao") patch.enabled = false;
  await Storage.upsertCustomAlarm({ ...item, ...patch });
  await scheduleCustomAlarms(); // próximo dia, se repetir

  await notifyAlarm(alarmName, title, message);
}

// O som toca em loop (ver offscreen.html/offscreen.js) até o usuário adiar
// ou desativar o alarme — pelos botões da notificação OU pelo card no
// painel — nunca para sozinho.
const SNOOZE_MS = 5 * 60 * 1000;

async function snoozeAlarm(alarmId) {
  if (!alarmId) return;
  stopSound();
  chrome.notifications.clear(alarmId);
  const customId = parseCustomAlarmName(alarmId);
  if (customId) {
    // Guarda o adiamento, para sobreviver a um reagendamento.
    const item = (await Storage.getCustomAlarms()).find((a) => a.id === customId);
    if (item) await Storage.upsertCustomAlarm({ ...item, snoozeUntil: Date.now() + SNOOZE_MS });
    return scheduleCustomAlarms();
  }
  // Dispara de novo em alguns minutos, sem alterar o horário salvo do alarme.
  chrome.alarms.create(alarmId, { when: Date.now() + SNOOZE_MS });
}

async function dismissAlarm(alarmId) {
  if (!alarmId) return;
  stopSound();
  chrome.notifications.clear(alarmId);
  const customId = parseCustomAlarmName(alarmId);
  if (customId) {
    // Repetidos continuam valendo nos próximos dias; só cancela o adiamento.
    const item = (await Storage.getCustomAlarms()).find((a) => a.id === customId);
    if (item) {
      const patch = { snoozeUntil: 0 };
      if (!item.repetir || item.repetir === "nao") patch.enabled = false;
      await Storage.upsertCustomAlarm({ ...item, ...patch });
    }
    return scheduleCustomAlarms();
  }
  // Mesmo efeito de desligar o alarme na aba Despertar.
  await Storage.setAlarmOverride(alarmId, { enabled: false });
}

chrome.notifications.onButtonClicked?.addListener(async (notificationId, buttonIndex) => {
  const parsed = parseAlarmName(notificationId) || parseCustomAlarmName(notificationId);
  if (!parsed) return;

  if (buttonIndex === 0) {
    await snoozeAlarm(notificationId);
  } else if (buttonIndex === 1) {
    await dismissAlarm(notificationId);
  }
});

// ---------- Offscreen document para som ----------
// chrome.offscreen só existe no Chrome/Edge (service worker não tem acesso
// a <audio>). No Firefox, o background roda como event page com DOM
// completo, então tocamos o som direto por aqui, sem documento offscreen.
let creatingOffscreen;
let firefoxAudio;

async function ensureOffscreenDocument() {
  const existing = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
  });
  if (existing.length > 0) return;

  if (creatingOffscreen) {
    await creatingOffscreen;
    return;
  }

  creatingOffscreen = chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: ["AUDIO_PLAYBACK"],
    justification: "Tocar sinal sonoro de alerta de voo.",
  });
  await creatingOffscreen;
  creatingOffscreen = null;
}

async function resolveSoundFile(soundId) {
  const lista = self.ARION_SONS || [];
  const id = soundId || (await Storage.getAlarmSound());
  const achado = lista.find((x) => x.id === id) || lista[0];
  return achado ? achado.arquivo : "sounds/classico.wav";
}

async function playSound(soundId) {
  try {
    const src = await resolveSoundFile(soundId);
    if (chrome.offscreen) {
      await ensureOffscreenDocument();
      // pequena margem de segurança: garante que o listener do offscreen já
      // está registrado antes de mandar a mensagem.
      chrome.runtime.sendMessage({ type: "PLAY_ALERT_SOUND", src }).catch(() => {});
    } else {
      if (firefoxAudio) firefoxAudio.pause();
      firefoxAudio = new Audio(src);
      firefoxAudio.loop = true;
      firefoxAudio.play().catch((err) => console.error("Erro ao tocar som:", err));
    }
  } catch (err) {
    console.error("Não foi possível tocar o som de alerta:", err);
  }
}

function stopSound() {
  if (chrome.offscreen) {
    chrome.runtime.sendMessage({ type: "STOP_ALERT_SOUND" }).catch(() => {});
  } else if (firefoxAudio) {
    firefoxAudio.pause();
    firefoxAudio.currentTime = 0;
  }
}


// ---------- Limpeza automática de dados pessoais (LGPD) ----------
// Chamados do NOC (tk_*) e o formulário do Preenchimento guardam nome,
// e-mail e telefone de solicitantes. Tudo que passou de 7 dias é apagado.
// Roda ao iniciar o navegador e uma vez por dia.
const RETENCAO_MS = 7 * 24 * 60 * 60 * 1000;
const LIMPEZA_ALARM = "arion:limpeza";

async function limparDadosAntigos() {
  const tudo = await chrome.storage.local.get(null);
  const limite = Date.now() - RETENCAO_MS;
  const remover = [];
  for (const [k, v] of Object.entries(tudo)) {
    if (k.startsWith("tk_") && !(v && v.ts > limite)) remover.push(k);
  }
  if (tudo.form && !(tudo.formTs > limite)) remover.push("form", "formTs");
  if (tudo.nomeLoc && !(tudo.nomeLoc.ts > limite)) remover.push("nomeLoc");
  if (remover.length) await chrome.storage.local.remove(remover);
  await chrome.storage.local.set({ "hub:ultimaLimpeza": Date.now() });
  return remover.length;
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(LIMPEZA_ALARM, { delayInMinutes: 1, periodInMinutes: 24 * 60 });
});
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(LIMPEZA_ALARM, { delayInMinutes: 1, periodInMinutes: 24 * 60 });
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === LIMPEZA_ALARM) limparDadosAntigos().catch(() => {});
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message && message.type === "LIMPAR_DADOS_ANTIGOS") {
    limparDadosAntigos().then((n) => sendResponse({ ok: true, removidos: n }));
    return true;
  }
});

// ---------- Aviso de versão nova (GitHub) ----------
// Lê um versao.json publicado no repositório a cada 6 horas (e ao abrir o navegador).
// Versão maior que a instalada: selo no ícone + notificação + aviso no Início.
// A extensão não se troca sozinha: a pessoa baixa o zip e recarrega.
const UPD_PADRAO = "https://raw.githubusercontent.com/ThiagoTasseli/central-servicos/alpha/versao.json";
const UPD_ALARM = "arion:atualizacao";
const UPD_NOTIF = "arion:nova-versao";

function cmpVersao(a, b) {
  const pa = String(a).match(/\d+/g) || [], pb = String(b).match(/\d+/g) || [];
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (+pa[i] || 0) - (+pb[i] || 0);
    if (d) return d;
  }
  return 0;
}

async function verificarAtualizacao(manual = false) {
  const st = await chrome.storage.local.get(["hub:updUrl", "upd:info"]);
  const url = (st["hub:updUrl"] || "").trim() || UPD_PADRAO;
  try {
    const res = await fetch(url + (url.includes("?") ? "&" : "?") + "t=" + Date.now(), { cache: "no-store" });
    if (!res.ok) throw new Error("HTTP " + res.status);
    const info = await res.json();
    const atual = chrome.runtime.getManifest().version;
    const nova = cmpVersao(info.versao, atual) > 0;
    const antes = st["upd:info"] || {};
    const registro = { ...info, nova, atual, url, ts: Date.now(), avisado: nova && antes.versao === info.versao && antes.avisado };
    if (nova) {
      chrome.action.setBadgeText({ text: "1" });
      chrome.action.setBadgeBackgroundColor({ color: "#ff8440" });
      if (!registro.avisado || manual) {
        chrome.notifications.create(UPD_NOTIF, {
          type: "basic",
          iconUrl: "icons/icon128.png",
          title: `Versão ${info.nome || info.versao} disponível`,
          message: (info.notas || "Abra a Central para baixar.") + "\nClique para baixar.",
          priority: 1,
        });
        registro.avisado = true;
      }
    } else {
      chrome.action.setBadgeText({ text: "" });
    }
    await chrome.storage.local.set({ "upd:info": registro });
    return { ok: true, nova, info: registro };
  } catch (e) {
    await chrome.storage.local.set({ "upd:erro": { msg: String(e.message || e), ts: Date.now(), url } });
    return { ok: false, erro: String(e.message || e) };
  }
}

// Baixa o zip direto (sem abrir aba). Sem a API de downloads, abre a página da versão.
function abrirDownload() {
  chrome.storage.local.get("upd:info", (v) => {
    const info = v["upd:info"];
    if (!info) return;
    if (info.download && chrome.downloads) {
      chrome.downloads.download({ url: info.download, conflictAction: "uniquify" }, (id) => {
        if (chrome.runtime.lastError || id === undefined) chrome.tabs.create({ url: info.pagina || info.download });
        else chrome.downloads.show(id);
      });
    } else if (info.pagina || info.download) {
      chrome.tabs.create({ url: info.pagina || info.download });
    }
  });
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create(UPD_ALARM, { delayInMinutes: 0.5, periodInMinutes: 6 * 60 });
});
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.create(UPD_ALARM, { delayInMinutes: 0.5, periodInMinutes: 6 * 60 });
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === UPD_ALARM) verificarAtualizacao().catch(() => {});
});
chrome.notifications.onClicked.addListener((id) => {
  if (id === UPD_NOTIF) { abrirDownload(); chrome.notifications.clear(id); }
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message && message.type === "VERIFICAR_ATUALIZACAO") {
    verificarAtualizacao(!!message.manual).then(sendResponse);
    return true;
  }
  if (message && message.type === "BAIXAR_ATUALIZACAO") { abrirDownload(); sendResponse({ ok: true }); }
});
