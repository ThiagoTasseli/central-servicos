/* theme-sync.js — tema único da Central (escuro/claro).
 * Carregado no <head> de cada página. Lê "arion:tema" e acompanha mudanças:
 * trocar o tema no trilho da Central atualiza todas as ferramentas na hora.
 */
(function () {
  var KEY = "arion:tema";
  var root = document.documentElement;
  function apply(t) { root.setAttribute("data-theme", t === "dark" ? "dark" : "light"); }
  apply("light");
  try {
    chrome.storage.local.get(KEY, function (v) { apply(v && v[KEY]); });
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area === "local" && changes[KEY]) apply(changes[KEY].newValue);
    });
  } catch (_) {}
})();
