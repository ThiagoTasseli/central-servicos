/* Lista de sons do alarme. Para adicionar um som: coloque o arquivo em sounds/ e inclua uma linha aqui. */
self.ARION_SONS = [
  { id: "classico", nome: "Clássico", arquivo: "sounds/classico.wav" },
  { id: "despertador", nome: "Despertador", arquivo: "sounds/despertador.mp3" },
  { id: "bip", nome: "Bip duplo", arquivo: "sounds/bip.mp3" },
  { id: "digital", nome: "Digital", arquivo: "sounds/digital.mp3" },
  { id: "sino", nome: "Sino", arquivo: "sounds/sino.mp3" },
  { id: "sirene", nome: "Sirene", arquivo: "sounds/sirene.mp3" },
  { id: "decolagem", nome: "Avião decolando", arquivo: "sounds/decolagem.mp3" },
  { id: "aviso", nome: "Aviso de voo", arquivo: "sounds/aviso-aviao.mp3" },
  { id: "mayday", nome: "Mayday", arquivo: "sounds/mayday.mp3" },
  { id: "violao", nome: "Violão", arquivo: "sounds/violao.mp3" },
];
self.ARION_SOM_PADRAO = "classico";
