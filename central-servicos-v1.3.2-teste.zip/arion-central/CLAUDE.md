# Central ARION — instruções para o Claude Code

Extensão interna do Grupo ARION (Chrome/Edge, Manifest V3). Uso interno, NÃO será publicada em loja.
Junta 4 ferramentas: Máscara de Chamado, NOC Atacado (OTRS), Preenchimento de Chamados (ServiceAide)
e Central de Voos. Estrutura e padrões estão no README.md — leia antes de mexer.

Estilo de resposta do usuário: direto, frases curtas, sem enrolação. Português do Brasil.
Ambiente: Windows, CMD/PowerShell. Pasta da extensão: esta pasta.

## Tarefa atual: preparar a versão de PRODUÇÃO (1.3.0)

Faça nesta ordem e mostre o resultado de cada passo:

1. **Backup**: copie esta pasta para `..\arion-central-teste-backup` antes de alterar.
2. **SheetJS oficial**: baixe `https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js`
   e substitua `apps/voos/libs/xlsx.full.min.js`. Confira que o arquivo contém `.version="0.20.3"`.
   Se a rede bloquear, avise e siga (a cópia atual também é 0.20.3, de espelho npm).
3. **Remover marcas de teste** em `manifest.json`:
   - `name` → `ARION · Central de Ferramentas`
   - `action.default_title` → `ARION · Central de Ferramentas`
   - remover a chave `version_name`
   - `description`: tirar o prefixo `Versão de teste. `
   - `hub/changelog.js`: `1.3.0-teste` → `1.3.0`
   - `README.md`: título sem "(TESTE)" e remover o bloco "Versão de teste / O que testar".
4. **Validar**: `manifest.json` é JSON válido; `node --check` em todos os .js fora de `libs/`
   (se o Node não existir, apenas valide o JSON com PowerShell `ConvertFrom-Json`).
5. **Empacotar (.crx)** com o Chrome ou Edge instalado:
   - Chrome: `"C:\Program Files\Google\Chrome\Application\chrome.exe" --pack-extension="<esta pasta>"`
   - Se já existir `..\arion-central.pem`, use `--pack-extension-key="..\arion-central.pem"` (mesmo ID).
   - Saídas: `..\arion-central.crx` e `..\arion-central.pem`.
   - **O .pem é segredo**: não copiar para pasta compartilhada, não colocar dentro desta pasta,
     não commitar. Avise o usuário para guardar em local seguro.
6. **Descobrir o ID** da extensão a partir da chave pública do .pem
   (SHA-256 da chave pública DER, primeiros 32 hex, mapeando 0-f → a-p). Mostre o ID.
7. **Gerar arquivos de distribuição** em `..\distribuicao\`:
   - `arion-central-1.3.0.crx`
   - `arion-central-1.3.0.zip` (pasta sem `CLAUDE.md`, sem `.pem`)
   - `update.xml` com o ID e a URL de download (pergunte a URL da intranet; se não souber,
     use `https://INTRANET/arion/` como marcador e avise)
   - `politica-chrome.reg` e `politica-edge.reg` com `ExtensionInstallForcelist`
     = `<ID>;<URL>/update.xml` (para a TI aplicar — NÃO aplicar no PC do usuário)
   - `LEIA-ME-TI.txt`: passo a passo curto para a TI (piloto em 2–3 PCs, depois todos).
8. **Script de próximas versões**: crie `..\distribuicao\nova-versao.ps1` que recebe a versão
   (ex.: 1.3.1), atualiza `manifest.json`, empacota com o mesmo .pem e atualiza `update.xml`.

## Regras

- Não aplicar políticas de grupo nem mexer no registro do Windows do usuário.
- Não apagar nada sem perguntar. Mover para `_to_delete\` se precisar.
- Não enviar dados para fora da rede, exceto o download do SheetJS.
- Versões sempre crescem (o Chrome não faz downgrade).
- O tema, cores e fontes ficam só em `shared/arion-ds.css`.
