chrome.runtime.onMessage.addListener((message) => {
  const audio = document.getElementById("alert-audio");
  if (message.type === "PLAY_ALERT_SOUND") {
    audio.currentTime = 0;
    audio.play().catch((err) => console.error("Erro ao tocar som:", err));
  } else if (message.type === "STOP_ALERT_SOUND") {
    audio.pause();
    audio.currentTime = 0;
  }
});
