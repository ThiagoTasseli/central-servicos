/* hub.js — navegação da Central ARION.
 * Cada ferramenta roda na própria página (iframe), carregada só no primeiro
 * clique e mantida viva depois: trocar de ícone não perde o que foi preenchido.
 */
(function () {
  const TOOLS = self.ARION_TOOLS;
  const $ = (id) => document.getElementById(id);
  const stage = $("stage");
  const railList = $("railList");
  const params = new URLSearchParams(location.search);
  const hubMode = params.get("mode") || "panel";
  const frameMode = hubMode === "sidebar" ? "sidebar" : "panel";
  const LAST_KEY = "hub:lastTool";
  let current = "guia";

  // Escapa texto vindo de fora (planilha, páginas, storage) antes de ir para innerHTML.
  const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const svg = (inner) => `<svg viewBox="0 0 24 24" aria-hidden="true">${inner}</svg>`;
  const store = {
    get: (k) => new Promise((r) => { try { chrome.storage.local.get(k, (v) => r(v ? v[k] : undefined)); } catch (_) { r(undefined); } }),
    set: (k, v) => { try { chrome.storage.local.set({ [k]: v }); } catch (_) {} },
  };

  document.documentElement.dataset.mode = hubMode;
  let manifest = {};
  try { manifest = chrome.runtime.getManifest(); } catch (_) {}
  const versao = manifest.version_name || manifest.version || "";
  const ehTeste = /teste/i.test(versao);
  $("ver").textContent = "v" + versao.replace(/-?teste/i, "");
  $("badgeTeste").hidden = !ehTeste;
  $("testeBanner").hidden = !ehTeste;

  // ---------- Trilho de ícones ----------
  const homeBtn = document.createElement("button");
  homeBtn.className = "rail-btn";
  homeBtn.dataset.tool = "guia";
  homeBtn.style.setProperty("--c", "#ffffff");
  homeBtn.setAttribute("role", "tab");
  homeBtn.title = "Guia — objetivo e modo de uso (Alt+1)";
  homeBtn.innerHTML = svg('<path d="M3 5.5h6a3 3 0 0 1 3 3V20a2.5 2.5 0 0 0-2.5-2.5H3z"/><path d="M21 5.5h-6a3 3 0 0 0-3 3V20a2.5 2.5 0 0 1 2.5-2.5H21z"/>') + "<span>Guia</span>";
  railList.appendChild(homeBtn);

  TOOLS.forEach((t, i) => {
    const b = document.createElement("button");
    b.className = "rail-btn";
    b.dataset.tool = t.id;
    b.style.setProperty("--c", t.cor);
    b.setAttribute("role", "tab");
    b.title = `${t.nome} (Alt+${i + 2})`;
    b.innerHTML = svg(t.icon) + `<span>${t.curto}</span><i class="dot" aria-hidden="true"></i>`;
    railList.appendChild(b);
  });

  document.querySelectorAll("[data-tool]").forEach((b) =>
    b.addEventListener("click", () => show(b.dataset.tool))
  );

  // ---------- Cards do guia ----------
  $("cards").innerHTML = TOOLS.map((t, i) => `
    <article class="card" style="--c:${t.cor}">
      <div class="card-top">
        <div class="card-icon">${svg(t.icon)}</div>
        <div class="card-title">
          <h3>${t.nome}</h3>
          <div class="chips">${t.onde.map((o) => `<span class="chip">${o}</span>`).join("")}</div>
        </div>
      </div>
      <p class="card-goal"><b>Objetivo</b> ${t.objetivo}</p>
      <details>
        <summary>Como usar <span class="kbd-hint">${t.passos.length} passos</span></summary>
        <ol>${t.passos.map((p) => `<li>${p}</li>`).join("")}</ol>
      </details>
      <button class="card-open" data-open="${t.id}">Abrir ${t.curto}
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>
      </button>
    </article>`).join("");
  document.querySelectorAll("[data-open]").forEach((b) =>
    b.addEventListener("click", () => show(b.dataset.open))
  );

  // ---------- Troca de ferramenta ----------
  function ensureFrame(t) {
    let view = document.querySelector(`.view[data-view="${t.id}"]`);
    if (view) return view;
    view = document.createElement("section");
    view.className = "view tool-view";
    view.dataset.view = t.id;
    view.hidden = true;
    const f = document.createElement("iframe");
    f.title = t.nome;
    f.setAttribute("allow", "clipboard-read; clipboard-write");
    f.src = `${t.page}?mode=${frameMode}`;
    view.appendChild(f);
    stage.appendChild(view);
    return view;
  }

  function show(id) {
    const t = TOOLS.find((x) => x.id === id);
    if (!t) id = "guia";
    current = id;
    if (t) ensureFrame(t);
    document.querySelectorAll(".view").forEach((v) => (v.hidden = v.dataset.view !== id));
    document.querySelectorAll(".rail-btn").forEach((b) => {
      const on = b.dataset.tool === id;
      b.classList.toggle("active", on);
      b.setAttribute("aria-selected", on);
    });
    document.documentElement.style.setProperty("--active-c", t ? t.cor : "#3a3a3a");
    if (id === "voos") clearAlarmDot();
    closeDrawer();
    store.set(LAST_KEY, id);
    if (t) {
      const f = document.querySelector(`.view[data-view="${id}"] iframe`);
      setTimeout(() => f && f.focus(), 30);
    }
  }

  // ---------- Atalhos ----------
  function onKey(e) {
    if (e.altKey && !e.shiftKey && /^[1-5]$/.test(e.key)) {
      e.preventDefault();
      show(["guia", ...TOOLS.map((t) => t.id)][Number(e.key) - 1]);
    } else if (e.altKey && !e.shiftKey && e.key === "0") {
      e.preventDefault();
      btnCollapse.click();
    } else if (e.key === "Escape") {
      closeDrawer();
    }
  }
  document.addEventListener("keydown", onKey);
  // Repassa os atalhos também quando o foco está dentro de uma ferramenta.
  stage.addEventListener("load", (e) => {
    try { e.target.contentWindow.addEventListener("keydown", onKey); } catch (_) {}
  }, true);

  // ---------- Ajuda contextual (?) ----------
  const drawer = $("drawer");
  function openDrawer() {
    const t = TOOLS.find((x) => x.id === current);
    if (!t) { show("guia"); return; }
    $("drawerBody").innerHTML = `
      <div class="drawer-head" style="--c:${t.cor}">
        <div class="card-icon">${svg(t.icon)}</div>
        <h3>${t.nome}</h3>
        <button class="drawer-x" aria-label="Fechar">✕</button>
      </div>
      <p class="card-goal"><b>Objetivo</b> ${t.objetivo}</p>
      <p class="drawer-where"><b>Onde usar</b> ${t.onde.join(" · ")}</p>
      <ol>${t.passos.map((p) => `<li>${p}</li>`).join("")}</ol>`;
    $("drawerBody").style.setProperty("--c", t.cor);
    drawer.hidden = false;
    drawer.querySelector(".drawer-x").onclick = closeDrawer;
  }
  function closeDrawer() { drawer.hidden = true; }
  $("btnHelp").addEventListener("click", () => (drawer.hidden ? openDrawer() : closeDrawer()));
  drawer.addEventListener("click", (e) => { if (e.target === drawer) closeDrawer(); });

  $("btnTab").addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("hub/index.html?mode=tab") });
  });
  if (hubMode === "tab") $("btnTab").hidden = true;

  // ---------- Recolher / expandir a barra ----------
  const COLLAPSE_KEY = "hub:railCollapsed";
  const btnCollapse = $("btnCollapse");
  function setCollapsed(on, save = true) {
    document.documentElement.classList.toggle("rail-collapsed", on);
    btnCollapse.setAttribute("aria-expanded", String(!on));
    const label = on ? "Expandir barra (Alt+0)" : "Recolher barra (Alt+0)";
    btnCollapse.title = label;
    btnCollapse.setAttribute("aria-label", label);
    if (save) store.set(COLLAPSE_KEY, on);
  }
  btnCollapse.addEventListener("click", () =>
    setCollapsed(!document.documentElement.classList.contains("rail-collapsed"))
  );
  store.get(COLLAPSE_KEY).then((v) => setCollapsed(!!v, false));

  // ---------- Bandeja ⇄ Lateral ----------
  // Bandeja = popup que abre no ícone ARION (fecha ao clicar fora).
  // Lateral = painel fixo ao lado da página (não fecha ao trocar de foco).
  const VIEW_KEY = "hub:viewMode";
  const sidebarApi = (typeof browser !== "undefined" && browser.sidebarAction) || chrome.sidebarAction || null;
  const btnMode = $("btnMode");
  const isTray = hubMode === "popup";
  const ICON_PIN = '<path d="M9 4h6l-1 5 3 3v2H7v-2l3-3z"/><path d="M12 14v6"/>';
  const ICON_TRAY = '<rect x="3.5" y="4" width="17" height="16" rx="2"/><path d="M3.5 9h17M8 13.5h8"/>';
  let windowId = null;
  try { chrome.windows.getCurrent((w) => { windowId = w && w.id; }); } catch (_) {}

  if (hubMode === "tab") btnMode.hidden = true;
  btnMode.innerHTML = isTray
    ? svg(ICON_PIN) + "<span>Fixar</span>"
    : svg(ICON_TRAY) + "<span>Bandeja</span>";
  btnMode.title = isTray
    ? "Fixar na lateral — o painel fica aberto ao lado da página"
    : "Mudar para bandeja — abre como janelinha no ícone ARION";

  function modeMsg(text) {
    const m = document.createElement("div");
    m.className = "mode-msg";
    m.innerHTML = text;
    document.querySelector(".shell").appendChild(m);
  }

  btnMode.addEventListener("click", async () => {
    if (isTray) {
      // Bandeja → Lateral: abre o painel ainda dentro do clique (exige gesto do usuário).
      let opened = null;
      try {
        if (chrome.sidePanel && chrome.sidePanel.open && windowId != null) opened = chrome.sidePanel.open({ windowId });
        else if (sidebarApi) opened = sidebarApi.open();
      } catch (_) {}
      chrome.storage.local.set({ [VIEW_KEY]: "lateral" });
      try { await chrome.runtime.sendMessage({ type: "SET_VIEW_MODE", mode: "lateral" }); } catch (_) {}
      try { await opened; } catch (_) {}
      window.close();
      return;
    }
    // Lateral → Bandeja
    try { await chrome.runtime.sendMessage({ type: "SET_VIEW_MODE", mode: "bandeja" }); }
    catch (_) { chrome.storage.local.set({ [VIEW_KEY]: "bandeja" }); }
    let popupOk = false;
    try { if (chrome.action.openPopup) { await chrome.action.openPopup(); popupOk = true; } } catch (_) {}
    if (!popupOk) {
      modeMsg("<b>Modo bandeja ativado.</b><br>Clique no ícone ARION na barra do navegador para abrir.");
      await new Promise((r) => setTimeout(r, 2200));
    }
    try {
      if (chrome.sidePanel && chrome.sidePanel.close && windowId != null) await chrome.sidePanel.close({ windowId });
      else if (sidebarApi && hubMode === "sidebar") await sidebarApi.close();
    } catch (_) {}
    window.close();
  });

  // ---------- Site detectado na aba ativa ----------
  async function detect() {
    let url = "";
    try {
      const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      url = (tab && tab.url) || "";
    } catch (_) {}
    let host = "";
    try { host = new URL(url).hostname; } catch (_) {}
    const hits = TOOLS.filter((t) => host && t.hosts.some((re) => re.test(host)));
    document.querySelectorAll(".rail-btn").forEach((b) =>
      b.classList.toggle("suggested", hits.some((t) => t.id === b.dataset.tool))
    );
    const box = $("detected");
    if (!hits.length) { box.hidden = true; return; }
    box.hidden = false;
    box.innerHTML = `<span class="pulse"></span><div><b>Site detectado:</b> ${esc(host)}<br>` +
      hits.map((t) => `<button class="link" data-open="${t.id}" style="--c:${t.cor}">Abrir ${t.nome} →</button>`).join(" ") +
      `</div>`;
    box.querySelectorAll("[data-open]").forEach((b) => b.addEventListener("click", () => show(b.dataset.open)));
  }
  try {
    chrome.tabs.onActivated.addListener(detect);
    chrome.tabs.onUpdated.addListener((_id, info, tab) => { if (tab.active && (info.url || info.status === "complete")) detect(); });
    chrome.windows && chrome.windows.onFocusChanged && chrome.windows.onFocusChanged.addListener(detect);
  } catch (_) {}
  detect();

  // ---------- Alarmes da Central de Voos ----------
  const toast = $("alarmToast");
  function clearAlarmDot() {
    const b = document.querySelector('.rail-btn[data-tool="voos"]');
    b && b.classList.remove("alarm");
  }
  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg || msg.type !== "ALARM_FIRED") return;
    const b = document.querySelector('.rail-btn[data-tool="voos"]');
    // Com a Central de Voos na tela, o próprio módulo mostra o card do alarme.
    if (current === "voos") return;
    b && b.classList.add("alarm");
    toast.innerHTML = `
      <div class="toast-title">✈ ${esc(msg.title || "Alarme de voo")}</div>
      <div class="toast-msg">${esc(msg.message).replace(/\n+/g, "<br>")}</div>
      <div class="toast-actions">
        <button data-a="open">Abrir Voos</button>
        <button data-a="SNOOZE_ALARM">Adiar 5 min</button>
        <button data-a="DISMISS_ALARM">Desativar</button>
      </div>`;
    toast.hidden = false;
    toast.querySelectorAll("button").forEach((btn) =>
      btn.addEventListener("click", () => {
        const a = btn.dataset.a;
        if (a === "open") show("voos");
        else chrome.runtime.sendMessage({ type: a, alarmId: String(msg.alarmId || "") }).catch(() => {});
        if (a !== "open") clearAlarmDot();
        toast.hidden = true;
      })
    );
  });

  // ---------- Tema único (claro/escuro) ----------
  // Grava a chave comum e as chaves antigas de cada ferramenta, para todas abrirem iguais.
  $("btnTheme").addEventListener("click", () => {
    const novo = document.documentElement.getAttribute("data-theme") === "light" ? "dark" : "light";
    try { chrome.storage.local.set({ "arion:tema": novo, tema: novo, theme: novo }); } catch (_) {}
  });

  // ---------- Novidades ----------
  $("changelog").innerHTML = (self.ARION_CHANGELOG || []).slice(0, 3).map((v) =>
    `<li><b>${esc(v.versao)}</b><ul>${v.itens.map((i) => `<li>${esc(i)}</li>`).join("")}</ul></li>`
  ).join("");

  // ---------- Relatar problema (versão de teste) ----------
  $("btnDiag").addEventListener("click", async () => {
    const tudo = await new Promise((r) => { try { chrome.storage.local.get(null, r); } catch (_) { r({}); } });
    const info = [
      "Central ARION — relato de teste",
      "Versão: " + versao,
      "Data: " + new Date().toLocaleString("pt-BR"),
      "Navegador: " + navigator.userAgent,
      "Modo: " + hubMode + " · Ferramenta aberta: " + current,
      "Tema: " + (document.documentElement.getAttribute("data-theme") || "dark"),
      "Chamados NOC guardados: " + Object.keys(tudo).filter((k) => k.startsWith("tk_")).length,
      "Planilha de voos: " + (tudo.importedFileName ? "carregada" : "não carregada"),
      "",
      "O que aconteceu:",
      "",
      "O que era esperado:",
      "",
    ].join("\n");
    try { await navigator.clipboard.writeText(info); $("btnDiag").textContent = "Copiado — cole no seu relato"; }
    catch (_) { $("btnDiag").textContent = "Não foi possível copiar"; }
    setTimeout(() => ($("btnDiag").textContent = "Copiar dados para relatar problema"), 2500);
  });

  // ---------- Limpeza manual ----------
  $("btnClean").addEventListener("click", async () => {
    try {
      const r = await chrome.runtime.sendMessage({ type: "LIMPAR_DADOS_ANTIGOS" });
      $("btnClean").textContent = `Feito (${(r && r.removidos) || 0} itens antigos removidos)`;
    } catch (_) { $("btnClean").textContent = "Falhou — tente de novo"; }
  });

  // ---------- Aviso de versão nova (intranet) ----------
  // versao.json esperado: { "versao": "1.3.1", "download": "https://… ou \\servidor\pasta", "notas": "…" }
  const UPD_KEY = "hub:updUrl";
  const cmp = (a, b) => {
    const pa = String(a).match(/\d+/g) || [], pb = String(b).match(/\d+/g) || [];
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      const d = (+pa[i] || 0) - (+pb[i] || 0);
      if (d) return d;
    }
    return 0;
  };
  async function checkUpdate(url, manual) {
    const st = $("updStatus"), ban = $("updateBanner");
    if (!url) { if (manual) st.textContent = "Informe o endereço do arquivo de versão."; return; }
    try {
      const res = await fetch(url, { cache: "no-store" });
      const info = await res.json();
      if (cmp(info.versao, manifest.version) > 0) {
        ban.hidden = false;
        ban.innerHTML = `<b>Versão ${esc(info.versao)} disponível.</b> ${esc(info.notas || "")}<br>` +
          `Baixe em: <code>${esc(info.download || url)}</code>`;
        const g = document.querySelector('.rail-btn[data-tool="guia"]');
        g && g.classList.add("suggested");
        st.textContent = "Há versão nova.";
      } else {
        ban.hidden = true;
        st.textContent = "Você está na versão mais recente.";
      }
    } catch (_) {
      st.textContent = manual ? "Não foi possível ler o arquivo de versão. Confira o endereço." : st.textContent;
    }
  }
  store.get(UPD_KEY).then((u) => { if (u) { $("updUrl").value = u; checkUpdate(u, false); } });
  $("btnUpd").addEventListener("click", async () => {
    const url = $("updUrl").value.trim();
    store.set(UPD_KEY, url);
    if (url && /^https?:/i.test(url) && chrome.permissions) {
      // Pede acesso só ao servidor informado (permissão opcional).
      try {
        const origin = new URL(url).origin + "/*";
        const ok = await chrome.permissions.request({ origins: [origin] });
        if (!ok) { $("updStatus").textContent = "Acesso ao servidor negado."; return; }
      } catch (_) {}
    }
    checkUpdate(url, true);
  });

  // ---------- Início ----------
  store.get(LAST_KEY).then((last) => show(last || "guia"));
})();
