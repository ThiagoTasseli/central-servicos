/* modules/page.js
 * Injetado na aba do OTRS (world MAIN): acesso a jQuery, InputFields e CKEditor.
 * Expõe window.__arionOTRS com: ler, categorizar, nota, abrir, mover.
 * Cada função devolve { ok, campos: { nome: true|false|'texto' }, ... }.
 */
(function () {
// Versão deste código. Sempre substitui o que estiver na janela:
// antes, a trava "if (window.__arionOTRS) return;" mantinha código antigo
// rodando em popups do OTRS abertos antes de atualizar a extensão.
const VERSAO = '2.4.2';

const sleep = ms => new Promise(r => setTimeout(r, ms));
const norm = s => String(s || '').replace(/ /g, ' ').replace(/\s+/g, ' ').trim().toUpperCase();

async function esperar(fn, timeout = 8000) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeout) {
    const v = fn();
    if (v) return v;
    await sleep(150);
  }
  return null;
}

async function esperarAjax() {
  await sleep(300);
  await esperar(() => !window.jQuery || jQuery.active === 0, 10000);
}

// Busca o campo pelo seletor; se falhar, pelo rótulo visível (<label for>).
function campo(seletores, rotulo) {
  for (const s of [].concat(seletores || [])) {
    const el = s && document.querySelector(s);
    if (el) return el;
  }
  if (!rotulo) return null;
  const alvo = norm(rotulo);
  const lbl = [...document.querySelectorAll('label')]
    .find(l => norm(l.textContent).replace(/[*:]/g, '').trim() === alvo);
  return lbl ? document.getElementById(lbl.htmlFor) : null;
}

function disparar(el, ...eventos) {
  eventos.forEach(e => el.dispatchEvent(new Event(e, { bubbles: true })));
  if (window.jQuery) jQuery(el).trigger('change');
}

// <select> (InputField em árvore ou lista): escolhe pela opção visível.
async function escolher(el, texto) {
  if (!el) return false;
  const opt = await esperar(() =>
    [...el.options].find(o => norm(o.text) === norm(texto)) ||
    [...el.options].find(o => norm(o.text).endsWith(norm(texto))));
  if (!opt) return false;
  if (el.value !== opt.value) {
    if (el.multiple) opt.selected = true; else el.value = opt.value;
    if (window.jQuery) jQuery(el).trigger('change').trigger('redraw.InputField');
    else disparar(el, 'change');
    await esperarAjax();
  }
  return true;
}

// SLA: usa o preferido (24 Horas 24x7); se não existir para o serviço, o primeiro disponível.
// Devolve true (preferido), o texto da opção usada (alternativa) ou false (lista vazia).
async function escolherOuDisponivel(el, texto) {
  if (!el) return false;
  // A lista de SLA é recarregada após escolher o Serviço: espera ter opções reais.
  const validas = () => [...el.options].filter(o => o.value && !/^-+$/.test(o.text.trim()));
  await esperar(() => validas().length, 6000);
  if (await escolherRapido(el, texto)) return true;
  const alt = validas()[0];
  if (!alt) return false;
  if (el.value !== alt.value) {
    el.value = alt.value;
    if (window.jQuery) jQuery(el).trigger('change').trigger('redraw.InputField');
    else disparar(el, 'change');
    await esperarAjax();
  }
  return alt.text.replace(/\u00a0/g, ' ').trim();
}

// Igual a escolher(), mas sem esperar a opção aparecer.
async function escolherRapido(el, texto) {
  const opt = [...el.options].find(o => norm(o.text) === norm(texto)) ||
    [...el.options].find(o => norm(o.text).endsWith(norm(texto)));
  if (!opt) return false;
  if (el.value !== opt.value) {
    el.value = opt.value;
    if (window.jQuery) jQuery(el).trigger('change').trigger('redraw.InputField');
    else disparar(el, 'change');
    await esperarAjax();
  }
  return true;
}

// Campo com lista de sugestões (Localidade, Empresa, Links de internet).
// Simula a digitação, espera a lista e CLICA na opção: só escrever não grava o valor.
const LISTAS = '.ui-autocomplete li, .ui-menu-item, [role="option"], .InputField_ListContainer li, .ac_results li';

// Só a lista DESTE campo: listas de outros campos podem continuar abertas.
let campoAtual = null;
function visiveis() {
  let raiz = document;
  try {
    const w = campoAtual && window.jQuery && jQuery(campoAtual).autocomplete('instance') && jQuery(campoAtual).autocomplete('widget');
    if (w && w[0]) raiz = w[0];
  } catch (_) {}
  let itens = [...raiz.querySelectorAll(raiz === document ? LISTAS : 'li, [role="option"]')]
    .filter(li => li.getClientRects().length && norm(li.textContent));
  if (raiz === document && campoAtual) {
    // Sem widget conhecido: fica com o que aparece logo abaixo do campo.
    const c = campoAtual.getBoundingClientRect();
    itens = itens.filter(li => {
      const r = li.getBoundingClientRect();
      return r.top >= c.top && r.top - c.bottom < 450 && r.left < c.right && r.right > c.left;
    });
  }
  return itens;
}

function melhorOpcao(texto, { qualquer = false } = {}) {
  // (usa visiveis(): só a lista do campo atual)
  const alvo = norm(texto);
  const ops = visiveis();
  return ops.find(li => norm(li.textContent) === alvo) ||
    ops.find(li => norm(li.textContent).startsWith(alvo)) ||
    ops.find(li => norm(li.textContent).includes(alvo)) ||
    (qualquer ? ops[0] : null);
}

function tecla(el, key, tipo = 'keydown') {
  const code = { ArrowDown: 40, Enter: 13 }[key] || key.charCodeAt(0);
  const ev = new KeyboardEvent(tipo, { bubbles: true, key, keyCode: code, which: code });
  el.dispatchEvent(ev);
  if (window.jQuery) jQuery(el).trigger(jQuery.Event(tipo, { key, keyCode: code, which: code }));
}

// busca: texto a digitar (padrão = texto). texto null = 1ª opção com o termo buscado.
async function digitar(el, texto, { busca, exigirOpcao = false, primeira = false, aceitaChip = false, teclado = false, idSel = null, timeout = 6000 } = {}) {
  busca = busca || texto;
  if (!el) return false;
  campoAtual = el;
  if (el.tagName === 'SELECT') return escolher(el, texto);

  el.focus();
  el.value = '';
  // Digita caractere a caractere: o OTRS só busca após eventos de tecla.
  for (const ch of busca) {
    el.value += ch;
    tecla(el, ch, 'keydown');
    el.dispatchEvent(new Event('input', { bubbles: true }));
    tecla(el, ch, 'keyup');
  }
  if (window.jQuery) {
    const $el = jQuery(el);
    $el.trigger('input');
    try { if ($el.autocomplete('instance')) $el.autocomplete('search', busca); } catch (_) {}
  }

  // texto null: 1ª opção que contém o termo digitado (ignora "Grupo Arion", que sempre aparece).
  const alvoTexto = texto == null ? null : texto;
  const item = await esperar(() => {
    const ops = visiveis().filter(li => !/^GRUPO ARION$/.test(norm(li.textContent)));
    return alvoTexto == null
      ? ops.find(li => norm(li.textContent).includes(norm(busca)))
      : melhorOpcao(alvoTexto, { qualquer: primeira });
  }, timeout);

  if (item) {
    const esperado = norm(item.textContent);
    ultimaOpcao = item.textContent.trim();
    const dados = dadosDoItem(item);
    const idEl = idSel ? document.querySelector(idSel) : null;
    const ok = () => confirmado(el, busca, esperado, aceitaChip, idEl, dados);

    const porSeta   = async () => viaTeclado(el, esperado);           // ↓ até o item ativo DO MENU + Enter
    const porSelect = async () => dispararSelect(el, item, dados);    // evento select do autocomplete
    const porMenu   = async () => selecionarItem(item);               // menu.focus + menu.select
    const porMouse  = async () => cliqueMouse(item);
    const tentativas = teclado ? [porSeta, porSelect, porMenu, porMouse] : [porMenu, porSeta, porSelect, porMouse];

    for (const tentar of tentativas) {
      try { await tentar(); } catch (_) {}
      await esperarAjax();
      if (await esperar(ok, 2000)) return true;
      // A lista pode ter fechado: digita/abre de novo para a próxima tentativa.
      if (!visiveis().length) await reabrir(el, busca);
    }
    ultimaOpcao = '';
    // Falhou: NÃO apaga. Mantém o termo e a lista aberta para o analista (ou o ↻).
    if (exigirOpcao) { await reabrir(el, busca); return false; }
    fecharLista(el);
    return 'texto';
  }

  // Nada achado: mantém o termo digitado (sem seta + Enter, que pegaria o Grupo Arion).
  if (exigirOpcao) return false;
  fecharLista(el);
  el.blur();
  return 'texto';
}

// Dados do item no jQuery UI 1.12: { label, value, data: { Name, Code, ID } }.
function dadosDoItem(li) {
  if (!window.jQuery) return null;
  const $li = jQuery(li).closest('li');
  return $li.data('ui-autocomplete-item') || $li.data('item.autocomplete') || null;
}

async function reabrir(el, busca) {
  el.focus();
  if (norm(el.value) !== norm(busca)) { el.value = busca; disparar(el, 'input'); }
  try { if (window.jQuery && jQuery(el).autocomplete('instance')) jQuery(el).autocomplete('search', busca); } catch (_) {}
  await esperar(() => visiveis().length, 3000);
}

// Plano B: dispara o "select" do autocomplete com os dados reais do item,
// exatamente o que o jQuery UI faz quando o analista escolhe na lista.
async function dispararSelect(el, li, dados) {
  if (!window.jQuery || !dados) return false;
  let inst = null;
  try { inst = jQuery(el).autocomplete('instance'); } catch (_) {}
  if (!inst) return false;
  const ev = jQuery.Event('autocompleteselect');
  if (inst._trigger('select', ev, { item: dados }) !== false) {
    el.value = dados.value;
  }
  inst.term = el.value;
  inst.selectedItem = dados;
  inst.close(ev);
  jQuery(el).trigger('change');
  return true;
}

// Seleciona o item pelo próprio menu do jQuery UI: foca ESTE item e confirma.
// Clique simulado sozinho confirmaria o item pré-destacado (o 1º da lista).
function selecionarItem(li) {
  const $ = window.jQuery;
  const ul = li.closest('.ui-menu, .ui-autocomplete, ul');
  if ($ && ul) {
    let menu = null;
    try { menu = $(ul).menu('instance'); } catch (_) {}
    if (!menu) menu = $(ul).data('ui-menu') || $(ul).data('menu');
    const $li = $(li).closest('.ui-menu-item').length ? $(li).closest('.ui-menu-item') : $(li);
    if (menu && menu.focus && menu.select) {
      menu.focus($.Event('mouseenter'), $li);
      menu.select($.Event('click'));
      return;
    }
    $li.trigger('mouseenter').trigger('mouseover');
    ($li.find('a, div').first().length ? $li.find('a, div').first() : $li).trigger('click');
    return;
  }
  const alvo = li.querySelector('a, div, span') || li;
  ['mouseover', 'mouseenter', 'mousemove', 'mousedown', 'mouseup', 'click'].forEach(t =>
    alvo.dispatchEvent(new MouseEvent(t, { bubbles: true })));
}

let ultimaOpcao = '';

// Só conta como selecionado se o campo MUDOU do termo digitado para a opção.
// ("fust" no campo com a lista aberta NÃO é seleção.)
function confirmado(el, busca, esperado, aceitaChip, idEl, dados) {
  const v = norm(el.value);
  // Localidade: o OTRS grava o ID da opção em um campo oculto ao selecionar.
  if (idEl) {
    const id = norm(idEl.value);
    const idEsperado = norm(dados && dados.data && (dados.data.ID || dados.data.Code) || '');
    return !!id && (idEsperado ? id === idEsperado : true) && v === esperado;
  }
  if (v === esperado) return true;
  if (v && v !== norm(busca) && (v.includes(esperado) || (esperado.includes(v) && v.length > norm(busca).length))) return true;
  // Links de internet: ao selecionar, o OTRS troca o campo por uma "etiqueta" com o link.
  if (aceitaChip) {
    const box = caixaDoCampo(el);
    const txt = norm(box ? box.textContent : '');
    if ((!el.getClientRects().length || v === '') && txt.includes(norm(busca))) return true;
  }
  return false;
}

function caixaDoCampo(el) {
  return el.closest('.Field') || (el.parentElement && el.parentElement.parentElement) || el.parentElement;
}

// Desce com a seta até a opção certa ficar destacada e confirma com Enter.
// Item ativo de verdade: o do menu do jQuery UI (a classe .ui-state-active pode estar "velha").
function itemAtivo(el) {
  try {
    const inst = window.jQuery && jQuery(el).autocomplete('instance');
    if (inst && inst.menu) return inst.menu.active && inst.menu.active.length ? inst.menu.active[0] : null;
  } catch (_) {}
  return null;
}

// Desce com a seta ↓ até o item ativo do menu ser o cliente certo e confirma com Enter.
async function viaTeclado(el, esperado) {
  let inst = null;
  try { inst = window.jQuery && jQuery(el).autocomplete('instance'); } catch (_) {}
  if (!inst) return false;
  const tecla = (code) => jQuery(el).trigger(jQuery.Event('keydown', { keyCode: code, which: code }));
  el.focus();
  const total = visiveis().length || 10;
  for (let i = 0; i <= total + 1; i++) {
    tecla(40); // ↓ (o 1º ↓ ativa o 1º item; os seguintes descem)
    await sleep(120);
    const li = itemAtivo(el);
    if (li && norm(li.textContent) === esperado) {
      tecla(13); // Enter
      return true;
    }
  }
  return false;
}

function cliqueMouse(li) {
  const alvo = li.querySelector('a, div, span') || li;
  ['mouseover', 'mouseenter', 'mousemove', 'mousedown', 'mouseup', 'click'].forEach(t =>
    alvo.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window })));
}

// Remove a etiqueta já selecionada no Links de internet (botão ⊗ ao lado).
async function limparLink(el) {
  const box = caixaDoCampo(el);
  if (!box) return;
  const x = [...box.querySelectorAll('a, span, i, button')].find(b =>
    /remove|delete|close|times|clear/i.test(b.className + ' ' + (b.getAttribute('title') || '')) ||
    /^[⊗×✕]$/.test((b.textContent || '').trim()));
  if (x) { x.click(); await esperarAjax(); await esperar(() => el.getClientRects().length, 3000); }
  el.value = '';
  disparar(el, 'input');
}

async function preencherLink(designacao) {
  const el = campo('#DynamicFieldConfigItemSearch_AtivodeRede2', 'Links de internet');
  if (!el) return { r: false, opcao: '' };
  await limparLink(el);
  ultimaOpcao = '';
  const r = await digitar(el, designacao, { primeira: true, aceitaChip: true, timeout: 8000 });
  return { r, opcao: r === true ? ultimaOpcao : '' };
}

function fecharLista(el) {
  try { if (window.jQuery && jQuery(el).autocomplete('instance')) jQuery(el).autocomplete('close'); } catch (_) {}
}

async function marcar(seletor, rotulo) {
  const el = campo(seletor) ||
    [...document.querySelectorAll('input[type=checkbox]')]
      .find(c => norm(c.value) === norm(rotulo) || norm(c.closest('label, span, div')?.textContent) === norm(rotulo));
  if (!el) return false;
  if (!el.checked) { el.click(); await esperarAjax(); }
  return el.checked;
}

function escrever(el, valor) {
  if (!el) return false;
  el.value = valor;
  disparar(el, 'input', 'change');
  return true;
}

function editor(html) {
  const inst = window.CKEDITOR && (CKEDITOR.instances.RichText || Object.values(CKEDITOR.instances)[0]);
  if (inst) { inst.setData(html); return true; }
  return escrever(document.getElementById('RichText'), html.replace(/<[^>]+>/g, '\n'));
}

function botaoEnviar() {
  return document.getElementById('submitRichText') ||
    [...document.querySelectorAll('button[type=submit], input[type=submit]')]
      .find(b => /ENVIAR|SUBMIT/.test(norm(b.textContent || b.value)));
}

// Texto do chamado SEM o formulário: rótulos ("ID Cliente (BRAD, ...)"), listas de
// filas/localidades e campos confundem a detecção do cliente.
const RUIDO = 'select, option, label, input, textarea, button, script, style, noscript, ' +
  '.InputField_Container, .InputField_TreeContainer, .ui-autocomplete, .ui-menu, #NavigationContainer, ' +
  '#ToolBar, .ActionRow, .Sidebar .Field, .FormFields, form .Field';

function textoLimpo(doc) {
  try {
    const clone = doc.body.cloneNode(true);
    clone.querySelectorAll(RUIDO).forEach(e => e.remove());
    let t = clone.innerText || clone.textContent || '';
    doc.querySelectorAll('iframe').forEach(f => {
      try { const b = f.contentDocument.body; t += "\n" + (b.innerText || b.textContent || ""); } catch (_) {}
    });
    return t;
  } catch (_) { return ''; }
}

function textoTotal() {
  let t = textoLimpo(document);
  // Popup (Campos Livres / Nota): os artigos ficam na janela do ticket.
  try { if (window.opener && window.opener.document) t += '\n' + textoLimpo(window.opener.document); } catch (_) {}
  return t;
}

// Título: campo Título + cabeçalho da tela (+ título do ticket na janela de origem).
function tituloChamado() {
  const partes = [];
  const input = document.getElementById('Title');
  if (input && input.value) partes.push(input.value);
  const h = document.querySelector('.Headline h1, h1');
  if (h) partes.push(h.textContent.replace(/^.*?—\s*/, '').trim());
  try {
    const oh = window.opener && window.opener.document.querySelector('.Headline h1, h1');
    if (oh) partes.push(oh.textContent.replace(/^.*?—\s*/, '').trim());
  } catch (_) {}
  return [...new Set(partes.filter(Boolean))].join(' | ') || document.title;
}

async function preencherLocalidade(d) {
  const el = campo('#DynamicField_SGFLocalidade', 'Localidade');
  if (!el) return false;
  return digitar(el, d.localidadeOpcao, {
    busca: d.localidadeBusca, exigirOpcao: true, teclado: true,
    idSel: document.getElementById('DynamicField_SGFIDLocalidade') ? '#DynamicField_SGFIDLocalidade' : null
  });
}

// Espera o OTRS parar de atualizar o formulário (AJAX + pequena folga).
async function esperarOtrsQuieto() {
  for (let i = 0; i < 3; i++) {
    await esperarAjax();
    await sleep(400);
    if (!window.jQuery || jQuery.active === 0) break;
  }
}

async function tituloEAssunto(mascara) {
  const t = campo('#Title', 'Título'), a = campo('#Subject', 'Assunto');
  await esperarOtrsQuieto();
  for (let tent = 0; tent < 3; tent++) {
    escrever(t, mascara);
    escrever(a, mascara);
    await esperarOtrsQuieto();
    // Conferência: se o OTRS sobrescreveu, escreve de novo.
    if ((!t || t.value === mascara) && (!a || a.value === mascara)) break;
  }
  return { titulo: !!t && t.value === mascara, assunto: !!a && a.value === mascara };
}

async function localidadeEResto(c, { d, fixos, texto, enviar }) {
  c.localidade = await preencherLocalidade(d);
  if (c.localidade !== true) {
    // Para aqui: sem Localidade confirmada, o resto seria apagado pelo OTRS depois.
    return { ok: false, campos: c, falhas: ['localidade'], paradoEm: 'localidade', enviado: false };
  }
  c.razao       = await digitar(campo('#DynamicField_SGFRazaoSocial', 'Empresa (Razão social)'), d.empresa, { exigirOpcao: true });
  c.fantasia    = await digitar(campo('#DynamicField_SGFNomeFantasia', 'Empresa (Nome fantasia)'), d.empresa, { exigirOpcao: true });
  c.servicoSgf  = await marcar('#INTERNET', fixos.servicoSgf);
  c.subServico  = await marcar('#Indisponibilidade', fixos.subServicoSgf);
  c.servico     = await escolher(campo('#ServiceID', 'Serviço'), fixos.servico);
  const sla     = await escolherOuDisponivel(campo('#SLAID', 'Acordo de Nível de Serviço'), fixos.sla);
  c.sla         = sla !== false;
  const slaAlternativo = typeof sla === 'string' ? sla : '';
  c.site        = await escolher(campo(null, 'Site'), fixos.site);
  const link    = await preencherLink(d.designacao);
  c.links       = link.r;
  c.texto       = editor(texto);
  // Título e Assunto por ÚLTIMO: o OTRS regera o Título após mudanças em
  // Localidade/Empresa/Serviço. Espera ele terminar, escreve e confere.
  const ta = await tituloEAssunto(d.mascara);
  c.titulo      = ta.titulo;
  c.assunto     = ta.assunto;

  const falhas = Object.entries(c).filter(([, v]) => v === false).map(([k]) => k);
  let enviado = false;
  if (enviar && !falhas.length) {
    const b = botaoEnviar();
    if (b) { b.click(); enviado = true; }
    else falhas.push('botão Enviar');
  }
  return { ok: !falhas.length, campos: c, falhas, enviado, linkOpcao: link.opcao, slaAlternativo };
}

const API = {
  ler() {
    const p = new URLSearchParams(location.search.replace(/;/g, '&'));
    return {
      ok: true,
      acao: p.get('Action') || '',
      ticketId: p.get('TicketID') || '',
      numero: ((document.body.innerText || document.body.textContent || "").match(/Ticket#\s*(\d{10,})/) || [])[1] || '',
      titulo: tituloChamado(),
      texto: textoTotal()
    };
  },

  // Tela "Alterar Texto Livre" (AgentTicketFreeText). Ordem igual ao processo manual.
  async categorizar({ d, fixos, texto, enviar }) {
    const c = {};
    c.tipo = await escolher(campo('#TypeID', 'Tipo'), fixos.tipo);
    return localidadeEResto(c, { d, fixos, texto, enviar });
  },

  // ↻ da Localidade: refaz a Localidade e retoma o Categorizar até o fim.
  // (Trocar a Localidade limpa Empresa, Nome fantasia, SGF, Serviço, SLA, Site e regera o Título.)
  async refazerLocalidade({ d, fixos, texto, enviar }) {
    const c = {};
    if (!norm(campo('#TypeID', 'Tipo')?.value)) c.tipo = await escolher(campo('#TypeID', 'Tipo'), fixos.tipo);
    return localidadeEResto(c, { d, fixos, texto, enviar });
  },

  // Botão ↻ do painel: apaga o Links de internet e busca a designação de novo.
  async rebuscarLink({ designacao }) {
    const { r, opcao } = await preencherLink(designacao);
    return { ok: r !== false, resultado: r === true ? 'opcao' : r === 'texto' ? 'texto' : 'falha', opcao };
  },

  // Tela de Nota (AgentTicketNote).
  async nota({ assunto, texto, enviar }) {
    const c = {};
    c.aberturaIsp = await escolher(campo(null, 'Abertura chamado ISP'), 'Sim');
    c.assunto     = escrever(campo('#Subject', 'Assunto'), assunto);
    c.texto       = editor(texto);
    const falhas = Object.entries(c).filter(([, v]) => v === false).map(([k]) => k);
    let enviado = false;
    if (enviar && !falhas.length) {
      const b = botaoEnviar();
      if (b) { b.click(); enviado = true; }
      else falhas.push('botão Enviar');
    }
    return { ok: !falhas.length, campos: c, falhas, enviado };
  },

  // No zoom do ticket: abre o popup de Campos Livres ou de Nota.
  abrir(tela) {
    const acao = tela === 'nota' ? 'AgentTicketNote' : 'AgentTicketFreeText';
    const a = document.querySelector(`a[href*="Action=${acao}"]`);
    if (!a) return { ok: false, falhas: ['link ' + acao] };
    a.click();
    return { ok: true };
  },

  // No zoom do ticket: seleciona a fila no "- Mover -". O OTRS move na hora.
  async mover({ fila }) {
    const el = document.getElementById('DestQueueID');
    const ok = await escolher(el, fila);
    return { ok, falhas: ok ? [] : ['fila ' + fila] };
  }
};

API.versao = VERSAO;
window.__arionOTRS = API;
})();
