/* modules/regras.js
 * Regras de negócio do NOC - ATACADO: clientes, operadoras, máscara e textos.
 * Para ajustar um texto exato (ex.: "CLARO S.A" × "CLARO S.A."), mude só aqui.
 */
(function () {

const NG = 'Não Geográficos (Urbanos)';
const UFS = 'AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO'.split(' ');

// mascara: texto da operadora na máscara.
// empresa: texto digitado em "Empresa (Razão social)" e "Empresa (Nome fantasia)".
const OPERADORAS = {
  claro:      { nome: 'Claro',             mascara: 'CLARO S.A.',             empresa: 'CLARO S.A' },
  telefonica: { nome: 'Telefônica (Vivo)', mascara: 'TELEFONICA BRASIL S.A.', empresa: 'TELEFONICA BRASIL S.A' },
  telmex:     { nome: 'Telmex',            mascara: 'TELMEX S.A',             empresa: 'TELMEX DO BRASIL S/A' },
  algar:      { nome: 'Algar Telecom',     mascara: 'ALGAR TELECOM',          empresa: 'ALGAR TELECOM' }
};

// Tipos de identificador no fim da máscara.
const SUFIXOS = {
  ci:      { rotulo: 'Chamado interno',    prefixo: 'CI: ' },
  inc:     { rotulo: 'Chamado Vivo (INC)', prefixo: '' },
  agencia: { rotulo: 'Nº da agência',      prefixo: '' },
  sigla:   { rotulo: 'Sigla',              prefixo: '' }
};

// Ordem importa: o primeiro cliente encontrado vence (título antes do corpo).
const CLIENTES = {
  fust:      { nome: 'Projeto FUST',      localidade: 'Projeto FUST',      prefixo: NG,                 projeto: 'PROJETO FUST',      operadoras: ['telefonica'],          sufixo: 'inc',                                   detectar: /\bFUST\b|\bINEP\b/i },
  bradesco:  { nome: 'BRAD (Bradesco)',   localidade: 'BRAD',              prefixo: 'BRAD',             projeto: 'BRADESCO',          operadoras: ['telefonica', 'telmex'], sufixo: { telefonica: 'agencia', telmex: 'ci' }, detectar: /BRADESCO|\bBRAD\b/i },
  bb:        { nome: 'Projeto BB',        localidade: 'Projeto BB',        prefixo: 'Projeto BB',       projeto: 'PROJETO BB',        operadoras: ['claro'],               sufixo: 'ci',                                    detectar: /PROJETO BB|BANCO DO BRASIL/i },
  cef:       { nome: 'Projeto CEF',       localidade: 'Projeto CEF',       prefixo: 'Projeto CEF',      projeto: 'PROJETO CEF',       operadoras: ['claro'],               sufixo: 'ci',                                    detectar: /PROJETO CEF|CAIXA ECON|\bCEF\b/i },
  correios:  { nome: 'Projeto Correios',  localidade: 'Projeto Correios',  prefixo: 'Projeto Correios', projeto: 'PROJETO CORREIOS',  operadoras: ['claro'],               sufixo: 'ci',                                    detectar: /CORREIOS|\bECT\b/i },
  carrefour: { nome: 'Projeto Carrefour', localidade: 'Projeto Carrefour', prefixo: NG,                 projeto: 'PROJETO CARREFOUR', operadoras: ['claro'],               sufixo: 'ci',                                    detectar: /CARREFOUR/i },
  mcdonalds: { nome: 'Arcos Dourados',    localidade: 'Arcos Dourados',    prefixo: NG,                 projeto: 'ARCOS DOURADOS',    operadoras: ['telefonica', 'claro'], sufixo: 'sigla',                                 detectar: /MC\s?DONALD|ARCOS DOURADOS/i },
  algar:     { nome: 'Projeto Algar',     localidade: 'Projeto EILD Algar - {UF}', prefixo: NG,         projeto: 'PROJETO ALGAR',     operadoras: ['algar'],               sufixo: 'ci',                                    detectar: /ALGAR/i },
  diversos:  { nome: 'Projeto Diversos',  localidade: 'Projeto Diversos',  prefixo: NG,                 projeto: 'PROJETO DIVERSOS',  operadoras: ['claro'],               sufixo: 'ci',                                    detectar: /PROJETO DIVERSOS/i }
};

// Localidade no OTRS: digita "busca" e clica na opção "opcao".
// opcao null = clica na primeira da lista.
const LOCALIDADE_BUSCA = {
  fust:      { busca: 'fust',       opcao: 'Projeto FUST' },
  bradesco:  { busca: 'brad',       opcao: null },
  bb:        { busca: 'bb',         opcao: 'Projeto BB' },
  cef:       { busca: 'cef',        opcao: 'Projeto CEF' },
  correios:  { busca: 'correios',   opcao: 'Projeto Correios' },
  carrefour: { busca: 'carrefour',  opcao: 'Projeto Carrefour' },
  mcdonalds: { busca: 'arcos',      opcao: 'Arcos Dourados' },
  algar:     { busca: 'algar - {UF}', opcao: 'Projeto EILD Algar - {UF}' },
  diversos:  { busca: 'diversos',   opcao: 'Projeto Diversos' }
};

const FIXOS = {
  tipo: 'Restauração',
  servicoSgf: 'INTERNET',
  subServicoSgf: 'Indisponibilidade',
  servico: 'Internet',
  sla: '24 Horas 24x7',
  site: 'NGO - NAO GEOGRAFICO'
};

const FILA = 'NOC - ATACADO';
const ASSUNTO_NOTA = 'NOTA DE ENCAMINHAMENTO';

// ---------------- extração ----------------

// No corpo, só nomes completos: siglas curtas (BRAD, BB, CEF) aparecem em rótulos e listas.
const DETECTAR_CORPO = {
  fust: /NOC[_\s-]?FUST|\bINEP\b/i,
  bradesco: /BRADESCO/i,
  bb: /BANCO DO BRASIL|PROJETO BB\b/i,
  cef: /CAIXA ECON[OÔ]MICA|PROJETO CEF\b/i,
  correios: /CORREIOS/i,
  carrefour: /CARREFOUR/i,
  mcdonalds: /MC\s?DONALD|ARCOS DOURADOS/i,
  algar: /ALGAR TELECOM|EILD ALGAR|PROJETO ALGAR/i,
  diversos: /PROJETO DIVERSOS/i
};

function detectarCliente(titulo, texto) {
  for (const [id, c] of Object.entries(CLIENTES)) if (c.detectar.test(titulo)) return id;
  for (const [id, re] of Object.entries(DETECTAR_CORPO)) if (re.test(texto)) return id;
  return '';
}

// Correios, BB, CEF, Carrefour, Diversos: sempre Claro. FUST: Vivo. Algar: Algar.
// Bradesco: Vivo ou Telmex. McDonald's: Vivo ou Claro. "VIVO" no chamado → Telefônica.
function detectarOperadora(cliente, texto) {
  const c = CLIENTES[cliente];
  if (!c) return '';
  if (c.operadoras.length === 1) return c.operadoras[0];
  if (/\bVIVO\b/i.test(texto)) return 'telefonica';
  if (cliente === 'bradesco') return /TELMEX|EMBRATEL/i.test(texto) ? 'telmex' : '';
  if (cliente === 'mcdonalds') return /\bCLARO\b/i.test(texto) ? 'claro' : 'telefonica';
  return c.operadoras[0];
}

function primeiro(fontes, re) {
  for (const f of fontes) {
    const m = f && f.match(re);
    if (m) return (m[1] || m[0]).trim();
  }
  return '';
}

function detectarUF(titulo, texto, designacao) {
  const cand = [
    primeiro([titulo, texto], /ALGAR\s*-\s*([A-Z]{2})\b/i),
    primeiro([designacao], /^VIVO\.([A-Z]{2})\./i),
    primeiro([titulo], /\s-\s([A-Z]{2})\s-\s/),
    primeiro([texto], /\s-\s*([A-Z]{2})\s+CEP/i)
  ].map(s => s.toUpperCase());
  return cand.find(u => UFS.includes(u)) || '';
}

function extrair({ titulo = '', texto = '' }) {
  const fontes = [titulo, texto];
  const cliente = detectarCliente(titulo, texto);
  const operadora = detectarOperadora(cliente, texto + '\n' + titulo);

  // FUST: designação no formato VIVO.UF.CÓDIGO (ex.: VIVO.BA.BLIVR000017).
  const vivo = primeiro(fontes, /\b(VIVO\.[A-Z]{2}\.[A-Z0-9]+)\b/i).toUpperCase();
  const bl = primeiro(fontes, /\b(B[DL]\d{8,})\b/i).toUpperCase();
  const designacao =
    (cliente === 'fust' ? vivo || bl : bl || vivo) ||
    primeiro(fontes, /DESIGNA(?:[CÇ][AÃ]O|DOR)\s*:?\s*([A-Z0-9][A-Z0-9./_-]{4,})/i);

  const valores = {
    ci: primeiro(fontes, /\bC\.?I\.?\s*:?\s*(\d{4,})/i) || primeiro(fontes, /\bREC(?:\s*ID)?\s*:?\s*(\d{4,})/i) || primeiro(fontes, /CHAMADO INTERNO\s*:?\s*(\d{4,})/i),
    inc: primeiro(fontes, /\bINC\s*:?\s*(\d{6,})\b/i),
    agencia: primeiro(fontes, /\bAG(?:[EÊ]NCIA)?\.?\s*(?:N[º°o]\.?)?\s*:?\s*(\d{3,5})\b/i),
    sigla: primeiro(fontes, /SIGLA\s*:?\s*([A-Z0-9]{2,10})\b/i)
  };

  const d = { cliente, operadora, designacao, uf: '' };
  if (cliente === 'algar') d.uf = detectarUF(titulo, texto, designacao);
  d.identificador = valores[tipoSufixo(d)] || '';
  return completar(d);
}

// ---------------- máscara ----------------

function tipoSufixo(d) {
  const c = CLIENTES[d.cliente];
  if (!c) return 'ci';
  return typeof c.sufixo === 'string' ? c.sufixo : (c.sufixo[d.operadora] || 'ci');
}

function localidade(d) {
  const c = CLIENTES[d.cliente];
  return c ? c.localidade.replace('{UF}', d.uf || '??') : '';
}

function faltando(d) {
  const f = [];
  const c = CLIENTES[d.cliente];
  if (!c) f.push('cliente');
  if (!d.operadora) f.push('operadora');
  else if (c && !c.operadoras.includes(d.operadora)) f.push('operadora inválida para o cliente');
  if (!d.designacao) f.push('designação');
  if (!d.identificador) f.push(SUFIXOS[tipoSufixo(d)].rotulo.toLowerCase());
  if (d.cliente === 'algar' && !UFS.includes(d.uf)) f.push('UF');
  return f;
}

function mascara(d) {
  const c = CLIENTES[d.cliente], op = OPERADORAS[d.operadora];
  const t = tipoSufixo(d);
  return [c.prefixo, op.mascara, 'RESTAURAÇÃO', 'INTERNET', c.projeto, d.designacao, SUFIXOS[t].prefixo + d.identificador].join(' - ');
}

// Recalcula os campos derivados após qualquer edição.
function completar(d) {
  d.tipoSufixo = tipoSufixo(d);
  // FUST: o chamado interno é sempre INC + código (aceita só os números).
  if (d.tipoSufixo === 'inc' && d.identificador) {
    d.identificador = 'INC' + String(d.identificador).toUpperCase().replace(/^INC\s*:?\s*/, '');
  }
  d.faltando = faltando(d);
  d.mascara = d.faltando.length ? '' : mascara(d);
  d.localidade = localidade(d);
  const lb = LOCALIDADE_BUSCA[d.cliente];
  const uf = d.uf || '';
  d.localidadeBusca = lb ? lb.busca.replace('{UF}', uf) : d.localidade;
  d.localidadeOpcao = lb ? (lb.opcao ? lb.opcao.replace('{UF}', uf) : null) : d.localidade;
  d.empresa = d.operadora ? OPERADORAS[d.operadora].empresa : '';
  return d;
}

// ---------------- textos ----------------

const esc = s => String(s || '').replace(/[&<>"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));

// Modelo escolhido: título em negrito, linha de traços separando a máscara.
function textoCategorizacao(d) {
  return '<p><strong>Arion - Central de Atendimento</strong><br>' +
    'Este ticket foi categorizado e encaminhado para a fila Service Desk.<br>' +
    '--------------------------------------------<br>' +
    'Mascara gerada<br>' +
    `${esc(d.mascara)}</p>`;
}

function textoNota() {
  return '<p><strong>Arion - Central de Atendimento</strong></p>' +
    `<p>Ticket encaminhado para a fila: ${FILA}</p>` +
    '<p>Atividade: Aguardando atuação da operadora de transito (ISP)</p>' +
    '<p>Gentileza acompanhar diariamente a tratativa até sua conclusão.</p>';
}

const api = { LOCALIDADE_BUSCA, NG, UFS, OPERADORAS, SUFIXOS, CLIENTES, FIXOS, FILA, ASSUNTO_NOTA, extrair, completar, tipoSufixo, textoCategorizacao, textoNota };
if (typeof self !== 'undefined') self.Regras = api;
if (typeof module !== 'undefined') module.exports = api;

})();
