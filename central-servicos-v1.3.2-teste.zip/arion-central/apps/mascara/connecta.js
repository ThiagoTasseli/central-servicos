// ========================================
// Connecta - selectors, fields and mask
// ========================================

(function () {
  /*
   * Cada campo aceita uma lista de seletores em ordem de prioridade.
   *
   * A captura em popup.js percorre todos os seletores do campo e usa o primeiro
   * que retornar valor. Isso é importante no Connecta porque chamados WO e INC
   * podem renderizar o mesmo dado com IDs diferentes.
   *
   * Para manutenção:
   * - Adicione novos seletores no final da lista quando eles forem fallback.
   * - Coloque seletores mais específicos antes de seletores genéricos.
   * - Evite remover seletores antigos enquanto eles ainda funcionarem em algum
   *   tipo de chamado, pois a própria ordem já resolve a prioridade.
   */
  const selectors = {
    chamado: [
      // Chamados WO.
      '#ar1000000182_data',
      // Chamados INC.
      '#ar1000000161_data',
    ],
    solicitante: [
      '#ar301395300_data',
      '#ar303530000_data',
      // Fallback por link de pessoa. O ID pode variar, mas o caminho personPV
      // identifica o link de perfil do solicitante no Smart IT.
      'a[href*="/personPV/"].displayAsTextContainer',
      'a[href*="/personPV/"]',
    ],
    email: [
      '.email-data-text',
    ],
    sla: [
      '#ar304434661_data',
    ],
    descricao: [
      '#ar1000000151_data',
    ],
  };

  const technicians = [
    'Glenison - CWB',
    'Marlo - CWB',
    'Den\u00edlson - LDB',
    'Cl\u00e1udio - LDB',
    'Filipe Felix - GYN',
    'Thalles Molina - GYN',
  ];

  const titles = [
    '[INSPE\u00c7\u00c3O] [FIDS, WIFI, SONORIZA\u00c7\u00c3O E SALAS T\u00c9CNICAS]',
    '[INSPE\u00c7\u00c3O] [INSPE\u00c7\u00c3O TOTENS DE AUTOATENDIMENTO]',
    '[INSPECAO][CAMERA] Solicita\u00e7\u00e3o [BACKUP DI\u00c1RIO DOS RELAT\u00d3RIOS DAS C\u00c2MERAS - &]',
    '[MICRO][Softw.] Solicita\u00e7\u00e3o [ANTIV\u00cdRUS - &]',
    '[ACOMP. TÉCNICO] (NOME DA EMPRESA)',
    '[APOC] VideoWall Incidente',
    '[APOC] VideoWall Solicitação',
    '[BCBP] Incidente',
    '[BCBP] Solicitação',
    '[CAMERA] Incidente',
    '[CAMERA] Solicitação',
    '[CELULAR] Incidente ',
    '[CELULAR] Solicitação ',
    '[CMES] VideoWall Incidente',
    '[CMES] VideoWall Solicitação',
    '[COLETOR] Incidente',
    '[COLETOR] Solicitação',
    '[CONTROLE DE ACESSO] Incidente ( Local )',
    '[CONTROLE DE ACESSO] Solicitação ( Local )',
    '[CUPPS] Incidente [Check-in:  - Cia Aerea:  - Posição: ]',
    '[CUPPS] Solicitação [Check-in:  - Cia Aerea:  - Posição: ]',
    '[CUPPS] Reposição de Insumos [Check-in:  - Cia Aerea:  - Posição: ]',
    '[CUPPS] Incidente [Embarque (Domestico ou Internacional) - Cia Aerea: - Portão: ]',
    '[CUPPS] Solicitação [Embarque (Domestico ou Internacional) - Cia Aerea: - Portão: ]',
    '[CUPPS] Reposição de Insumos [Embarque (Domestico ou Internacional) - Cia Aerea: - Portão: ]',
    '[CUSS] Incidente [Localidade:  - Cia Aerea:  - TOTEM: ]',
    '[CUSS] Solicitação [Localidade:  - Cia Aerea:  - TOTEM: ]',
    '[CUSS] Reposição de Insumos [Localidade:  - Cia Aerea:  - TOTEM: ]',
    '[DATACENTER] Solicitação',
    '[ESTACIONAMENTO] Cartão Retido - Transação Pendente',
    '[ESTACIONAMENTO] Contador de Vagas',
    '[ESTACIONAMENTO] Falha no EAPC (n° Equipamento)',
    '[ESTACIONAMENTO] Fechamento de caixa',
    '[ESTACIONAMENTO] Incidente',
    '[ESTACIONAMENTO] Não emitiu relatório',
    '[ESTACIONAMENTO] Solicitação',
    '[ESTACIONAMENTO] Transação Pendente',
    '[FBLB] Incidente',
    '[FBLB] Solicitação',
    '[FIDS] Incidente',
    '[FIDS] Solicitação',
    '[GENETEC] Solicitação de Acesso',
    '[GESTÃO DE ACESSO] incidente',
    '[GESTÃO DE ACESSO] Solicitação',
    '[IMPRESSORA] [Contador] Local',
    '[IMPRESSORA] Incidente',
    '[IMPRESSORA] Solicitação ',
    '[INSPEÇÃO]',
    '[LEITOR DE CARTÃO] Incidente',
    '[LEITOR DE CARTÃO] Solicitação',
    '[MICRO] Incidente',
    '[MICRO] Solicitação',
    '[MICRO] [hardw.] Incidente',
    '[MICRO] [hardw.] Solicitação',
    '[MICRO] [softw.] Incidente',
    '[MICRO] [softw.] Solicitação',
    '[OUTLOOK] Incidente',
    '[OUTLOOK] Solicação',
    '[PORTA RESTRITA] Incidente',
    '[PORTA RESTRITA] Solicitação',
    '[PORTÃO DE EMBARQUE] Incidente',
    '[PORTÃO DE EMBARQUE] Solicitação',
    '[RÁDIO COMUNICADOR] Incidente',
    '[RÁDIO COMUNICADOR] Solicitação',
    '[REDE] Analise de Viabilidade Tecnica ',
    '[REDE] Configuração de Porta no Switch [Empresa] [Vlan]',
    '[REDE] Incidente',
    '[REDE] Solicitação',
    '[RELOGIO DE PONTO] Incidente',
    '[RELOGIO DE PONTO] Solicitação',
    '[SAFE - CONTROLE DE ACESSO] Incidente',
    '[SAFE - CONTROLE DE ACESSO] Solicitação',
    '[SAFE] Credencial Não Abre Portas ',
    '[SBD] Incidente',
    '[SBD] Solicitação ',
    '[SICRA] Incidente',
    '[SICRA] Solicitação',
    '[SISO]',
    '[SISTEMA DE SOM] Incidente',
    '[SISTEMA DE SOM] Solicitação',
    '[TABLET] Incidente',
    '[TABLET] Solicitação',
    '[TAG]',
    '[TELEFONIA CISCO] Incidente (nº ramal)',
    '[TELEFONIA CISCO] Solicitação (nº ramal)',
    '[TELEFONIA] Alarme de Panico (PAR METALICO)',
    '[TELEFONIA] Incidente (Ramal)',
    '[TELEFONIA] Solicitação (n° ramal)',
    '[TOTEM] Incidente',
    '[TOTEM] Solicitação',
    '[TV] Incidente',
    '[TV] Solicitação',
    '[ULTRA] Falha Geral',
    '[WMS] Incidente',
    '[WMS] Solicitação',
  ];

  /*
   * Regra de negócio do campo DESCRIÇÃO no Connecta.
   *
   * Em alguns chamados, o campo vem com um bloco cujo título é
   * "NOS DÊ MAIS DETALHES". O suporte N1 não copia esse título, apenas o texto
   * que aparece abaixo dele. Se o título não existir, mantemos a descrição
   * completa exatamente como foi capturada.
   */
  function extractDetailsAfterBusinessTitle(description) {
    const text = (description || '').trim();
    /*
     * Procuramos o título em uma cópia normalizada do texto. Essa cópia remove
     * acentos apenas para comparação, então tanto "NOS DÊ MAIS DETALHES" quanto
     * "NOS DE MAIS DETALHES" são encontrados. O texto original continua sendo o
     * que vai para a máscara, preservando quebras de linha e caracteres.
     */
    const normalizedText = text
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLocaleUpperCase('pt-BR');
    const marker = 'NOS DE MAIS DETALHES';
    const markerIndex = normalizedText.indexOf(marker);

    if (markerIndex === -1) return text;

    return text
      .slice(markerIndex + marker.length)
      .replace(/^[:\s-]+/, '')
      .trim();
  }

  function applyCapture(config, data, setField) {
    let count = 0;

    count += setField(config.fields.chamado, data.chamado);
    count += setField(config.fields.solicitante, data.solicitante);
    count += setField(config.fields.email, data.email);
    count += setField(config.fields.sla, data.sla);
    count += setField(config.fields.descricao, extractDetailsAfterBusinessTitle(data.descricao));

    return count;
  }

  function generateMask(fields, getAtendente) {
    return `${fields.titulo.value.trim()}

CHAMADO: ${fields.chamado.value.trim()}
ATENDENTE: ${getAtendente()}
SOLICITANTE: ${fields.solicitante.value.trim()}
E-MAIL: ${fields.email.value.trim()}
VIOLA\u00c7\u00c3O SLA: ${fields.sla.value.trim()}
DESCRI\u00c7\u00c3O: ${fields.descricao.value.trim()}`;
  }

  window.ConnectaSite = {
    key: 'connecta',
    label: 'Connecta',
    selectors,
    iframeSelector: '#pwa-frame',
    groupId: 'connectaGroup',
    maskOutputId: 'connectaMaskOutput',
    toastId: 'connectaToast',
    fieldIds: {
      titulo: 'connectaTitulo',
      chamado: 'connectaChamado',
      solicitante: 'connectaSolicitante',
      email: 'connectaEmail',
      sla: 'connectaSLA',
      descricao: 'connectaDescricao',
      tecnico: 'connectaTecnico',
    },
    datalists: [
      { id: 'connectaTecnicosList', items: technicians },
    ],
    autocompletes: [
      { inputId: 'connectaTitulo', listId: 'lista', items: titles },
    ],
    applyCapture,
    generateMask,
  };
})();
