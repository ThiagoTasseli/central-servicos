// ========================================
// Service Aide - selectors, fields and mask
// ========================================

(function () {
  /*
   * Seletor usado como plano B para o SLA.
   * O Service Aide pode renderizar esse bloco com muitos containers do ExtJS,
   * entao mantemos o caminho completo apenas quando a captura principal falha.
   */
  const fallbackSlaSelector = '#tabcontainer-body > div.x-panel.x-tabpanel-child.x-panel-default.x-closable.x-panel-closable.x-panel-default-closable > div > div.x-panel.x-panel-default > div > div > div > div.x-panel.ca-panel-collapse-icon-left.ca-panel-collapse-icon-sidebar.ca-panel-no-border.ca-panel-no-shadow.x-box-item.x-panel-ca-sidebar > div.x-panel-body.x-panel-body-ca-sidebar.x-panel-body-ca-sidebar > div.x-container.x-container-default > div:nth-child(1) > div.x-panel-body.x-panel-body-ca-collapsiblepanel.x-panel-body-ca-collapsiblepanel > div.x-container.x-container-default > div.x-container.x-container-default.x-box-layout-ct > div > div > label';

  /*
   * Cada chave representa um campo do popup.
   * Cada array contem seletores em ordem de prioridade para encontrar o mesmo
   * dado dentro da pagina do Service Aide.
   */
  const selectors = {
    chamado: ['label[data-caid="title"]'],
    solicitante: [
      'input[autoidentifier="txtbox_RequesterUserNameVIP"]',
      'input[name="RequesterUserNameVIP"]',
    ],
    ramal: [
      'input[autoidentifier="txtbox_RequesterAltPhone"]',
      'input[name="RequesterAltPhone"]',
      '#textfield-1794-inputEl',
    ],
    email: [
      'input[autoidentifier="txtbox_RequesterAltEmail"]',
      'input[name="RequesterAltEmail"]',
      '#textfield-1795-inputEl',
    ],
    localizacao: ['input[autoidentifier="txtbox_Localiza\u00e7\u00e3o"]'],
    titulo: [
      'textarea[autoidentifier="txtbox_Description"]',
      'textarea[name="Description"]',
      '#textareafield-1839-inputEl',
    ],
    descricao: [
      'textarea[autoidentifier="txtbox_Details"]',
      'textarea[name="DescriptionLong"]',
      '#textareafield-1843-inputEl',
    ],
    slaFallback: [fallbackSlaSelector],
  };

  const technicians = [
    // Lista usada pelo datalist do campo Tecnico.
    'CNF - Gregory Felipe',
    'ARION - GLORIA COIMBRA - CNF',
    'ARION - HAROLDO - Field - CNF - Paulo',
    'ARION - IAGO - CNF FIELD',
    'ARION - IAGO COSTA - CNF - FIELD',
    'CNF - AMARILDO PROEN\u00c7A',
    'CNF - ANTHONY DE JESUS - FIELD - FIELD ARION',
    'CNF - CARLOS SILVESTRE - TEL/CABLING ARION',
    'CNF - ITALO - FIELD ARION',
    'CNF - JO\u00c3O VITOR COIMBRA - FIELD ARION',
    'CNF - MARCOS SOUZA - TEL/CABLING ARION',
    'CRISTIANO PEREIRA - FIELD - CNF',
    'KAROLINE HASTENRETER',
    'VAGNER - CNF',
    'CNF - PAULO - TEL/CABLING ARION',
  ];

  const defaultGroups = [
    // Grupos iniciais; o usuario pode sobrescrever essa lista na aba Config.
    'SUPORTE TI',
    'INFRAESTRUTURA',
    'NOC',
    'HELPDESK N2',
    'REDES',
    'SISTEMAS',
  ];

  function cleanChamado(value) {
    // Extrai apenas o numero do chamado quando o Service Aide devolve texto adicional no titulo.
    const text = value.trim();
    const match = text.match(/\b\d{3}-\d{5,}\b/);
    return match ? match[0] : text;
  }

  function normalizeRequester(value) {
    // Converte "Sobrenome, Nome" para "Nome Sobrenome", deixando nomes comuns como vieram.
    const partes = value.split(',');
    return partes.length === 2 ? `${partes[1].trim()} ${partes[0].trim()}` : value;
  }

  function applyCapture(config, data, setField) {
    // Aplica os dados capturados nos campos do popup e soma quantos campos foram preenchidos.
    let count = 0;

    count += setField(config.fields.chamado, cleanChamado(data.chamado || ''));
    count += setField(config.fields.solicitante, normalizeRequester(data.solicitante || ''));
    count += setField(config.fields.ramal, data.ramal);
    count += setField(config.fields.email, data.email);
    count += setField(config.fields.localizacao, data.localizacao);
    count += setField(config.fields.titulo, data.titulo);
    count += setField(config.fields.descricao, data.descricao);
    count += setField(config.fields.sla, data.sla);

    return count;
  }

  function generateMask(fields, getAtendente) {
    // Monta a mensagem final do Service Aide seguindo o modelo usado pela operacao.
    return `${fields.titulo.value.trim()}

CHAMADO: ${fields.chamado.value.trim()}
ATENDENTE: ${getAtendente()}
SOLICITANTE: ${fields.solicitante.value.trim()}
RAMAL: ${fields.ramal.value.trim()}
E-MAIL: ${fields.email.value.trim()}
LOCALIZA\u00c7\u00c3O: ${fields.localizacao.value.trim()}
VIOLA\u00c7\u00c3O SLA: ${fields.sla.value.trim()}
DESCRI\u00c7\u00c3O: ${fields.descricao.value.trim()}`;
  }

  window.ServiceAideSite = {
    // Contrato consumido pelo popup.js para tratar o Service Aide como um modulo independente.
    key: 'serviceAide',
    label: 'Service Aide',
    selectors,
    defaultGroups,
    groupId: 'serviceGroup',
    maskOutputId: 'serviceMaskOutput',
    toastId: 'serviceToast',
    configurableGroups: true,
    fieldIds: {
      titulo: 'serviceTitulo',
      chamado: 'serviceChamado',
      solicitante: 'serviceSolicitante',
      ramal: 'serviceRamal',
      email: 'serviceEmail',
      localizacao: 'serviceLocalizacao',
      sla: 'serviceSLA',
      descricao: 'serviceDescricao',
      tecnico: 'serviceTecnico',
    },
    datalists: [
      { id: 'serviceTecnicosList', items: technicians },
    ],
    applyCapture,
    generateMask,
  };
})();
