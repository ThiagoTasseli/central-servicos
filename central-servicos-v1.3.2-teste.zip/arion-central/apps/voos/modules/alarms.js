/* modules/alarms.js
 * Cálculo puro dos alarmes de Inspeção/Acompanhamento a partir dos voos e
 * dos minutos de antecedência configurados na aba "Alarme".
 * As chamadas reais a chrome.alarms ficam em background.js — este módulo
 * só decide QUANDO cada alarme deveria disparar, para que popup (lista de
 * próximos alertas) e background (agendamento) usem exatamente a mesma
 * lógica.
 */
(function () {

const { formatHHMM, formatISODate, dateFromISOAndHHMM } = self.Fmt;

const ALARM_PREFIX = "flight-alert::";

function alarmName(flightId, kind) {
  return `${ALARM_PREFIX}${flightId}::${kind}`;
}

function parseAlarmName(name) {
  if (!name.startsWith(ALARM_PREFIX)) return null;
  const rest = name.slice(ALARM_PREFIX.length);
  const lastSep = rest.lastIndexOf("::");
  if (lastSep === -1) return null;
  return { flightId: rest.slice(0, lastSep), kind: rest.slice(lastSep + 2) };
}

/**
 * Gera a lista de alarmes possíveis (Inspeção e Acompanhamento) para os
 * voos informados, usando os minutos de antecedência configurados como
 * padrão — e aplicando, por cima, qualquer ajuste individual feito pelo
 * usuário na aba Alarme (horário próprio e/ou ativado/desativado), no
 * estilo de um alarme de despertador de celular.
 * Cada entrada traz o horário do evento e o horário em que o alerta deve
 * disparar (evento - minutos, ou o horário customizado).
 */
function computeAlarmEntries(flights, alarmSettings, overrides = {}) {
  const minutosInspecao = Number(alarmSettings?.minutosInspecao ?? 15);
  const minutosAcompanhamento = Number(alarmSettings?.minutosAcompanhamento ?? 10);
  const entries = [];

  for (const flight of flights) {
    entries.push(
      buildEntry(flight, "inspecao", flight.inspecaoTimestamp, flight.inspecaoTime, minutosInspecao, overrides)
    );
    entries.push(
      buildEntry(
        flight,
        "acompanhamento",
        flight.acompanhamentoTimestamp,
        flight.acompanhamentoTime,
        minutosAcompanhamento,
        overrides
      )
    );
  }

  return entries.sort((a, b) => a.alarmeTimestamp - b.alarmeTimestamp);
}

function buildEntry(flight, kind, eventoTimestamp, horarioEvento, minutosAntes, overrides) {
  const id = alarmName(flight.id, kind);
  const defaultTimestamp = eventoTimestamp - minutosAntes * 60 * 1000;

  const entry = {
    id,
    flightId: flight.id,
    kind,
    empresa: flight.empresa,
    numeroVoo: flight.numeroVoo,
    horarioPartida: flight.horarioVoo,
    horarioEvento,
    eventoTimestamp,
    alarmeMinutosAntes: minutosAntes,
    alarmeTimestamp: defaultTimestamp,
    enabled: true,
    customTime: false,
  };

  const override = overrides[id];
  if (override) {
    if (override.enabled === false) entry.enabled = false;
    if (override.hhmm) {
      // Mantém a mesma data-base do alarme padrão, só troca o horário —
      // equivalente a arrastar o ponteiro de um despertador de celular.
      const baseDateISO = formatISODate(new Date(defaultTimestamp));
      entry.alarmeTimestamp = dateFromISOAndHHMM(baseDateISO, override.hhmm).getTime();
      entry.customTime = true;
    }
  }

  entry.alarmeHHMM = formatHHMM(new Date(entry.alarmeTimestamp));
  return entry;
}

// ---------- Alarmes próprios (tarefas e lembretes) ----------
// Não dependem de voo. Repetir: "nao" (uma vez), "diario" ou "semana" (seg a sex).
const CUSTOM_PREFIX = "custom-alert::";
const REPETIR_LABEL = { nao: "Uma vez", diario: "Diário", semana: "Seg a sex" };
const TIPO_LABEL = { tarefa: "Tarefa", lembrete: "Lembrete" };

function customAlarmName(id) {
  return `${CUSTOM_PREFIX}${id}`;
}

function parseCustomAlarmName(name) {
  return typeof name === "string" && name.startsWith(CUSTOM_PREFIX) ? name.slice(CUSTOM_PREFIX.length) : null;
}

function atHHMM(date, hhmm) {
  const [h, m] = String(hhmm || "00:00").split(":").map(Number);
  const d = new Date(date);
  d.setHours(h || 0, m || 0, 0, 0);
  return d;
}

/** Data (ISO) da próxima vez que o horário acontece, a partir de agora. */
function nextDateISO(hhmm, now = Date.now()) {
  const d = atHHMM(now, hhmm);
  if (d.getTime() <= now) d.setDate(d.getDate() + 1);
  return formatISODate(d);
}

/** Próximo disparo (timestamp) de um alarme próprio, ou null se não há. */
function nextCustomTimestamp(alarm, now = Date.now()) {
  if (alarm.repetir === "nao" || !alarm.repetir) {
    if (!alarm.data) return null;
    const ts = dateFromISOAndHHMM(alarm.data, alarm.hhmm).getTime();
    return ts > now ? ts : null;
  }
  for (let i = 0; i < 8; i++) {
    const d = atHHMM(now, alarm.hhmm);
    d.setDate(d.getDate() + i);
    const dia = d.getDay();
    if (alarm.repetir === "semana" && (dia === 0 || dia === 6)) continue;
    if (d.getTime() > now) return d.getTime();
  }
  return null;
}

/** Quando agendar no chrome.alarms (adiamento tem prioridade). */
function customFireTimestamp(alarm, now = Date.now()) {
  if (alarm.snoozeUntil && alarm.snoozeUntil > now) return alarm.snoozeUntil;
  return alarm.enabled === false ? null : nextCustomTimestamp(alarm, now);
}

function customAlarmStatus(alarm, now = Date.now()) {
  if (alarm.enabled === false) return "desativado";
  return nextCustomTimestamp(alarm, now) ? "agendado" : "concluido";
}

/** Só os alarmes ativados cujo horário de disparo ainda está no futuro (agendáveis) */
function futureAlarmEntries(entries, now = Date.now()) {
  return entries.filter((e) => e.enabled !== false && e.alarmeTimestamp > now);
}

/** Status textual para exibição na lista de alarmes */
function alarmStatus(entry, now = Date.now()) {
  if (entry.enabled === false) return "desativado";
  if (entry.eventoTimestamp <= now) return "concluido";
  if (entry.alarmeTimestamp <= now) return "disparado";
  return "agendado";
}

if (typeof self !== "undefined") {
  self.Alarms = {
    ALARM_PREFIX,
    alarmName,
    parseAlarmName,
    computeAlarmEntries,
    futureAlarmEntries,
    alarmStatus,
    CUSTOM_PREFIX,
    REPETIR_LABEL,
    TIPO_LABEL,
    customAlarmName,
    parseCustomAlarmName,
    nextDateISO,
    nextCustomTimestamp,
    customFireTimestamp,
    customAlarmStatus,
  };
}

})();
