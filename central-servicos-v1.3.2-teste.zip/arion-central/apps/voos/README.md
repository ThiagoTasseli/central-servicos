# ARION · Central de Voos

Extensão de navegador (Manifest V3) para a operação de **inspeção e acompanhamento técnico de voos internacionais de partida** (CUPPS). A partir da planilha de voos do dia, ela calcula os horários, dispara alarmes, **preenche o chamado no ServiceAide** e **gera o informe** no padrão da operação.

**Versão:** 4.0.0 · **Navegadores:** Chrome, Edge, Brave (painel lateral) e Firefox 121+ (barra lateral)

---

## Sumário

1. [Visão geral](#1-visão-geral)
2. [Funcionalidades](#2-funcionalidades)
3. [Como funciona](#3-como-funciona)
4. [Tecnologias utilizadas](#4-tecnologias-utilizadas)
5. [Arquitetura e estrutura de arquivos](#5-arquitetura-e-estrutura-de-arquivos)
6. [Instalação](#6-instalação)
7. [Guia de uso](#7-guia-de-uso)
8. [Configurações](#8-configurações)
9. [Permissões e privacidade](#9-permissões-e-privacidade)
10. [Compatibilidade entre navegadores](#10-compatibilidade-entre-navegadores)
11. [Solução de problemas](#11-solução-de-problemas)
12. [Decisões técnicas](#12-decisões-técnicas)
13. [Limitações conhecidas](#13-limitações-conhecidas)
14. [Histórico de versões](#14-histórico-de-versões)

---

## 1. Visão geral

Para cada voo internacional de partida, o operador precisa:

- abrir um chamado de **Inspeção** (4 horas antes da partida);
- abrir um chamado de **Acompanhamento** (1 hora antes da partida);
- registrar o **informe** de cada chamado, com número, solicitante, SLA e descrição.

Feito manualmente, isso significa calcular horários, montar textos padronizados e preencher dezenas de campos por voo. A extensão automatiza esse ciclo:

| Etapa | Antes | Com a extensão |
|---|---|---|
| Descobrir os voos do dia | Filtrar a planilha à mão | Importar o arquivo; a lista aparece pronta |
| Calcular horários | Subtrair 4 h e 1 h de cada voo | Calculado automaticamente |
| Lembrar de abrir o chamado | Atenção do operador | Alarme configurável, com adiar e silenciar |
| Preencher o ServiceAide | Digitar campo a campo | Botão **Colar** |
| Montar o informe | Copiar e reescrever vários campos | Botão **Copiar informe** |

---

## 2. Funcionalidades

### 2.1 Consulta de voos
- Importação de planilha `.xlsx`, `.xls` ou `.csv` por arraste ou seleção.
- Reconhecimento tolerante de colunas: ignora maiúsculas, acentos, espaços e underscores.
- Localiza o cabeçalho mesmo que não esteja na primeira linha (verifica as 15 primeiras).
- Filtro automático: **Tipo de Voo = Partida**, **Natureza = Internacional** e **data selecionada**.
- Tabela-resumo e cards individuais, ordenados por horário.
- Inspeção e Acompanhamento que cruzam a meia-noite são tratados corretamente.

### 2.2 Chamados prontos
- Máscara e descrição geradas no padrão da operação, com todos os campos editáveis.
- Botões **Copiar** por campo, e **Copiar texto** para o chamado completo.
- Marcação visual de cada chamado já colado (✓), persistida entre sessões.
- **Copiar todos os chamados** de todos os voos do dia.

### 2.3 Colar no ServiceAide
Um clique preenche o formulário "Acompanhamento técnico de voo" aberto no navegador:

| Campo | Valor |
|---|---|
| Nome | Digita o texto de busca, aperta Enter, escolhe a pessoa na janela e aguarda o E-mail se completar |
| Telefone | Preenchido somente depois do Nome |
| Descrição | Máscara do chamado |
| Detalhes | Texto da descrição |
| Matrícula | `N/A` |
| Departamento | Escolhido na lista: Azul, Tap ou Latam; demais companhias, Operações |
| Localização | `CHECK IN <COMPANHIA>`, escolhido na lista de sugestões |
| Identificação do equipamento | `N/A` |

Os campos preenchidos piscam em verde. O operador revisa e clica em **Salvar** no ServiceAide.

### 2.4 Copiar informe
Com o chamado aberto no ServiceAide, **Copiar informe** captura os dados da tela e monta o informe:

```
[INSPECAO][CUPPS] Suporte/Outros LATAM INSPEÇÃO 19:40 - 23:40

CHAMADO: 100-28152
ATENDENTE: <nome configurado>
SOLICITANTE: Nome Sobrenome
RAMAL: <telefone>
E-MAIL: <e-mail>
LOCALIZAÇÃO: CHECK IN LATAM
VIOLAÇÃO SLA: 09/10/2026 04:14
DESCRIÇÃO: <detalhes do chamado>
```

A **violação do SLA** é lida da própria tela do ServiceAide. Se não existir, usa o horário do clique.

### 2.5 Alarmes
- Alarme antes de cada Inspeção (padrão **15 min**) e Acompanhamento (padrão **10 min**).
- Horário e liga/desliga **individuais**, no estilo despertador de celular.
- Notificação do sistema com som em repetição, **Adiar 5 min** e **Desativar**.
- Alarmes disparam com o painel fechado.
- **Silenciar:** sino no cabeçalho, ou por 30 min, 1 h, 2 h ou até reativar. Silenciado, a notificação continua aparecendo, sem som. Há também **Parar som** e **Testar som**.

### 2.6 Interface
- Identidade visual ARION: grafite, laranja `#FF8440` e verde `#00BF9A`, com o logotipo em branco.
- Tema escuro (padrão) e claro.
- Acessibilidade: foco visível, rótulos ARIA e respeito a `prefers-reduced-motion`.

---

## 3. Como funciona

```mermaid
flowchart LR
    A[Planilha<br/>xlsx / xls / csv] --> B[Leitura e<br/>normalização]
    B --> C[(chrome.storage.local<br/>voos por dia)]
    C --> D[Filtro:<br/>Partida + Internacional + data]
    D --> E[Cálculo:<br/>Inspeção −4h<br/>Acompanhamento −1h]
    E --> F[Cards de voo]
    E --> G[Alarmes<br/>chrome.alarms]
    F -->|Colar| H[ServiceAide<br/>preenche formulário]
    H -->|chamado salvo| I[Copiar informe<br/>captura a tela]
    I --> J[Informe na<br/>área de transferência]
```

### Colar: o que acontece por baixo
1. A extensão localiza a aba do ServiceAide (`https://*.serviceaide.com/*`) e a traz para a frente.
2. Injeta `modules/sa-page.js` em todos os frames da aba, com `chrome.scripting.executeScript`.
3. O script localiza cada campo, primeiro pelos **seletores internos** do site (`autoidentifier`, `name`) e, se não encontrar, pelo **rótulo visível** ("Nome", "Departamento" etc.).
4. Para campos de texto, simula a digitação e dispara `input`, `change`, `keydown`, `keyup` e `blur`, para que o site reconheça o valor.
5. Para a **janela de busca** (Nome): digita, envia Enter, encontra o nome na janela, clica e aguarda o E-mail se completar.
6. Para **listas de seleção** (Departamento): abre a lista, rola até a opção, clica e confere se o campo ficou com o valor.
7. Para **autocomplete** (Localização): digita, espera as sugestões e clica na opção correspondente.
8. Devolve à extensão quais campos foram preenchidos e quais falharam.

### Copiar informe: o que acontece por baixo
1. Injeta o mesmo script e lê os campos do chamado pelos seletores do ServiceAide.
2. Extrai o número do chamado com a expressão `\d{3}-\d{5,}`.
3. Converte "Sobrenome, Nome" em "Nome Sobrenome" e aplica capitalização.
4. Lê o SLA do bloco "Resolver em" da tela.
5. Monta o texto e copia com `navigator.clipboard.writeText`.

---

## 4. Tecnologias utilizadas

| Camada | Tecnologia | Uso |
|---|---|---|
| Plataforma | **WebExtensions, Manifest V3** | Estrutura da extensão em Chrome, Edge, Brave e Firefox |
| Linguagem | **JavaScript (ES2020+), sem frameworks** | Toda a lógica; sem build e sem dependências em tempo de execução |
| Interface | **HTML5 + CSS3** | Design system com *CSS custom properties*, grid, flexbox e temas claro e escuro |
| Planilhas | **SheetJS (`xlsx.full.min.js`)** | Leitura local de `.xlsx`, `.xls` e `.csv` |
| Armazenamento | **`chrome.storage.local`** (`unlimitedStorage`) | Voos por dia, configurações, status, alarmes e tema |
| Agendamento | **`chrome.alarms`** | Alarmes que sobrevivem ao fechamento do painel |
| Alertas | **`chrome.notifications`** | Notificação do sistema |
| Áudio | **Documento `offscreen`** (Chromium) e `Audio` no background (Firefox) | Som de alerta em repetição |
| Painel | **`sidePanel`** (Chromium) e **`sidebar_action`** (Firefox) | Interface que não fecha ao trocar de janela |
| Integração | **`chrome.scripting`**, **`chrome.tabs`** e *content scripts* injetados | Ler e preencher o ServiceAide |
| Área de transferência | **Clipboard API** | Cópia de campos, chamados e informes |
| Módulos | **IIFE + `self.*`** | Mesmos arquivos no painel (`<script>`) e no background (`importScripts`) |

**Validação e testes**
- **Mozilla `addons-linter`:** validação do manifesto para o Firefox, sem erros.
- **Playwright + Chromium:** teste ponta a ponta em um formulário simulado do ServiceAide, cobrindo Colar (8 campos), lista de Departamento, janela de busca do Nome, autocomplete da Localização, Copiar informe e silenciar alarmes.

---

## 5. Arquitetura e estrutura de arquivos

```
VoosBH-Extension/
├── manifest.json            Manifesto MV3 (+ configurações do Firefox)
├── background.js            Alarmes, notificações, som, mudo, toggle da barra lateral (Firefox)
├── popup.html / .css / .js  Interface: abas Voos, Configurações e Alarme
├── mode.js                  Detecta o modo (painel, barra lateral, aba ou popup) e ajusta o tamanho
├── offscreen.html / .js     Documento só para tocar o som (Chromium)
├── assets/                  Logotipo ARION em branco
├── icons/                   Ícones 16, 48 e 128 px
├── sounds/alert.wav         Som do alerta
├── libs/xlsx.full.min.js    SheetJS
└── modules/
    ├── formatters.js        Datas, horas, normalização de texto
    ├── spreadsheet.js       Mapeamento de colunas, leitura, filtro e cálculo de horários
    ├── templates.js         Textos dos chamados, campos do ServiceAide, informe, regra de departamento
    ├── storage.js           Acesso único ao storage; chaves centralizadas; estado de mudo
    ├── alarms.js            Cálculo puro dos alarmes (usado pelo painel e pelo background)
    ├── clipboard.js         Cópia com tratamento de erro
    ├── autofill.js          Ponte painel ↔ ServiceAide (Colar e capturar)
    └── sa-page.js           Script injetado na página: localiza campos, preenche e captura
```

**Responsabilidades**

| Contexto | Arquivos | Papel |
|---|---|---|
| Painel (interface) | `popup.*`, `mode.js`, `modules/*` | Importar, listar, editar, colar e copiar |
| Background | `background.js`, `modules/*` | Alarmes, notificações, som e mudo |
| Página do ServiceAide | `modules/sa-page.js` | Ler e preencher o formulário |
| Offscreen | `offscreen.*` | Reproduzir o som no Chromium |

---

## 6. Instalação

### Chrome, Edge e Brave
1. Descompacte o `.zip`.
2. Abra `chrome://extensions` (ou `edge://extensions`).
3. Ative o **Modo do desenvolvedor**.
4. Clique em **Carregar sem compactação** e selecione a pasta que contém o `manifest.json`.
5. Clique no ícone da extensão: o painel lateral abre.

### Firefox (temporária)
1. Abra `about:debugging` e clique em **Este Firefox**.
2. Clique em **Carregar extensão temporária** e escolha o `manifest.json`.
3. Em `about:addons`, abra a extensão, vá em **Permissões** e ative o acesso a `serviceaide.com`.
4. Clique no ícone: a **barra lateral** abre e fica aberta.

Extensões temporárias somem quando o Firefox fecha e precisam ser carregadas de novo.

### Firefox (permanente)
- **Assinatura da Mozilla:** envie o `.zip` ao addons.mozilla.org como versão **não listada** (gratuito). O `.xpi` assinado instala como uma extensão comum. O ID fixo já está no manifesto: `voosbh@grupoarion.com.br`.
- **Firefox Developer Edition ou ESR:** em `about:config`, defina `xpinstall.signatures.required` como `false`.

---

## 7. Guia de uso

1. **Importe a planilha** na aba **Voos**. Colunas esperadas: Tipo de Voo, Natureza, Data do Voo, Companhia Aérea, Número do Voo, Horário de Partida (e, opcionalmente, Rota, Número de Assentos, Modelo da Aeronave).
2. **Escolha a data.** Os voos internacionais de partida aparecem em ordem de horário.
3. **Abra o formulário** "Acompanhamento técnico de voo" no ServiceAide, em uma aba.
4. No card do voo, clique em **Colar Inspeção** ou **Colar Acomp.**
5. **Revise e salve** o chamado no ServiceAide.
6. Com o chamado salvo, clique em **Copiar informe** no card e cole onde precisar.
7. Use **Editar / copiar campos** para ajustar algum texto antes de colar, ou para copiar campo a campo.
8. Na aba **Alarme**, ajuste a antecedência, edite horários e silencie quando necessário.

---

## 8. Configurações

Todas ficam na aba **Configurações** e são salvas localmente.

| Grupo | Campo | Descrição |
|---|---|---|
| Chamados | Atendente, Solicitante, Ramais, E-mail | Usados nos textos dos chamados e do informe |
| ServiceAide | Matrícula | Valor do campo Matrícula (padrão `N/A`) |
| ServiceAide | Identificação do equipamento | Valor do campo (padrão `N/A`) |
| ServiceAide | Prefixo da Localização | Prefixo antes da companhia (padrão `CHECK IN`) |
| ServiceAide | Nome: texto da busca / clicar em | O que digitar e em quem clicar na janela de busca |
| ServiceAide | Telefone | Preenchido depois do Nome |
| ServiceAide | Departamento = companhia / demais | Lista de companhias com departamento próprio e o departamento padrão para as outras |
| Informe | Violação SLA, horas | Horas somadas ao clique quando a tela não traz o SLA |
| Alarme | Minutos de antecedência | Padrão de 15 min (Inspeção) e 10 min (Acompanhamento) |

---

## 9. Permissões e privacidade

| Permissão | Motivo |
|---|---|
| `storage`, `unlimitedStorage` | Guardar voos, configurações e status no próprio navegador |
| `alarms` | Agendar os alertas |
| `notifications` | Exibir os alertas |
| `offscreen` | Tocar o som de alerta (Chromium) |
| `sidePanel` | Painel lateral (Chromium) |
| `scripting` | Injetar o script que lê e preenche o ServiceAide |
| `host_permissions: https://*.serviceaide.com/*` | Único site em que a extensão atua |

**Privacidade**
- Nenhum dado é enviado a servidores. Tudo é processado e armazenado **localmente**.
- A planilha é lida no próprio navegador.
- A extensão só atua em `serviceaide.com`, e somente quando o operador clica em Colar ou Copiar informe.
- Declara `data_collection_permissions: none` para o Firefox.
- **Limpar dados** (no rodapé) remove planilha, status e alarmes.

---

## 10. Compatibilidade entre navegadores

| Recurso | Chrome / Edge / Brave | Firefox 121+ |
|---|---|---|
| Interface | Painel lateral fixo | Barra lateral fixa |
| Colar e Copiar informe | Sim | Sim (liberar acesso a `serviceaide.com`) |
| Alarmes e som | Sim, mesmo com o painel fechado | Sim, com o Firefox aberto |
| Notificação com botões Adiar e Desativar | Sim | Não; use os botões do card no painel |
| Instalação permanente | Carregar a pasta (modo desenvolvedor) | Exige assinatura da Mozilla |

---

## 11. Solução de problemas

| Sintoma | Causa provável | O que fazer |
|---|---|---|
| "ServiceAide não está aberto" | Não há aba do ServiceAide | Abra o formulário e tente de novo |
| "Sem acesso à aba do ServiceAide" | Permissão do site não liberada | No Firefox, ative em `about:addons` > Permissões; em qualquer navegador, recarregue a extensão e a página |
| Campo não preenchido | Rótulo ou seletor mudou no site | A mensagem indica o campo. Selecione à mão e avise para ajustar |
| "Departamento: opção não encontrada" | Nome da opção diferente do configurado | Confira o nome na lista e ajuste em Configurações |
| Nome sem E-mail | Pessoa não foi escolhida na janela | Escolha manualmente; confira o texto "clicar em" em Configurações |
| Informe sem número do chamado | Chamado ainda não salvo | Salve o chamado ou digite o número quando a extensão perguntar |
| Planilha não reconhecida | Cabeçalho com outro nome | A extensão informa qual coluna faltou; renomeie na planilha |
| Sem som no alarme | Alarmes silenciados | Verifique o sino no cabeçalho e a aba Alarme |
| Firefox: extensão some ao reabrir | Extensão temporária | Assine na Mozilla (seção 6) |

---

## 12. Decisões técnicas

- **Painel fixo em vez de popup.** Um popup fecha ao arrastar um arquivo, trocar de janela ou colar em outro lugar, e perde o estado. No Firefox, o popup também fecha ao perder o foco; por isso o ícone abre a barra lateral.
- **Campos localizados pelo rótulo, com seletores como prioridade.** Os seletores internos do ServiceAide são mais precisos; o rótulo visível serve de reserva se a interface mudar.
- **Ordem de preenchimento importa.** O Nome vem primeiro porque a janela de busca completa o E-mail; o Telefone só entra depois.
- **Campos bloqueados não são pulados.** Se o campo ao lado do rótulo é somente leitura, a busca para ali, para não escrever no campo de outro rótulo.
- **Datas com aritmética real** (`Date` e milissegundos), para tratar corretamente horários que cruzam a meia-noite.
- **Reagendamento total dos alarmes** a cada mudança de planilha, data ou antecedência: mais simples e sem risco de alarmes duplicados.
- **Voos armazenados por dia** (`flightsByDate::AAAA-MM-DD`): o painel carrega apenas o dia em uso.
- **Módulos compartilhados.** Os mesmos arquivos servem ao painel e ao background, sem duplicar a lógica.
- **Textos fiéis à especificação.** A diferença entre "INDENTIFICAR" (Inspeção) e "IDENTIFICAR" (Acompanhamento) é proposital.

---

## 13. Limitações conhecidas

- A integração depende da estrutura atual do ServiceAide. Mudanças no site podem exigir ajuste nos seletores.
- O Colar e o Copiar informe foram validados em um formulário simulado e na lógica da extensão arion-plugin; o comportamento no ambiente real deve ser confirmado em uso.
- No Firefox, a instalação permanente exige assinatura, e as notificações não têm botões.
- O formulário do ServiceAide precisa estar aberto em uma aba comum do navegador.

---

## 14. Histórico de versões

| Versão | Principais mudanças |
|---|---|
| **4.0.0** | Firefox: ícone abre a barra lateral fixa. "Copiar informe" no mesmo estilo de "Editar / copiar campos" |
| 3.1.0 | Copiar informe com a lógica da arion-plugin (captura do ServiceAide). Colar com seletores reais do site. Correção do popup do Firefox |
| 3.0.1 | Departamento tratado como lista de seleção |
| 3.0.0 | Colar Nome (janela de busca), Telefone e Departamento. Informes INS e AC |
| 2.2.0 | Botão Colar no ServiceAide. Silenciar alarmes. Identidade visual ARION |
| 2.1.0 | Versão base: consulta de voos, chamados, alarmes |

---

**Grupo ARION** · Uso interno
