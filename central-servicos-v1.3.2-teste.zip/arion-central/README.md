# ARION · Central de Ferramentas — v1.3.0 (TESTE)

> **Versão de teste, uso interno.** Use em paralelo ao processo normal.
> Achou problema? Guia → "Copiar dados para relatar problema" e envie o texto.

## O que testar nesta versão

1. Visual igual nas 4 ferramentas (cabeçalho, cores, fontes, botões, campos).
2. Tema claro/escuro no trilho (☀/☾): troca tudo de uma vez.
3. Funciona sem internet externa (fontes locais).
4. Importar planilha de voos (.xlsx, .xls, .csv) — biblioteca nova.
5. Capturas e preenchimentos de cada ferramenta continuam iguais.
6. Guia → "Limpar agora": apaga chamados e solicitantes com mais de 7 dias.
7. Opcional: aviso de versão nova (ver `versao.exemplo.json`).

Uma extensão só, com quatro ferramentas. Navegação por ícones no trilho lateral.

| Ícone | Ferramenta | Objetivo | Onde usar |
|---|---|---|---|
| 📖 Guia | Início | Objetivo e passo a passo de cada ferramenta | — |
| 💬 Máscara | Máscara de Chamado | Captura o chamado e gera a máscara do WhatsApp | Service Aide, Connecta |
| 🖧 NOC | NOC Atacado | Categoriza e encaminha para a fila NOC - ATACADO | OTRS |
| 📋 Chamados | Preenchimento de Chamados | Preenche o formulário e gera o modelo de texto | ServiceAide |
| ✈ Voos | Central de Voos | Planilha de voos, alarmes CUPPS, chamados e informes | Planilha + ServiceAide |

## Instalar (Chrome / Edge / Brave)

1. Desinstale as extensões antigas (Máscara, NOC Atacado, Preenchimento, Central de Voos).
2. Abra `chrome://extensions` e ligue o **Modo do desenvolvedor**.
3. **Carregar sem compactação** → selecione a pasta `arion-central`.
4. Fixe o ícone ARION. Clique nele (ou `Alt+Shift+A`) para abrir o painel lateral.

Firefox 128+: `about:debugging` → **Carregar extensão temporária** → `manifest.json`. Abre na barra lateral.

> A extensão nova tem outro ID. Configurações das antigas não migram:
> refaça nome do atendente, grupos e reimporte a planilha de voos.

## Como navegar

- **Trilho de ícones** à esquerda. Clique para trocar de ferramenta.
- **Botão no topo do trilho** (ou `Alt+0`): recolhe a barra para uma faixa fina e expande de novo. Fica salvo.
- **Ponto colorido** no ícone: site da aba atual combina com a ferramenta.
- **Ponto laranja pulsando** em Voos: alarme disparado.
- **Bandeja / Fixar** no rodapé do trilho: alterna o modo de abrir.
  - *Lateral* (padrão): painel fixo ao lado da página, não fecha ao trocar de foco.
  - *Bandeja*: janelinha que abre no ícone ARION e fecha ao clicar fora.
  - A escolha fica salva e vale para os próximos cliques no ícone.
- **?** no rodapé do trilho: passo a passo da ferramenta aberta.
- **↗** abre a Central em uma aba inteira.
- `Alt+1` a `Alt+5`: Guia, Máscara, NOC, Chamados, Voos.
- Trocar de ícone não perde o que foi preenchido. A última ferramenta usada reabre sozinha.

## Estrutura

```
arion-central/
├── manifest.json        ← único; soma permissões e sites das 4 extensões
├── background.js        ← único; painel lateral + alarmes/notificações dos voos
├── offscreen.html/.js   ← som do alarme (Chrome)
├── sounds/alert.wav
├── icons/               ← ícone ARION (marca oficial)
├── shared/              ← design system único
│   ├── arion-ds.css     ← tokens de cor/tema, fontes, cabeçalho padrão
│   ├── theme-sync.js    ← tema claro/escuro em todas as páginas
│   ├── fonts/           ← DM Sans e Syne (locais, licença OFL)
│   └── arion-logo-white.png
├── hub/                 ← casca: trilho de ícones, guia, ajuda, aviso de alarme
│   ├── index.html · hub.css · hub.js
│   └── tools.js         ← cadastro das ferramentas (nome, cor, ícone, guia)
└── apps/
    ├── mascara/         ← antiga "Grupo Arion - Máscara de Chamado"
    ├── noc-atacado/     ← antiga "ARION · NOC Atacado"
    ├── preenchimento/   ← antiga "ARION · Preenchimento de Chamados"
    └── voos/            ← antiga "ARION · Central de Voos"
```

Cada ferramenta roda na própria página (iframe da extensão), com o código original.
Ajustes feitos na junção:

- Caminhos dos scripts injetados nas páginas apontam para `apps/<ferramenta>/…`.
- Central de Voos usa `window.__arionSAVoos` para não colidir com o Preenchimento no ServiceAide.
- Máscara: largura fluida e sem o botão "fixar na lateral" (já está no painel).
- Backgrounds unidos em um só.

## Padrão visual (v1.3.0)

- Cabeçalho grafite com logo ARION branco, título curto e faixa laranja/branco/verde.
- Laranja `#FF8440` = ação principal. Verde `#00BF9A` = foco, sucesso, ação secundária.
- Campos e botões com o mesmo tamanho, borda e raio em todas as ferramentas.
- Títulos em Syne, texto em DM Sans.
- Cores ficam só em `shared/arion-ds.css` (tokens `--ds-*`). Cada ferramenta mapeia suas variáveis no próprio CSS/skin.

## Segurança e privacidade (v1.3.0)

- Texto vindo da planilha e das páginas é escapado antes de ir para a tela.
- SheetJS 0.20.3 (corrige falhas da 0.18.5). Obtido do espelho npm `@e965/xlsx`;
  antes de produção, troque `apps/voos/libs/xlsx.full.min.js` pelo arquivo oficial de cdn.sheetjs.com.
- Sem chamadas a Google Fonts. Nenhum dado sai do navegador.
- Chamados do NOC e formulário do Preenchimento são apagados após 7 dias (limpeza diária).

## Aviso de versão nova (opcional)

Coloque um `versao.json` num servidor da intranet e informe o endereço no Guia:

```json
{ "versao": "1.3.1", "download": "\\\\servidor\\arion\\arion-central-v1.3.1.zip", "notas": "Correções do teste." }
```

## Adicionar uma ferramenta nova

1. Copie a pasta para `apps/<id>/`.
2. Adicione um item em `hub/tools.js` (nome, cor, ícone SVG, objetivo, passos, sites).
3. Some permissões e `host_permissions` no `manifest.json`.
4. Se injetar scripts, use caminho a partir da raiz: `apps/<id>/arquivo.js`.
