// ARION · Preenchimento de Chamados — painel lateral
// Fluxo: capturar (opcional) → verificar entradas → inserir no formulário → gerar texto → copiar.
const api = globalThis.browser ?? globalThis.chrome;
const $ = (id) => document.getElementById(id);
// Escapa texto antes de ir para innerHTML.
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const SA_URLS = ['https://*.serviceaide.com/*'];

// ---------- Campos do painel ----------
const FIELDS = [
  { id: 'nome', label: 'Nome', req: true },
  { id: 'email', label: 'E-mail' },
  { id: 'telefone', label: 'Telefone', req: false }, // opcional: vazio não é escrito no ServiceAide
  { id: 'equipamentoTipo', label: 'Equipamento', req: true },
  { id: 'tipo', label: 'Solicitação ou incidente', req: true },
  { id: 'localizacao', label: 'Localização', req: true },
  { id: 'problema', label: 'Descrição do problema', req: true },
  { id: 'detalhes', label: 'Detalhes' },
  { id: 'matricula', label: 'Matrícula', req: true },
  { id: 'departamento', label: 'Departamento', req: true },
  { id: 'equipamento', label: 'Identificação do equipamento', req: true },
];
const DEFAULTS = { matricula: 'N/A', equipamento: 'N/A' };
const DEFAULT_EQUIPS = ['CUPPS', 'CUSS', 'FIDS'];
let equips = [...DEFAULT_EQUIPS];

// ---------- Máscara: [ Equipamento ] [ TIPO ] [ LOCALIZAÇÃO ] [ DESCRIÇÃO ] ----------
const up = (t) => (t || '').trim().toLocaleUpperCase('pt-BR');
function buildMask(v) {
  return [v.equipamentoTipo, v.tipo, v.localizacao, v.problema].map((p) => `[${up(p)}]`).join(' ');
}
function updateMask() {
  const v = readValues();
  const empty = !v.equipamentoTipo && !v.tipo && !v.localizacao && !v.problema;
  $('mascara').textContent = empty ? '[ EQUIPAMENTO ] [ TIPO ] [ LOCALIZAÇÃO ] [ PROBLEMA ]' : buildMask(v);
}

// ---------- Modelo de texto (edite aqui para mudar o formato) ----------
const titleCase = (t) => t.toLowerCase().replace(/(^|\s)(\S)/g, (m, s, c) => s + c.toUpperCase());
// Texto do chamado: mesmo modelo da máscara da ferramenta Máscara (Copiar).
// Chamado e SLA vêm do ServiceAide (lidos ao copiar); Atendente vem das Configurações da Máscara.
let ultimaCaptura = { chamado: '', sla: '' };
let atendente = '';
function buildText(v, extra = ultimaCaptura) {
  return [
    buildMask(v),
    '',
    `CHAMADO: ${extra.chamado || ''}`,
    `ATENDENTE: ${atendente || '-'}`,
    `SOLICITANTE: ${titleCase(v.nome)}`,
    `RAMAL: ${v.telefone}`,
    `E-MAIL: ${v.email}`,
    `LOCALIZAÇÃO: ${up(v.localizacao)}`,
    `VIOLAÇÃO SLA: ${extra.sla || ''}`,
    `DESCRIÇÃO: ${detalhesOf(v).replace(/\r/g, '')}`,
  ].join('\n');
}
const detalhesOf = (v) => v.detalhes || v.problema;

// ---------- Utilidades ----------
const readValues = () => Object.fromEntries(FIELDS.map((f) => [f.id, $(f.id).value.trim()]));
function setStatus(msg, kind = '', el = 'status') { $(el).textContent = msg; $(el).className = 'status ' + kind; }
// formTs: usado pela limpeza automática (dados com mais de 7 dias são apagados).
const saveForm = () => api.storage.local.set({ form: Object.fromEntries(FIELDS.map((f) => [f.id, $(f.id).value])), formTs: Date.now() });

// ---------- Configuração de equipamentos ----------
function renderEquips() {
  const sel = $('equipamentoTipo');
  const cur = sel.value;
  sel.innerHTML = '<option value="">Selecione…</option>' + equips.map((e) => `<option value="${esc(e)}">${esc(e)}</option>`).join('');
  if (cur && !equips.includes(cur)) sel.insertAdjacentHTML('beforeend', `<option value="${esc(cur)}">${esc(cur)}</option>`);
  sel.value = cur;
  $('cfgList').innerHTML = equips.map((e, i) => `<li><span>${esc(e)}</span><button class="icon-btn" data-del="${i}" type="button" title="Remover">✕</button></li>`).join('');
}
async function saveEquips() { await api.storage.local.set({ equips }); renderEquips(); }
// Compara sem acento, maiúscula e espaço extra: "BCBP", "bcbp " e "Bcbp" são o mesmo.
const chaveEquip = (t) => normTxt(t).replace(/\s+/g, ' ').trim();
function addEquip() {
  const name = up($('cfgNew').value).replace(/[<>"]/g, '').replace(/\s+/g, ' ');
  const msg = $('cfgMsg');
  if (!name) return;
  const igual = equips.find((e) => chaveEquip(e) === chaveEquip(name));
  if (igual) {
    msg.textContent = `Já existe: ${igual}`;
    msg.className = 'status status--inline err';
    return;
  }
  equips.push(name);
  $('cfgNew').value = '';
  msg.textContent = `${name} adicionado.`;
  msg.className = 'status status--inline ok';
  saveEquips();
}

// ---------- Localização: sugere as já digitadas (mais recentes primeiro) ----------
let locsUsadas = [];
const locItems = () => locsUsadas.slice().reverse();
async function rememberLoc(value) {
  const v = up(value);
  if (!v) return;
  locsUsadas = [...locsUsadas.filter((l) => normTxt(l) !== normTxt(v)), v].slice(-40);
  await api.storage.local.set({ locsUsadas });
}

// ---------- Departamento: sugestões ao digitar (mesmo padrão da Máscara) ----------
// Lista base em departamentos.js + departamentos já usados neste navegador.
let deptosUsados = [];
const normTxt = (t) => (t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('pt-BR');
const deptoItems = () => {
  const base = Array.isArray(globalThis.ARION_DEPARTAMENTOS) ? globalThis.ARION_DEPARTAMENTOS : [];
  const seen = new Set();
  return [...base, ...deptosUsados].filter((d) => {
    const k = normTxt(d);
    if (!k || seen.has(k)) return false;
    seen.add(k);
    return true;
  });
};
async function rememberDepto(value) {
  const v = (value || '').trim();
  if (!v || deptoItems().some((d) => normTxt(d) === normTxt(v))) return;
  deptosUsados = [...deptosUsados, v].slice(-50);
  await api.storage.local.set({ deptosUsados });
}

function bindAutocomplete(input, list, getItems) {
  let active = -1;
  const close = () => { active = -1; list.classList.remove('open'); list.innerHTML = ''; };
  const pick = (value) => {
    input.value = value;
    input.dispatchEvent(new Event('input', { bubbles: true }));
    input.dispatchEvent(new Event('change', { bubbles: true }));
    close();
  };
  const setActive = (i) => {
    const opts = [...list.querySelectorAll('.autocomplete-option')];
    if (!opts.length) return;
    active = (i + opts.length) % opts.length;
    opts.forEach((o, j) => o.classList.toggle('active', j === active));
    opts[active].scrollIntoView({ block: 'nearest' });
  };
  const render = () => {
    const q = normTxt(input.value.trim());
    // Começa com o texto primeiro; depois os que contêm.
    const all = getItems().filter((d) => normTxt(d).includes(q));
    const items = [...all.filter((d) => normTxt(d).startsWith(q)), ...all.filter((d) => !normTxt(d).startsWith(q))];
    active = -1;
    list.innerHTML = '';
    if (!items.length || (items.length === 1 && normTxt(items[0]) === q)) return close();
    items.forEach((d) => {
      const o = document.createElement('div');
      o.className = 'autocomplete-option';
      o.textContent = d;
      o.addEventListener('mousedown', (e) => { e.preventDefault(); pick(d); });
      list.appendChild(o);
    });
    list.classList.add('open');
  };
  input.addEventListener('focus', render);
  input.addEventListener('click', render);
  input.addEventListener('input', render);
  input.addEventListener('blur', () => setTimeout(close, 120));
  input.addEventListener('keydown', (e) => {
    if (!list.classList.contains('open')) return;
    if (e.key === 'ArrowDown') { e.preventDefault(); setActive(active + 1); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(active - 1); }
    else if (e.key === 'Enter' && active >= 0) { e.preventDefault(); pick(list.children[active].textContent); }
    else if (e.key === 'Escape') close();
  });
}

// ---------- Verificar entradas ----------
function verify(v) {
  const missing = FIELDS.filter((f) => f.req && !v[f.id]);
  const badMail = v.email && !/^\S+@\S+\.\S+$/.test(v.email);
  FIELDS.forEach((f) => $(f.id).classList.toggle('invalid', missing.includes(f) || (f.id === 'email' && badMail)));
  document.querySelector('.invalid')?.focus();
  if (missing.length) return { ok: false, msg: 'Preencha: ' + missing.map((f) => f.label).join(', ') + '.' };
  if (badMail) return { ok: false, msg: 'E-mail inválido.' };
  return { ok: true };
}

// ---------- Inserir no formulário (página do ServiceAide) ----------
// Ordem importa: o Nome vem primeiro (a janela de busca preenche o e-mail na página).
function nomeField(nome) {
  const [first, ...rest] = nome.split(/\s+/);
  return { key: 'nome', labels: ['Nome'], mode: 'modal', search: first, pick: rest.join(' '), waitFor: ['Email', 'E-mail'], value: nome };
}
function buildPayload(v, skipNome, manualEmail) {
  return [
    ...(skipNome ? [] : [nomeField(v.nome)]),
    // E-mail digitado pelo usuário vai depois do Nome (a busca do Nome troca o E-mail da página).
    ...(manualEmail ? [{ key: 'email', labels: ['Email', 'E-mail'], value: v.email }] : []),
    ...(v.telefone ? [{ key: 'telefone', labels: ['Telefone'], value: v.telefone }] : []),
    { key: 'descricao', labels: ['Descrição'], value: buildMask(v) },
    { key: 'detalhes', labels: ['Detalhes', 'Detalhe'], value: detalhesOf(v) },
    { key: 'matricula', labels: ['Matrícula'], value: v.matricula },
    { key: 'departamento', labels: ['Departamento'], value: v.departamento, mode: 'select' },
    { key: 'localizacao', labels: ['Localização'], value: up(v.localizacao), mode: 'autocomplete' },
    { key: 'equipamento', labels: ['Identificação do equipamento', 'Identificação do equip.'], value: v.equipamento },
  ];
}
const PAGE_LABELS = { nome: 'Nome', email: 'E-mail', telefone: 'Telefone', descricao: 'Descrição', detalhes: 'Detalhes', matricula: 'Matrícula', departamento: 'Departamento', localizacao: 'Localização', equipamento: 'Identificação do equipamento' };
const ERRORS = {
  'no-tab': 'ServiceAide não está aberto. Abra o chamado e tente de novo.',
  'no-form': 'Formulário não encontrado na aba do ServiceAide.',
  inject: 'Sem acesso ao ServiceAide. Clique em Permitir acesso no Início e recarregue a página.',
};

async function findTab() {
  let tabs = await api.tabs.query({ url: SA_URLS, currentWindow: true });
  if (!tabs.length) tabs = await api.tabs.query({ url: SA_URLS });
  return tabs.find((t) => t.active) || tabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0] || null;
}

// Injeta sa-page.js em todos os frames e roda uma ação; devolve o resultado de cada frame.
async function runInPage(action, arg, focus) {
  const tab = await findTab();
  if (!tab) return { error: 'no-tab' };
  if (focus) {
    try { // a janela de busca do Nome precisa da página ativa
      await api.tabs.update(tab.id, { active: true });
      await api.windows.update(tab.windowId, { focused: true });
    } catch (_) {}
  }
  try {
    const target = { tabId: tab.id, allFrames: true };
    // Caminho a partir da raiz (Firefox); se recusar a barra, tenta o caminho antigo.
    try { await api.scripting.executeScript({ target, files: ['/apps/preenchimento/sa-page.js'] }); }
    catch (_) { await api.scripting.executeScript({ target, files: ['apps/preenchimento/sa-page.js'] }); }
    const out = await api.scripting.executeScript({
      target,
      func: (act, a) => (window.__arionSA ? window.__arionSA[act](a) : null),
      args: [action, arg ?? null],
    });
    return { results: out.map((o) => o.result).filter(Boolean) };
  } catch (err) {
    console.error(err);
    return { error: 'inject' };
  }
}

async function fillPage(fields) {
  const r = await runInPage('fill', { fields }, true);
  if (r.error) return r;
  const best = r.results.sort((a, b) => b.filled.length - a.filled.length)[0];
  return best && best.filled.length ? best : { error: 'no-form' };
}

// ---------- Localizar o solicitante ----------
// Guarda quem já foi localizado: no "Preencher" o Nome não é buscado de novo.
let located = null; // { nome, email, ts }
// E-mail escrito pela Central. Diferente disso = o usuário digitou: não sobrescrever.
let autoEmail = '';
function isManualEmail() {
  const e = $('email').value.trim();
  return !!e && e.toLowerCase() !== autoEmail.toLowerCase();
}
function setAutoEmail(email) {
  if (!email || isManualEmail()) return false;
  $('email').value = email;
  autoEmail = email;
  saveForm();
  return true;
}
const sameName = (a, b) => (a || '').trim().toLowerCase() === (b || '').trim().toLowerCase();
const saveLocated = () => (located ? api.storage.local.set({ nomeLoc: located }) : api.storage.local.remove('nomeLoc'));

function renderLocated() {
  const ok = !!located && sameName(located.nome, $('nome').value);
  $('nome').classList.toggle('found', ok);
  $('nomeHint').hidden = ok || !!$('nomeStatus').textContent;
}
function setLocated(nome, email) {
  located = { nome, email: email || '', ts: Date.now() };
  saveLocated();
  renderLocated();
}
function clearLocated() {
  located = null;
  saveLocated();
  setStatus('', '', 'nomeStatus');
  renderLocated();
}

function nomeMsg(n, nome) {
  const [first, ...rest] = nome.split(/\s+/);
  if (n.status === 'nome-nao-encontrado') return { msg: `Não encontrado: "${first}".`, kind: 'err' };
  if (n.status === 'sobrenome-nao-encontrado') return { msg: `"${first}" encontrado, mas sobrenome "${rest.join(' ')}" não.`, kind: 'err' };
  return { msg: `Encontrado ✓ ${titleCase(nome)}${n.email ? ' · ' + n.email : ''}`, kind: 'ok' };
}

async function onFind() {
  const nome = $('nome').value.trim();
  if (!nome) {
    $('nome').classList.add('invalid');
    $('nome').focus();
    return setStatus('Digite o nome.', 'err', 'nomeStatus');
  }
  $('nome').classList.remove('invalid');
  $('nomeFind').disabled = true;
  setStatus('Localizando…', '', 'nomeStatus');
  renderLocated();
  const r = await runInPage('fill', { fields: [nomeField(nome)] }, true);
  $('nomeFind').disabled = false;

  if (r.error) { setStatus(ERRORS[r.error], 'err', 'nomeStatus'); return renderLocated(); }
  const n = r.results.find((x) => x.nome)?.nome;
  if (!n) { setStatus(ERRORS['no-form'], 'err', 'nomeStatus'); return renderLocated(); }

  const { msg, kind } = nomeMsg(n, nome);
  setStatus(msg, kind, 'nomeStatus');
  if (n.status !== 'selecionado') { located = null; saveLocated(); return renderLocated(); }
  setAutoEmail(n.email);
  setLocated(nome, n.email);
}

// O Nome localizado ainda está no formulário da página? (outro chamado = busca de novo)
async function locatedOnPage(nome) {
  if (!located || !sameName(located.nome, nome)) return false;
  const r = await runInPage('nomeAtual');
  if (r.error) return false;
  return r.results.some((x) => x && x.nome);
}

// ---------- Ação principal ----------
async function onFill() {
  const v = readValues();
  const check = verify(v);
  if (!check.ok) return setStatus(check.msg, 'err');

  rememberDepto(v.departamento);
  rememberLoc(v.localizacao);
  $('fill').disabled = true;
  const skipNome = await locatedOnPage(v.nome);
  const manualEmail = isManualEmail();
  setStatus(skipNome ? 'Preenchendo…' : 'Buscando o solicitante…');
  const res = await fillPage(buildPayload(v, skipNome, manualEmail));
  $('fill').disabled = false;

  if (res.error) {
    showText(v);
    return setStatus(ERRORS[res.error] + ' O texto foi gerado mesmo assim.', 'err');
  }

  // Resultado da busca do Nome
  const n = skipNome ? { status: 'selecionado', email: located.email } : res.nome || { status: 'selecionado', email: '' };
  if (!skipNome) {
    const { msg, kind } = nomeMsg(n, v.nome);
    setStatus(msg, kind, 'nomeStatus');
    if (n.status !== 'selecionado') { renderLocated(); return setStatus(msg, 'err'); }
    setLocated(v.nome, n.email);
  }

  let mailMsg = 'O chamado ficou sem e-mail.';
  if (manualEmail) mailMsg = `E-mail mantido: ${v.email}.`;
  else if (n.email) {
    setAutoEmail(n.email);
    mailMsg = `E-mail encontrado: ${n.email}.`;
  }

  showText(readValues());
  const todo = [...res.missing.map((k) => PAGE_LABELS[k] || k), ...res.notes.map((x) => PAGE_LABELS[x.split(':')[0]] || x)];
  if (todo.length) setStatus(`${mailMsg} Confira na página: ${[...new Set(todo)].join(', ')}.`, 'err');
  else setStatus(`Chamado preenchido ✓ ${skipNome ? 'O nome já estava localizado. ' : ''}${mailMsg}`, n.email || manualEmail ? 'ok' : 'err');
}
function showText(v) { $('out').value = buildText(v); $('result').hidden = false; }

// ---------- Capturar (mesma lógica da arion-plugin) ----------
const cleanChamado = (t) => (t.match(/\b\d{3}-\d{4,}\b/) || [t.trim()])[0];
function normalizeRequester(value) { // "Sobrenome, Nome" → "Nome Sobrenome"
  const p = value.split(',');
  return p.length === 2 ? `${p[1].trim()} ${p[0].trim()}` : value.trim();
}
// Lê "[A] [B] [C] [D]" de volta nos 4 campos da máscara.
function parseMask(text) {
  const parts = [...(text || '').matchAll(/\[([^\]]*)\]/g)].map((m) => m[1].trim());
  if (parts.length !== 4) return null;
  const [eq, tp, loc, prob] = parts;
  const tipo = /incid/i.test(tp) ? 'INCIDENTE' : /solic/i.test(tp) ? 'SOLICITAÇÃO' : '';
  return { equipamentoTipo: up(eq), tipo, localizacao: loc, problema: prob };
}

// informe: true = botão "Capturar informe" (mostra o informe); false = usado pelo Copiar do Texto do chamado.
async function onCapture(_ev, { informe = true } = {}) {
  const st = informe ? 'capStatus' : 'status';
  $('capture').disabled = true;
  setStatus('Capturando o chamado no ServiceAide…', '', st);
  const r = await runInPage('capture');
  $('capture').disabled = false;
  if (r.error) { setStatus(ERRORS[r.error], 'err', st); return false; }
  const best = r.results.sort((a, b) => b.found - a.found)[0];
  if (!best || !best.found) { setStatus('Nenhum dado capturado.', 'err', st); return false; }

  const d = best.data;
  const c = {
    chamado: cleanChamado(d.chamado || ''),
    nome: normalizeRequester(d.nome || ''),
    telefone: (d.telefone || '').trim(),
    email: (d.email || '').trim(),
    localizacao: (d.localizacao || '').trim(),
    titulo: (d.descricao || '').trim(),
    detalhes: (d.detalhes || '').trim(),
    sla: (d.sla || '').trim(),
  };

  // Preenche o painel com o que veio
  const set = (id, val) => { if (val) $(id).value = val; };
  set('nome', c.nome); set('telefone', c.telefone); set('email', c.email);
  if (c.email) autoEmail = c.email;
  if (located && !sameName(located.nome, $('nome').value)) clearLocated();
  set('localizacao', c.localizacao); set('detalhes', c.detalhes);
  const m = parseMask(c.titulo);
  if (m) {
    if (m.equipamentoTipo && !equips.includes(m.equipamentoTipo)) { equips.push(m.equipamentoTipo); await saveEquips(); }
    Object.entries(m).forEach(([k, val]) => set(k, val));
  } else set('problema', c.titulo);
  updateMask();
  saveForm();

  ultimaCaptura = { chamado: c.chamado, sla: c.sla };
  if (!$('result').hidden) showText(readValues());

  if (!informe) return true;

  // Informe no mesmo modelo da Máscara
  $('capOut').value = [
    c.titulo,
    '',
    `CHAMADO: ${c.chamado}`,
    `ATENDENTE: ${atendente || '-'}`,
    `SOLICITANTE: ${c.nome}`,
    `RAMAL: ${c.telefone}`,
    `E-MAIL: ${c.email}`,
    `LOCALIZAÇÃO: ${c.localizacao}`,
    `VIOLAÇÃO SLA: ${c.sla}`,
    `DESCRIÇÃO: ${c.detalhes}`,
  ].join('\n');
  $('capResult').hidden = false;
  setStatus(`${best.found} campo(s) capturado(s) ✓`, 'ok', 'capStatus');
  return true;
}

// ---------- Copiar o Texto do chamado ----------
// Copiar = Capturar + Copiar: captura o chamado aberto no ServiceAide (preenche o painel,
// número e SLA) e copia o texto no modelo da Máscara. Sem ServiceAide, copia o que está no painel.
async function onCopyTexto() {
  $('copy').disabled = true;
  const ok = await onCapture(null, { informe: false });
  $('copy').disabled = false;
  showText(readValues());
  await copyFrom('out', 'status', ok
    ? `Capturado e copiado ✓${ultimaCaptura.chamado ? ' (chamado ' + ultimaCaptura.chamado + ')' : ''}`
    : 'Copiado sem capturar: abra o chamado no ServiceAide para trazer número e SLA.');
}

// ---------- Copiar ----------
async function copyFrom(id, statusEl, msg) {
  try { await navigator.clipboard.writeText($(id).value); }
  catch (_) { $(id).select(); document.execCommand('copy'); }
  setStatus(msg, 'ok', statusEl);
}

async function onClear() {
  FIELDS.forEach((f) => { $(f.id).value = DEFAULTS[f.id] ?? ''; $(f.id).classList.remove('invalid'); });
  $('result').hidden = true;
  $('capResult').hidden = true;
  setStatus(''); setStatus('', '', 'capStatus');
  clearLocated();
  autoEmail = '';
  updateMask();
  await api.storage.local.remove('form');
}

(async function init() {
  const { form = {}, equips: saved, nomeLoc, deptosUsados: usados, locsUsadas: locs } = await api.storage.local.get(['form', 'equips', 'nomeLoc', 'deptosUsados', 'locsUsadas']);
  if (Array.isArray(usados)) deptosUsados = usados;
  if (Array.isArray(locs)) locsUsadas = locs;
  ({ atendente = '' } = await api.storage.local.get('atendente'));
  api.storage.onChanged?.addListener((ch, area) => { if (area === 'local' && ch.atendente) { atendente = ch.atendente.newValue || ''; if (!$('result').hidden) showText(readValues()); } });
  bindAutocomplete($('localizacao'), $('localizacaoList'), locItems);
  $('localizacao').addEventListener('change', () => rememberLoc($('localizacao').value));
  bindAutocomplete($('departamento'), $('departamentoList'), deptoItems);
  if (Array.isArray(saved) && saved.length) equips = saved;
  renderEquips();
  FIELDS.forEach((f) => { $(f.id).value = form[f.id] ?? DEFAULTS[f.id] ?? ''; });
  renderEquips(); // mantém equipamento salvo que saiu da lista
  updateMask();
  if (nomeLoc && sameName(nomeLoc.nome, $('nome').value)) {
    located = nomeLoc;
    if (sameName(nomeLoc.email, $('email').value)) autoEmail = nomeLoc.email || '';
    setStatus(nomeMsg({ status: 'selecionado', email: nomeLoc.email }, nomeLoc.nome).msg, 'ok', 'nomeStatus');
  }
  renderLocated();

  const onChange = () => { updateMask(); saveForm(); };
  document.addEventListener('input', onChange);
  document.addEventListener('change', onChange);

  $('cfgToggle').addEventListener('click', (e) => { e.preventDefault(); $('cfg').hidden = !$('cfg').hidden; });
  $('cfgAdd').addEventListener('click', addEquip);
  $('cfgNew').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); addEquip(); } });
  $('cfgNew').addEventListener('input', () => { $('cfgMsg').textContent = ''; });
  $('cfgList').addEventListener('click', (e) => {
    const i = e.target.dataset.del;
    if (i === undefined) return;
    equips.splice(Number(i), 1);
    saveEquips();
  });

  $('nomeFind').addEventListener('click', onFind);
  $('nome').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); onFind(); } });
  $('nome').addEventListener('input', () => {
    $('nome').classList.remove('invalid');
    if (located && !sameName(located.nome, $('nome').value)) clearLocated();
    else if (!located) { setStatus('', '', 'nomeStatus'); renderLocated(); }
  });
  $('capture').addEventListener('click', onCapture);
  $('capCopy').addEventListener('click', () => copyFrom('capOut', 'capStatus', 'Informe copiado ✓'));
  $('fill').addEventListener('click', onFill);
  $('copy').addEventListener('click', onCopyTexto);
  $('clear').addEventListener('click', onClear);
})();
