/* alpha-mascara.js — Copiar Chamado (visual da Central 2.0).
 * Só o cartão da máscara, editável. A lógica de captura continua no popup.js.
 */
(function () {
  const $ = (id) => document.getElementById(id);
  const tabService = document.querySelector('.tab-service');
  const tabSettings = document.querySelector('.tab-settings');
  const emConfig = () => tabSettings.classList.contains('active');

  // Engrenagem: alterna Configurações ⇄ ServiceAide.
  $('aCfg').addEventListener('click', () => (emConfig() ? tabService : tabSettings).click());
  $('aVoltar').addEventListener('click', () => tabService.click());
  new MutationObserver(() => { $('aSub').textContent = emConfig() ? 'Configurações' : 'ServiceAide'; })
    .observe(tabSettings, { attributes: true, attributeFilter: ['class'] });

  const v = (id) => ($(id).value || '').trim();
  const m = $('serviceMaskOutput');

  // A máscara cresce conforme o texto (visualização completa).
  function ajustar() {
    // Sem chamado capturado: mostra a dica em vez do modelo vazio.
    if (!v('serviceChamado') && !v('serviceTitulo') && /^\s*CHAMADO:\s*\n/.test(m.value.replace(/^\s+/, ''))) m.value = '';
    m.style.height = 'auto';
    m.style.height = Math.max(72, m.scrollHeight) + 'px';
    $('aMask').classList.toggle('ok', !!m.value.trim());
    const ch = v('serviceChamado');
    $('aCtxTxt').textContent = ch ? `Chamado ${ch} capturado` : 'Abra o chamado no ServiceAide';
    $('aCtxDot').classList.toggle('a-dot--off', !ch);
  }
  m.addEventListener('input', ajustar);
  // A captura muda os valores sem evento: confere a cada meio segundo.
  let ultimo = '';
  setInterval(() => { const a = m.value + '|' + v('serviceChamado'); if (a !== ultimo) { ultimo = a; ajustar(); } }, 500);
  window.addEventListener('resize', ajustar);
  ajustar();
})();
