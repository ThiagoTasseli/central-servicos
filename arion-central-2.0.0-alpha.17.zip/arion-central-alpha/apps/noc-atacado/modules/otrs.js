/* modules/otrs.js
 * Ponte entre o painel e as abas do OTRS (mesma ideia do autofill.js da Central de Voos).
 */
(function () {

// OTRS = qualquer página index.pl com Action=Agent..., em qualquer domínio.
const EH_OTRS = url => /index\.pl\?.*Action=Agent/i.test(url || '');
const sleep = ms => new Promise(r => setTimeout(r, ms));

const acaoDe = url => (String(url).match(/Action=(\w+)/) || [])[1] || '';
const ticketDe = url => (String(url).match(/TicketID=(\d+)/) || [])[1] || '';

async function abas() {
  return (await chrome.tabs.query({})).filter(t => EH_OTRS(t.url));
}

/** Aba do OTRS em foco: a ativa da janela atual, senão a mais recente. */
async function abaAtual() {
  const [ativa] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (ativa && EH_OTRS(ativa.url) && ticketDe(ativa.url)) return ativa;
  // Popups (Campos Livres, Nota) ficam em outra janela: prefere a aba com ticket mais recente.
  const todas = (await abas()).filter(t => ticketDe(t.url));
  return todas.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0] || null;
}

async function abaDoTicket(ticketId, acao) {
  const todas = await abas();
  return todas.find(t => ticketDe(t.url) === ticketId && acaoDe(t.url) === acao) || null;
}

/** Espera abrir o popup (Campos Livres ou Nota) do ticket. */
async function esperarAba(ticketId, acao, timeout = 15000) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeout) {
    const t = await abaDoTicket(ticketId, acao);
    if (t && t.status === 'complete') return t;
    await sleep(300);
  }
  return null;
}

/** Injeta page.js (world MAIN) e chama window.__arionOTRS[nome](arg).
 *  Erros dentro da página voltam como { __erro } (antes viravam resultado vazio). */
async function rodar(tabId, nome, arg) {
  // Caminho a partir da raiz ("/..."): o Firefox resolvia "apps/..." a partir da pasta do painel
  // e não achava o page.js. Se algum navegador recusar a barra, tenta o caminho antigo.
  try {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['/apps/noc-atacado/modules/page.js'], world: 'MAIN' });
  } catch (e) {
    await chrome.scripting.executeScript({ target: { tabId }, files: ['apps/noc-atacado/modules/page.js'], world: 'MAIN' });
  }
  const [r] = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func: async (n, a) => {
      try {
        if (!window.__arionOTRS) return { __erro: 'page.js não carregou na página' };
        const res = await window.__arionOTRS[n](a);
        // Firefox: devolve uma cópia simples (objeto criado na página às vezes não volta).
        return res && typeof res === 'object' ? JSON.parse(JSON.stringify({ ...res, versao: window.__arionOTRS.versao })) : res;
      } catch (e) {
        return { __erro: String((e && e.message) || e) };
      }
    },
    args: [nome, arg === undefined ? null : arg]
  });
  if (r && r.error) return { __erro: String(r.error.message || r.error) };
  return r && r.result;
}

/** Plano B da leitura: lê o chamado direto do DOM (mundo isolado, sem page.js). */
async function lerIsolado(tabId) {
  const [r] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const RUIDO = 'select, option, label, input, textarea, button, script, style, noscript, ' +
        '.InputField_Container, .InputField_TreeContainer, .ui-autocomplete, .ui-menu, #NavigationContainer, ' +
        '#ToolBar, .ActionRow, .Sidebar .Field, .FormFields, form .Field';
      const limpo = (doc) => {
        try {
          const c = doc.body.cloneNode(true);
          c.querySelectorAll(RUIDO).forEach((e) => e.remove());
          let t = c.innerText || c.textContent || '';
          doc.querySelectorAll('iframe').forEach((f) => { try { const b = f.contentDocument.body; t += '\n' + (b.innerText || b.textContent || ''); } catch (_) {} });
          return t;
        } catch (_) { return ''; }
      };
      let texto = limpo(document);
      try { if (window.opener && window.opener.document) texto += '\n' + limpo(window.opener.document); } catch (_) {}
      const partes = [];
      const input = document.getElementById('Title');
      if (input && input.value) partes.push(input.value);
      const h = document.querySelector('.Headline h1, h1');
      if (h) partes.push(h.textContent.replace(/^.*?—\s*/, '').trim());
      const p = new URLSearchParams(location.search.replace(/;/g, '&'));
      return {
        ok: true,
        acao: p.get('Action') || '',
        ticketId: p.get('TicketID') || (location.href.match(/TicketID=(\d+)/) || [])[1] || '',
        numero: ((document.body.innerText || document.body.textContent || '').match(/Ticket#\s*(\d{10,})/) || [])[1] || '',
        titulo: [...new Set(partes.filter(Boolean))].join(' | ') || document.title,
        texto
      };
    }
  });
  return r && r.result;
}

async function focar(tab) {
  try {
    await chrome.tabs.update(tab.id, { active: true });
    if (tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true });
  } catch (_) {}
}

/** Lê o ticket da aba em foco (zoom ou popup). */
async function ler() {
  const tab = await abaAtual();
  if (!tab) return { ok: false, erro: 'Nenhuma aba do OTRS com chamado aberto.' };
  try {
    let r = null, detalhe = '';
    try { r = await rodar(tab.id, 'ler'); } catch (e) { detalhe = e.message; }
    if (r && r.__erro) { detalhe = r.__erro; r = null; }
    // Leitura principal vazia (visto no Firefox): tenta ler só o DOM.
    if (!r || !r.ticketId) {
      try { const b = await lerIsolado(tab.id); if (b && b.ticketId) r = { ...b, lidoPor: 'isolado' }; } catch (e) { detalhe = detalhe || e.message; }
    }
    if (!r || !r.ticketId) return { ok: false, erro: 'A página aberta não é de um chamado (sem TicketID).' + (detalhe ? ' (' + detalhe + ')' : '') };
    return { ...r, tabId: tab.id };
  } catch (e) {
    let host = '';
    try { host = new URL(tab.url).host; } catch (_) {}
    return { ok: false, erro: `Sem acesso a ${host || 'esta aba'}: ${e.message}` };
  }
}

/**
 * Garante o popup da tela pedida aberto e devolve a aba.
 * Se já estiver aberto, reutiliza. Se não, clica no link a partir do zoom.
 */
async function abrirTela(ticketId, acao, tela) {
  let tab = await abaDoTicket(ticketId, acao);
  if (tab) return tab;
  const zoom = await abaDoTicket(ticketId, 'AgentTicketZoom');
  if (!zoom) return null;
  const r = await rodar(zoom.id, 'abrir', tela);
  if (!r || !r.ok) return null;
  return esperarAba(ticketId, acao);
}

// Converte { __erro } da página em mensagem para o painel.
const comErro = (r) => (r && r.__erro ? { ok: false, erro: 'Erro na página do OTRS: ' + r.__erro } : r);

async function categorizar(ticketId, payload) {
  const tab = await abrirTela(ticketId, 'AgentTicketFreeText', 'campos');
  if (!tab) return { ok: false, erro: 'Não abriu a tela de Campos Livres.' };
  await focar(tab);
  return comErro(await rodar(tab.id, 'categorizar', payload));
}

async function categorizarSuporte(ticketId, payload) {
  const tab = await abrirTela(ticketId, 'AgentTicketFreeText', 'campos');
  if (!tab) return { ok: false, erro: 'Não abriu a tela de Campos Livres.' };
  await focar(tab);
  return comErro(await rodar(tab.id, 'categorizarSuporte', payload));
}

async function categorizarCancNgo(ticketId, payload) {
  const tab = await abrirTela(ticketId, 'AgentTicketFreeText', 'campos');
  if (!tab) return { ok: false, erro: 'Não abriu a tela de Campos Livres.' };
  await focar(tab);
  return comErro(await rodar(tab.id, 'categorizarCancNgo', payload));
}

async function categorizarCmdb(ticketId, payload) {
  const tab = await abrirTela(ticketId, 'AgentTicketFreeText', 'campos');
  if (!tab) return { ok: false, erro: 'Não abriu a tela de Campos Livres.' };
  await focar(tab);
  return comErro(await rodar(tab.id, 'categorizarCmdb', payload));
}

// Comercial: abre "Novo chamado via processo" numa aba nova do mesmo OTRS e preenche (sem enviar).
async function abrirProcesso(processo, payload) {
  const base = (await abaAtual()) || (await abas())[0];
  if (!base) return { ok: false, erro: 'Abra o OTRS em uma aba primeiro.' };
  const u = new URL(base.url);
  const url = `${u.origin}${u.pathname}?Action=AgentTicketProcess;ProcessEntityID=${processo}`;
  const tab = await chrome.tabs.create({ url, active: true });
  const t0 = Date.now();
  while (Date.now() - t0 < 20000) {
    const t = await chrome.tabs.get(tab.id).catch(() => null);
    if (!t) return { ok: false, erro: 'A aba do chamado novo foi fechada.' };
    if (t.status === 'complete') break;
    await sleep(300);
  }
  await focar(tab);
  return comErro(await rodar(tab.id, 'abrirComercial', payload));
}

async function nota(ticketId, payload) {
  const tab = await abrirTela(ticketId, 'AgentTicketNote', 'nota');
  if (!tab) return { ok: false, erro: 'Não abriu a tela de Nota.' };
  await focar(tab);
  return comErro(await rodar(tab.id, 'nota', payload));
}

async function mover(ticketId, fila) {
  const zoom = await abaDoTicket(ticketId, 'AgentTicketZoom');
  if (!zoom) return { ok: false, erro: 'Abra o chamado (tela de detalhes) para mover.' };
  await focar(zoom);
  return comErro(await rodar(zoom.id, 'mover', { fila }));
}

async function rebuscarLink(ticketId, designacao) {
  const tab = await abrirTela(ticketId, 'AgentTicketFreeText', 'campos');
  if (!tab) return { ok: false, erro: 'Abra a tela Campos Livres do chamado.' };
  await focar(tab);
  return comErro(await rodar(tab.id, 'rebuscarLink', { designacao }));
}

async function refazerLocalidade(ticketId, payload) {
  const tab = await abrirTela(ticketId, 'AgentTicketFreeText', 'campos');
  if (!tab) return { ok: false, erro: 'Abra a tela Campos Livres do chamado.' };
  await focar(tab);
  return comErro(await rodar(tab.id, 'refazerLocalidade', payload));
}

self.OTRS = { ler, categorizar, categorizarSuporte, categorizarCancNgo, categorizarCmdb, abrirProcesso, nota, mover, rebuscarLink, refazerLocalidade };

})();
