/* comercial.js — aba "Comercial" da Categorização (CSTI). Versão de teste.
 * Capturar: lê o chamado do OTRS aberto (número, cliente, empresa, contato, e-mail, descrição) + data/hora.
 * Preencher planilha: copia a linha A–E (CHAMADO, NOME DO CLIENTE, EMPRESA, DATA, HORA) e foca a planilha.
 * Abrir chamado: abre "Novo chamado de Restauração/Solicitação" no OTRS e preenche os campos (sem enviar).
 */
(function () {
  const $ = (id) => document.getElementById(id);
  const R = self.Regras;
  const get = (k) => new Promise((r) => chrome.storage.local.get(k, (v) => r(v[k])));
  const set = (k, v) => new Promise((r) => chrome.storage.local.set({ [k]: v }, r));
  const msg = (t, erro) => { try { toast(t, erro); } catch (_) {} };

  const PROCESSO = 'Process-a946dec6796857d27b1b3ae9f0d48c51'; // Novo chamado de Restauração/Solicitação
  const AJUSTES_PADRAO = {
    tipo: 'Solicitação', sgf: 'INTERNET',
    servico: 'Internet', sla: '24 Horas 24x7', site: 'NGO - NAO GEOGRAFICO'
  };
  const CAMPOS = ['chamado', 'nome', 'empresa', 'contato', 'email', 'descricao']; // Data e Hora: geradas no Abrir chamado
  const AJ = ['tipo', 'sgf', 'servico', 'sla', 'site', 'assunto']; // Localidade: por chamado, no card Cliente

  let c = { fontes: {} };        // captura atual
  let aj = { ...AJUSTES_PADRAO };
  let textoEditado = false;
  let assuntoEditado = false;

  // ---------- modo (aba Comercial) ----------
  const bCom = document.querySelector('#aTipo button[data-modo="comercial"]');
  function modo(com) {
    document.body.classList.toggle('modo-comercial', com);
    $('comercial').hidden = !com;
    bCom.classList.toggle('on', com);
    set('noc_modo', com ? 'comercial' : '');
  }
  bCom.addEventListener('click', () => modo(true));
  document.querySelectorAll('#aTipo button[data-tipo]').forEach((b) => b.addEventListener('click', () => modo(false)));

  // ---------- extração ----------
  const limpa = (v) => String(v || '').replace(/\s+/g, ' ').trim();
  // O texto pode vir sem quebras de linha: o valor vai até a quebra OU o próximo rótulo conhecido.
  const ROTULOS = ['De', 'From', 'Remetente', 'Para', 'Cc', 'Assunto', 'Data', 'Empresa', 'Raz[aã]o Social', 'Nome Fantasia',
    'Rede parceira', 'Telefone', 'Celular', 'Contato', 'Tel', 'E-?mail', 'Descri[cç][aã]o', 'Nome do cliente', 'Nome', 'Cliente', 'Solicitante'];
  const PROX = '(?=(?:' + ROTULOS.join('|') + ')\\s*:|\\n|$)';
  function rotulo(texto, nomes) {
    for (const n of nomes) {
      const m = String(texto).match(new RegExp('(?:^|[^A-Za-zÀ-ú])' + n + '\\s*:[ \\t]*([^\\n]{1,160}?)' + PROX, 'i')) ||
        String(texto).match(new RegExp(n + '\\s*:[ \\t]*([^\\n]{1,160}?)' + PROX, 'i'));
      if (m && limpa(m[1])) return limpa(m[1]);
    }
    return '';
  }
  function formataFone(f) {
    const n = String(f).replace(/\D/g, '').replace(/^55(?=\d{10,11}$)/, '');
    if (n.length === 11) return `(${n.slice(0, 2)}) ${n.slice(2, 7)}-${n.slice(7)}`;
    if (n.length === 10) return `(${n.slice(0, 2)}) ${n.slice(2, 6)}-${n.slice(6)}`;
    return limpa(f);
  }
  function extrairCliente(titulo, texto) {
    const t = String(texto || '');
    const out = {}, fonte = {};
    // Remetente: "De: Nome <email>" / "From: …"
    const rem = t.match(/(?:De|From|Remetente)\s*:\s*"?([^"<\n:]{2,80}?)"?\s*<([^>\s]+@[^>\s]+)>/i);
    out.nome = rotulo(t, ['Nome do cliente', 'Nome', 'Cliente', 'Solicitante']);
    if (out.nome) fonte.nome = 'do texto';
    else if (rem) { out.nome = limpa(rem[1]); fonte.nome = 'do remetente'; }
    out.empresa = rotulo(t, ['Empresa', 'Raz[aã]o Social', 'Nome Fantasia', 'Rede parceira']);
    if (out.empresa) fonte.empresa = 'do texto';
    const fone = rotulo(t, ['Telefone', 'Celular', 'Contato', 'Tel']) ;
    const foneNum = (fone.match(/\(?\d{2}\)?\s?9?\d{4}[-\s.]?\d{4}/) || [])[0] ||
      (t.match(/\(?\b\d{2}\)?\s?9\d{4}[-\s.]?\d{4}\b/) || [])[0] || '';
    if (foneNum) { out.contato = formataFone(foneNum); fonte.contato = fone ? 'do texto' : 'da assinatura'; }
    const emails = (t.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g) || []).filter((e) => !/grupoarion|otrs/i.test(e));
    const em = rotulo(t, ['E-?mail']).match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/);
    out.email = (em && em[0]) || (rem && !/grupoarion/i.test(rem[2]) ? rem[2] : '') || emails[0] || '';
    if (out.email) fonte.email = em ? 'do texto' : rem ? 'do remetente' : 'do texto';
    const desc = t.match(/Descri[cç][aã]o\s*:\s*([\s\S]{3,600}?)(?:\n\s*\n|(?:Att|Atenciosamente|Obrigad[oa])\b|$)/i);
    out.descricao = desc ? limpa(desc[1]) : '';
    if (out.descricao) fonte.descricao = 'do texto';
    return { out, fonte };
  }

  // ---------- tela ----------
  function badge(k) {
    const el = $('b-' + k);
    if (!el) return;
    const f = c.fontes[k];
    el.className = 'c-b ' + (f === 'editado' ? 'ed' : f ? 'ok' : (c.chamado ? 'no' : ''));
    el.textContent = f === 'editado' ? '✎ editado' : f ? '✓ ' + f : (c.chamado ? (k === 'nome' ? 'Não localizado' : 'Não localizado · digite') : '');
    $('c-' + k).closest('.a-f').classList.toggle('erro', !!c.chamado && !f && (k === 'empresa'));
  }
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  function textoPadrao() {
    return 'Arion - Central de Atendimento\n' +
      'Este ticket foi categorizado e encaminhado para a fila Service Desk.\n\n' +
      `Chamado: ${c.chamado || ''}\n` +
      `Nome do Cliente: ${c.nome || ''}\n` +
      `Empresa: ${c.empresa || ''}\n` +
      `Contato (Número): ${c.contato || ''}\n` +
      `E-mail: ${c.email || ''}\n` +
      `Data/Hora: ${[c.data, c.hora].filter(Boolean).join(' ')}\n` +
      `Descrição: ${c.descricao || ''}`;
  }
  const locAtual = () => c.localidade || '';
  const assuntoPadrao = () => [locAtual() || 'LOCALIDADE', String(c.empresa || 'EMPRESA').toUpperCase(), String(aj.tipo || '').toUpperCase(), 'INTERNET'].join(' - ');
  const linha = () => [c.chamado, c.nome, c.empresa, c.data, c.hora].map((v) => String(v || '').replace(/[\t\n]/g, ' '));

  function render() {
    CAMPOS.forEach((k) => { if (document.activeElement !== $('c-' + k)) $('c-' + k).value = c[k] || ''; });
    ['nome', 'empresa', 'contato', 'email', 'descricao'].forEach(badge);
    if (document.activeElement !== $('c-localidade')) $('c-localidade').value = locAtual();
    const bl = $('b-localidade');
    bl.className = 'c-b ' + (c.chamado && !c.localidade ? 'no' : '');
    bl.textContent = c.chamado && !c.localidade ? 'digite e escolha' : '';
    $('c-ctx').hidden = !c.chamado;
    $('c-ctx-t').textContent = !c.chamado ? '' : c.data ? `Chamado aberto em ${c.data} às ${c.hora}` : 'Chamado capturado · data e hora entram ao clicar em Abrir chamado';
    ['chamado', 'nome', 'empresa', 'data', 'hora'].forEach((k, i) => { $('p-' + k).value = c.chamado ? linha()[i] : ''; });
    if (!textoEditado) $('c-texto').value = c.chamado ? textoPadrao() : '';
    if (!assuntoEditado && document.activeElement !== $('c-assunto')) $('c-assunto').value = c.chamado ? assuntoPadrao() : '';
    AJ.filter((k) => k !== 'assunto').forEach((k) => { if (document.activeElement !== $('c-' + k)) $('c-' + k).value = aj[k] || ''; });
    $('c-abrir').disabled = !c.chamado;
  }
  const salvar = () => set('com_atual', { c, textoEditado, assuntoEditado, texto: $('c-texto').value, assunto: $('c-assunto').value });

  // Localidades (lista do OTRS)
  const LOCS = (R.LOCALIDADES || []).map((l) => l.trim());

  CAMPOS.forEach((k) => $('c-' + k).addEventListener('input', () => {
    c[k] = $('c-' + k).value;
    if (c.fontes && k in c.fontes || ['nome', 'empresa', 'contato', 'email', 'descricao'].includes(k)) c.fontes[k] = c[k] ? 'editado' : '';
    c.planilha = false;
    render(); salvar();
  }));
  AJ.forEach((k) => $('c-' + k).addEventListener('input', () => {
    if (k === 'assunto') assuntoEditado = true; else aj[k] = $('c-' + k).value;
    set('com_ajustes', aj);
    render(); salvar();
  }));
  $('c-texto').addEventListener('input', () => { textoEditado = true; salvar(); });
  // Localidade: vazia por padrão; as opções aparecem só ao digitar (filtra sem acento).
  const semAcento = (t) => String(t).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const locIn = $('c-localidade'), locUl = $('c-loc-list');
  let locOps = [], locSel = -1;
  function mostrarLocs() {
    const q = semAcento(locIn.value.trim());
    if (!q) { locUl.hidden = true; return; }
    const termos = q.split(/\s+/);
    locOps = LOCS.filter((l) => termos.every((t) => semAcento(l).includes(t))).slice(0, 10);
    locSel = locOps.length ? 0 : -1;
    locUl.innerHTML = locOps.length
      ? locOps.map((l, i) => `<li role="option" data-i="${i}" class="${i === locSel ? 'on' : ''}">${esc(l)}</li>`).join('')
      : '<li class="vazio">Nenhuma localidade com esse nome</li>';
    locUl.hidden = false;
  }
  function marcarLoc() { [...locUl.children].forEach((li, i) => li.classList.toggle('on', i === locSel)); const on = locUl.children[locSel]; if (on) on.scrollIntoView({ block: 'nearest' }); }
  function escolherLoc(l) {
    c.localidade = l; locIn.value = l; locUl.hidden = true;
    locIn.closest('.a-f').classList.remove('erro');
    render(); salvar();
  }
  locIn.addEventListener('input', () => { c.localidade = ''; mostrarLocs(); render(); });
  locIn.addEventListener('keydown', (e) => {
    if (locUl.hidden) return;
    if (e.key === 'ArrowDown') { locSel = Math.min(locSel + 1, locOps.length - 1); marcarLoc(); e.preventDefault(); }
    else if (e.key === 'ArrowUp') { locSel = Math.max(locSel - 1, 0); marcarLoc(); e.preventDefault(); }
    else if (e.key === 'Enter') { if (locOps[locSel]) escolherLoc(locOps[locSel]); e.preventDefault(); }
    else if (e.key === 'Escape') { locUl.hidden = true; }
  });
  locUl.addEventListener('mousedown', (e) => { const li = e.target.closest('li[data-i]'); if (li) { e.preventDefault(); escolherLoc(locOps[+li.dataset.i]); } });
  locIn.addEventListener('blur', () => setTimeout(() => {
    locUl.hidden = true;
    // Só vale opção da lista: texto solto é apagado.
    const ex = LOCS.find((l) => semAcento(l) === semAcento(locIn.value.trim()));
    if (ex) escolherLoc(ex); else { if (!c.localidade) locIn.value = ''; render(); salvar(); }
  }, 120));

  // ---------- etapas ----------
  function etapas(lista) { const ol = $('c-etapas'); ol.hidden = false; ol.innerHTML = lista.map((n, i) => `<li data-i="${i}">${esc(n)}<em></em></li>`).join(''); }
  function etapa(i, st, m = '') { const li = document.querySelector(`#c-etapas li[data-i="${i}"]`); if (li) { li.className = st; li.querySelector('em').textContent = m; } }

  // ---------- ações ----------
  $('c-capturar').onclick = async () => {
    $('c-capturar').classList.add('carregando');
    const r = await OTRS.ler().catch((e) => ({ ok: false, erro: e.message }));
    $('c-capturar').classList.remove('carregando');
    if (!r || !r.ok) return msg((r && r.erro) || 'Não leu o chamado', true);
    const { out, fonte } = extrairCliente(r.titulo, r.texto);
    c = {
      chamado: r.numero || r.ticketId || '',
      data: '',
      hora: '',
      nome: out.nome || 'Não localizado',
      empresa: out.empresa || '',
      contato: out.contato || '',
      email: out.email || '',
      descricao: out.descricao || '',
      localidade: '',
      fontes: fonte,
      ticketId: r.ticketId,
      planilha: false
    };
    textoEditado = false; assuntoEditado = false;
    render(); salvar();
    msg(fonte.empresa ? 'Chamado capturado' : 'Capturado. Empresa não localizada: digite.', !fonte.empresa);
  };

  $('c-copiar').onclick = async () => {
    try { await navigator.clipboard.writeText($('c-texto').value); msg('Texto copiado'); } catch (_) { msg('Não copiou', true); }
  };

  // ---------- planilha ----------
  // Plano A: copia a linha como TABELA (texto + HTML). O Excel separa as 5 colunas; Chamado/Data/Hora como texto.
  function copiarLinha(vals) {
    const tsv = vals.join('\t');
    const html = '<table><tr>' + vals.map((v) => `<td style="mso-number-format:'\\@'">${esc(v)}</td>`).join('') + '</tr></table>';
    let ok = false;
    const h = (e) => { e.clipboardData.setData('text/plain', tsv); e.clipboardData.setData('text/html', html); e.preventDefault(); ok = true; };
    document.addEventListener('copy', h);
    try { document.execCommand('copy'); } catch (_) {}
    document.removeEventListener('copy', h);
    if (!ok) { try { navigator.clipboard.writeText(tsv); ok = true; } catch (_) {} }
    return ok;
  }

  async function copiarTexto(t) {
    let ok = false;
    const h = (e) => { e.clipboardData.setData('text/plain', t); e.preventDefault(); ok = true; };
    document.addEventListener('copy', h);
    try { document.execCommand('copy'); } catch (_) {}
    document.removeEventListener('copy', h);
    if (!ok) { try { await navigator.clipboard.writeText(t); ok = true; } catch (_) {} }
    return ok;
  }

  // Ícone de copiar dentro de cada campo da planilha.
  document.querySelectorAll('.c-cp').forEach((b) => b.addEventListener('click', async () => {
    const v = linha()[['chamado', 'nome', 'empresa', 'data', 'hora'].indexOf(b.dataset.k)];
    if (!v && ['data', 'hora'].includes(b.dataset.k)) return msg('Data e hora entram ao clicar em Abrir chamado', true);
    if (!v) return msg('Campo vazio', true);
    if (await copiarTexto(v)) {
      b.classList.add('ok'); setTimeout(() => b.classList.remove('ok'), 1200);
      msg(`${b.title.replace('Copiar ', '')} copiado`);
    } else msg('Não copiou', true);
  }));

  // Copiar linha: as 5 colunas de uma vez (cole na coluna A da linha vazia).
  $('c-cp-linha').onclick = async () => {
    if (!c.chamado) return msg('Capture um chamado', true);
    if (!c.empresa) return msg('Preencha a Empresa', true);
    if (!c.data) return msg('Clique em Abrir chamado primeiro: ele gera a data e a hora', true);
    if (copiarLinha(linha())) {
      const hist = (await get('com_hist')) || [];
      set('com_hist', [{ quando: Date.now(), linha: linha() }, ...hist].slice(0, 200));
      msg('Linha copiada: clique na coluna A da linha vazia e Ctrl+V');
    } else msg('Não copiou', true);
  };

  function textoHtml(t) {
    const l = String(t).split('\n');
    const prim = l.shift() || '';
    return '<p><strong>' + esc(prim) + '</strong><br>' + l.map(esc).join('<br>') + '</p>';
  }

  $('c-abrir').onclick = async () => {
    if (!c.empresa) return msg('Preencha a Empresa', true);
    if (!c.localidade) { locIn.closest('.a-f').classList.add('erro'); locIn.focus(); return msg('Escolha a Localidade', true); }
    // Data e hora do momento do clique (vão para o texto e para a planilha).
    const agora = new Date();
    c.data = agora.toLocaleDateString('pt-BR');
    c.hora = agora.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    if (textoEditado) $('c-texto').value = $('c-texto').value.replace(/^Data\/Hora:.*$/m, `Data/Hora: ${c.data} ${c.hora}`);
    render(); salvar();
    const auto = false; // teste: nunca envia sozinho
    etapas(['Abrir Novo chamado (processo)', 'Preencher campos', 'Conferir e clicar em Enviar']);
    etapa(0, 'run');
    $('c-abrir').classList.add('carregando');
    const r = await OTRS.abrirProcesso(PROCESSO, {
      f: { localidade: locAtual(), empresa: c.empresa, contato: c.contato },
      fixos: { tipo: aj.tipo, servicoSgf: aj.sgf, servico: aj.servico, sla: aj.sla, site: aj.site },
      assunto: $('c-assunto').value || assuntoPadrao(),
      texto: textoHtml($('c-texto').value),
      enviar: auto
    }).catch((e) => ({ ok: false, erro: e.message }));
    $('c-abrir').classList.remove('carregando');
    if (!r || r.erro) { etapa(0, 'erro', (r && r.erro) || 'falhou'); return msg((r && r.erro) || 'Não abriu', true); }
    etapa(0, 'ok', r.versao ? 'código v' + r.versao : '');
    const nomes = { tipo: 'Tipo', localidade: 'Localidade', fantasia: 'Nome fantasia', razao: 'Razão social', telefone: 'Telefone', servicoSgf: 'Serviço SGF', servico: 'Serviço', sla: 'SLA', site: 'Site', texto: 'Texto', assunto: 'Assunto', formulario: 'Formulário' };
    if (!r.ok) { etapa(1, 'erro', (r.falhas || []).map((f) => nomes[f] || f).join(', ')); msg('Alguns campos não foram preenchidos. Confira no OTRS.', true); }
    else etapa(1, 'ok');
    etapa(2, 'vez', 'confira e envie');
  };

  $('c-limpar').onclick = () => {
    c = { fontes: {} }; textoEditado = false; assuntoEditado = false;
    $('c-etapas').hidden = true;
    render(); salvar();
  };

  // ---------- início ----------
  (async () => {
    aj = { ...AJUSTES_PADRAO, ...((await get('com_ajustes')) || {}) };
    const s = await get('com_atual');
    if (s && s.c) {
      c = { fontes: {}, ...s.c }; textoEditado = !!s.textoEditado; assuntoEditado = !!s.assuntoEditado;
      if (textoEditado) $('c-texto').value = s.texto || '';
      if (assuntoEditado) $('c-assunto').value = s.assunto || '';
    }
    render();
    if ((await get('noc_modo')) === 'comercial') modo(true);
  })();

  self.__comercial = { extrairCliente }; // testes
})();
