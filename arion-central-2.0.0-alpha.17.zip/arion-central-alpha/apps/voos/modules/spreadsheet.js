/* modules/spreadsheet.js
 * Leitura da planilha (SheetJS), mapeamento tolerante de colunas e
 * normalização das linhas em voos utilizáveis pelo resto da extensão.
 * Só é carregado no popup (usa a lib xlsx.full.min.js e APIs de File).
 */
(function () {

const { normalizeHeader, toHHMM, toISODate, dateFromISOAndHHMM, formatHHMM, formatISODate } = self.Fmt;

// Colunas da planilha (conforme especificação) -> campo interno.
// Ordem importa: aliases mais específicos primeiro, para não deixar um
// alias curto capturar por engano a coluna errada.
const HEADER_ALIASES = {
  chegada_partida: ["tipo de voo", "tipo voo", "chegada partida", "chegada/partida", "movimento"],
  natureza: ["natureza"],
  data: ["data do voo", "data voo", "data"],
  empresa: ["companhia aerea", "companhia", "empresa", "cia aerea", "cia", "airline"],
  voo: ["numero do voo", "numero voo", "no voo", "n voo", "nr voo", "flight", "voo", "numero"],
  aeronave: ["modelo da aeronave", "modelo aeronave", "aeronave", "modelo"],
  horario: [
    "horario de partida",
    "horario partida",
    "horario (hora local)",
    "horario hora local",
    "hora local",
    "horario do voo",
    "horario voo",
    "hora do voo",
    "hora voo",
    "horario",
    "hora",
  ],
  destino: ["rota", "destino", "origem destino", "origem/destino"],
  assentos: ["numero de assentos", "numero assentos", "n assentos", "assentos"],
  tipo_de_servico: ["tipo de servico", "tipo servico", "servico"],
  dia_da_semana: ["dia da semana", "dia semana"],
};

/**
 * Recebe as chaves de uma linha (como vieram do sheet_to_json) e devolve um
 * mapa { empresa: "Companhia Aérea", horario: "Horário de Partida", ... }
 * ligando cada campo canônico à coluna real encontrada na planilha.
 */
function buildHeaderMap(rowKeys) {
  const normalizedToOriginal = rowKeys.map((k) => [normalizeHeader(k), k]);
  const map = {};
  const usedOriginals = new Set();

  for (const [canonical, aliases] of Object.entries(HEADER_ALIASES)) {
    for (const alias of aliases) {
      const found = normalizedToOriginal.find(
        ([normalized, original]) => normalized.includes(alias) && !usedOriginals.has(original)
      );
      if (found) {
        map[canonical] = found[1];
        usedOriginals.add(found[1]);
        break;
      }
    }
  }
  return map;
}

/**
 * Planilhas reais nem sempre têm o cabeçalho na linha 1. Esta função recebe
 * a matriz bruta (array de arrays) e localiza a linha que melhor parece ser
 * o cabeçalho de voos, testando as primeiras linhas.
 * Retorna { rows, headerRowIndex, missingRequired }.
 */
const REQUIRED_FIELDS = ["chegada_partida", "natureza", "data", "empresa", "voo", "horario"];

function rowsFromSheetAOA(aoa) {
  const SCAN_LIMIT = Math.min(aoa.length, 15);

  let bestIndex = -1;
  let bestScore = 0;
  let bestMap = {};

  for (let i = 0; i < SCAN_LIMIT; i++) {
    const candidate = aoa[i] || [];
    if (!candidate.some((c) => String(c ?? "").trim() !== "")) continue; // linha vazia

    const map = buildHeaderMap(candidate.map((c) => String(c ?? "")));
    const score = REQUIRED_FIELDS.filter((k) => map[k]).length;

    if (score > bestScore) {
      bestScore = score;
      bestIndex = i;
      bestMap = map;
    }
    if (score === REQUIRED_FIELDS.length) break;
  }

  if (bestScore < REQUIRED_FIELDS.length) {
    const missing = REQUIRED_FIELDS.filter((k) => !bestMap[k]);
    return { rows: [], headerRowIndex: -1, missingRequired: missing };
  }

  const headerRow = aoa[bestIndex].map((c) => String(c ?? "").trim());
  const rows = [];

  for (let r = bestIndex + 1; r < aoa.length; r++) {
    const raw = aoa[r] || [];
    if (!raw.some((c) => String(c ?? "").trim() !== "")) continue; // pula linhas vazias

    const obj = {};
    headerRow.forEach((h, colIdx) => {
      if (!h) return;
      obj[h] = raw[colIdx] ?? "";
    });
    rows.push(obj);
  }

  return { rows, headerRowIndex: bestIndex, missingRequired: [] };
}

// ---------- Leitura do arquivo ----------

// Carrega libs/xlsx.full.min.js sob demanda (881KB) — só quando o
// usuário realmente importar uma planilha, em vez de bloquear toda
// abertura do popup.
let xlsxLoadPromise = null;
function ensureXLSXLoaded() {
  if (self.XLSX) return Promise.resolve();
  if (xlsxLoadPromise) return xlsxLoadPromise;
  xlsxLoadPromise = new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = "libs/xlsx.full.min.js";
    script.onload = resolve;
    script.onerror = reject;
    document.head.appendChild(script);
  });
  return xlsxLoadPromise;
}

/** Lê um File (.xlsx/.xls/.csv) e devolve a matriz bruta (array de arrays) */
async function readFileToAOA(file) {
  await ensureXLSXLoaded();
  const isCSV = /\.csv$/i.test(file.name);
  let workbook;

  if (isCSV) {
    // CSV é texto puro — se lido como buffer binário genérico, acentos
    // ficam corrompidos (mojibake), o que quebra o reconhecimento das
    // colunas. Decodifica como UTF-8 explicitamente antes do SheetJS.
    const buffer = await file.arrayBuffer();
    const text = new TextDecoder("utf-8").decode(buffer);
    // raw:true → cada célula fica como texto ("03/11/2026", "21:10").
    // Sem isso, o SheetJS lia a data no formato americano (mês/dia) e montava a
    // hora com o fuso histórico de 1899 (-3:06), adiantando a partida em ~3 h.
    workbook = XLSX.read(text, { type: "string", raw: true });
  } else {
    const buffer = await file.arrayBuffer();
    // cellDates:false → datas/horas chegam como número serial do Excel, sem
    // deslocamento de fuso (com Date, o SheetJS muda o dia conforme o fuso do PC).
    workbook = XLSX.read(buffer, { type: "array", cellDates: false });
  }

  const firstSheet = workbook.Sheets[workbook.SheetNames[0]];
  return XLSX.utils.sheet_to_json(firstSheet, { header: 1, defval: "" });
}

// ---------- Parsing / normalização de voos ----------

/** true se o texto (normalizado) indica um voo de Partida */
function isPartida(value) {
  const v = normalizeHeader(value);
  return v.startsWith("partida");
}

/** true se o texto (normalizado) indica natureza Internacional */
function isInternacional(value) {
  const v = normalizeHeader(value);
  return v.startsWith("int") || v.includes("internacional");
}

/** Lê linhas cruas (array de objetos) e devolve TODOS os voos normalizados (sem filtrar) */
function parseAllRows(rows) {
  const flights = [];
  if (!rows || !rows.length) return flights;

  const headerMap = buildHeaderMap(Object.keys(rows[0]));

  rows.forEach((row, idx) => {
    const chegadaPartidaRaw = headerMap.chegada_partida ? row[headerMap.chegada_partida] : "";
    const naturezaRaw = headerMap.natureza ? row[headerMap.natureza] : "";
    const horarioVoo = headerMap.horario ? toHHMM(row[headerMap.horario]) : null;
    const dataVoo = headerMap.data ? toISODate(row[headerMap.data]) : null;
    if (!horarioVoo || !dataVoo) return;

    const empresa = String((headerMap.empresa ? row[headerMap.empresa] : "") ?? "").trim();
    const numeroVoo = String((headerMap.voo ? row[headerMap.voo] : "") ?? "").trim();
    const aeronave = String((headerMap.aeronave ? row[headerMap.aeronave] : "") ?? "").trim();
    const destinoRaw = String((headerMap.destino ? row[headerMap.destino] : "") ?? "").trim();
    const assentos = String((headerMap.assentos ? row[headerMap.assentos] : "") ?? "").trim();
    const tipoServico = String((headerMap.tipo_de_servico ? row[headerMap.tipo_de_servico] : "") ?? "").trim();
    const diaSemana = String((headerMap.dia_da_semana ? row[headerMap.dia_da_semana] : "") ?? "").trim();

    // Aritmética real de datas para não quebrar em voos que cruzam a
    // meia-noite (ex.: voo às 01:30 -> inspeção às 21:30 do dia anterior).
    const horarioVooDate = dateFromISOAndHHMM(dataVoo, horarioVoo);
    const inspecaoDate = new Date(horarioVooDate.getTime() - 4 * 60 * 60 * 1000);
    const acompanhamentoDate = new Date(horarioVooDate.getTime() - 1 * 60 * 60 * 1000);

    flights.push({
      id: `${dataVoo}_${numeroVoo || idx}_${horarioVoo}`,
      chegadaPartida: String(chegadaPartidaRaw ?? "").trim(),
      natureza: String(naturezaRaw ?? "").trim(),
      empresa,
      numeroVoo,
      aeronave,
      dataVoo,
      horarioVoo,
      horarioVooTimestamp: horarioVooDate.getTime(),
      destinoRaw,
      assentos,
      tipoServico,
      diaSemana,

      inspecaoTime: formatHHMM(inspecaoDate),
      inspecaoDate: formatISODate(inspecaoDate),
      inspecaoTimestamp: inspecaoDate.getTime(),

      acompanhamentoTime: formatHHMM(acompanhamentoDate),
      acompanhamentoDate: formatISODate(acompanhamentoDate),
      acompanhamentoTimestamp: acompanhamentoDate.getTime(),

      status: { inspecao: "pendente", acompanhamento: "pendente" },
    });
  });
  return flights;
}

/** Filtra: Tipo de Voo = Partida, Natureza = Internacional, Data = dataISO. Ordena por horário. */
function filterFlights(allFlights, dataISO) {
  return allFlights
    .filter((f) => isPartida(f.chegadaPartida) && isInternacional(f.natureza) && f.dataVoo === dataISO)
    .sort((a, b) => a.horarioVooTimestamp - b.horarioVooTimestamp);
}

if (typeof self !== "undefined") {
  self.Spreadsheet = {
    HEADER_ALIASES,
    REQUIRED_FIELDS,
    buildHeaderMap,
    rowsFromSheetAOA,
    readFileToAOA,
    parseAllRows,
    filterFlights,
    isPartida,
    isInternacional,
  };
}

})();
