// ---------- Atalhos para os módulos ----------
const { todayISO, isoToBR, eventTimeLabel, circledNumber } = self.Fmt;
const {
  DEFAULT_SETTINGS,
  DEFAULT_ALARM_SETTINGS,
  resolveDestino,
  fieldOrderFor,
  FIELD_LABELS,
  buildInspecaoFields,
  buildAcompanhamentoFields,
  composeChamadoText,
  copyFieldValue,
  copyFieldAndBelow,
  buildFlightBundle,
  buildAllFlightsText,
  buildServiceAideFields,
  SERVICEAIDE_READ_FIELDS,
  buildInformeChamado,
  buildInformeServiceAide,
  cleanChamado,
} = self.Templates;
const Storage = self.Storage;
const { readFileToAOA, rowsFromSheetAOA, parseAllRows, filterFlights } = self.Spreadsheet;
const {
  computeAlarmEntries,
  alarmStatus,
  REPETIR_LABEL,
  TIPO_LABEL,
  nextDateISO,
  nextCustomTimestamp,
  customFireTimestamp,
  customAlarmStatus,
} = self.Alarms;
const { copyText } = self.Clipboard;
const { pasteToServiceAide, captureFromServiceAide } = self.Autofill;

const CHECK_ICON = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="m5 12 5 5 9-10" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
const PASTE_ICON = `<svg class="btn-icon" width="15" height="15" viewBox="0 0 24 24" fill="none" aria-hidden="true" focusable="false"><rect x="6" y="4" width="12" height="17" rx="2" stroke="currentColor" stroke-width="2"/><path d="M9 4.5V3h6v1.5M9.5 12.5l2 2 3.5-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

// ---------- Elementos ----------
const importZone = document.getElementById("import-zone");
const fileInfoBar = document.getElementById("file-info-bar");
const fileInfoName = document.getElementById("file-info-name");
const fileInfoCount = document.getElementById("file-info-count");
const reimportBtn = document.getElementById("reimport-btn");
const dropzone = document.getElementById("dropzone");
const fileInput = document.getElementById("file-input");
const statusBar = document.getElementById("status-bar");
const copyToast = document.getElementById("copy-toast");
const tableWrap = document.getElementById("table-wrap");
const flightList = document.getElementById("flight-list");
const listActions = document.getElementById("list-actions");
const copyAllBtn = document.getElementById("copy-all-btn");
const headerDateLabel = document.getElementById("header-date-label");
const clearBtn = document.getElementById("clear-btn");
const openTabLink = document.getElementById("open-tab-link");
const datePicker = document.getElementById("date-picker");

const tabButtons = {
  voos: document.getElementById("tab-voos-btn"),
  config: document.getElementById("tab-config-btn"),
  despertar: document.getElementById("tab-despertar-btn"),
};
const tabPanels = {
  voos: document.getElementById("tab-voos-panel"),
  config: document.getElementById("tab-config-panel"),
  despertar: document.getElementById("tab-despertar-panel"),
};

const settingsSave = document.getElementById("settings-save");
const settingsSavedMsg = document.getElementById("settings-saved-msg");
const setFields = {
  atendente: document.getElementById("set-atendente"),
  solicitante: document.getElementById("set-solicitante"),
  ramalInspecao: document.getElementById("set-ramal-inspecao"),
  ramalAcompanhamento: document.getElementById("set-ramal-acompanhamento"),
  email: document.getElementById("set-email"),
  saMatricula: document.getElementById("set-sa-matricula"),
  saEquipamento: document.getElementById("set-sa-equipamento"),
  saLocalPrefixo: document.getElementById("set-sa-local"),
  saNomeBusca: document.getElementById("set-sa-nome-busca"),
  saNomeSelecionar: document.getElementById("set-sa-nome-sel"),
  saTelefone: document.getElementById("set-sa-telefone"),
  saDeptCompanhias: document.getElementById("set-sa-dept-cias"),
  saDeptPadrao: document.getElementById("set-sa-dept-padrao"),
  slaHoras: document.getElementById("set-sla-horas"),
};
// Campos de texto das Configurações (salvos com fallback no padrão)
const TEXT_SETTING_KEYS = [
  "atendente", "solicitante", "ramalInspecao", "ramalAcompanhamento", "email",
  "saMatricula", "saEquipamento", "saLocalPrefixo", "saNomeBusca", "saNomeSelecionar",
  "saTelefone", "saDeptCompanhias", "saDeptPadrao",
];

const alarmsSave = document.getElementById("alarms-save");
const alarmsSavedMsg = document.getElementById("alarms-saved-msg");
const alarmFields = {
  minutosInspecao: document.getElementById("set-min-inspecao"),
  minutosAcompanhamento: document.getElementById("set-min-acompanhamento"),
};
const alertsList = document.getElementById("alerts-list");
const flightAlertsList = document.getElementById("flight-alerts-list");
const firedAlarmsList = document.getElementById("fired-alarms");

// ---------- Estado ----------
let currentSettings = { ...DEFAULT_SETTINGS };
let currentAlarmSettings = { ...DEFAULT_ALARM_SETTINGS };
let currentAlarmOverrides = {}; // ajustes individuais de horário/ativação por alarme (estilo despertador)
let customAlarms = []; // tarefas e lembretes criados pelo botão +
let guideTarget = null; // { flightId, kind, until } — botão a destacar após clicar em "Partida"
const GUIDE_MS = 8000;
// Voos já carregados, por data (dataISO -> voos normalizados daquele dia, sem
// filtro de Partida/Internacional). Evita recarregar a planilha inteira a
// cada abertura: só busca no storage a data que ainda não está em cache.
let dayFlightsCache = {};
let selectedDate = todayISO();
let totalFlightCount = 0;
let currentFileName = "";
let filteredFlights = []; // resultado do filtro (Partida + Internacional + data) da data selecionada
let flightStatusMap = {};
let forceShowImport = false;

// Estado de UI dos cards de voo (accordion de 3 níveis), independente por voo.
// expandedFlights[flightId] = true  -> card mostra as opções INSPEÇÃO/ACOMPANHAMENTO
// openSections[flightId] = { inspecao: bool, acompanhamento: bool } -> gaveta aberta
// fieldValues[flightId] = { inspecao: {...campos}, acompanhamento: {...campos} }
let expandedFlights = {};
let openSections = {};
let fieldValues = {};
const firedAlarmCards = new Map(); // alarmId -> elemento do card exibido no painel
let currentMuteUntil = 0; // 0 = som ativo · -1 = até reativar · timestamp = silenciado até

// Elementos de "silenciar alarmes"
const muteToggleBtn = document.getElementById("mute-toggle-btn");
const muteIconOn = document.getElementById("mute-icon-on");
const muteIconOff = document.getElementById("mute-icon-off");
const muteBanner = document.getElementById("mute-banner");
const muteBannerText = document.getElementById("mute-banner-text");
const muteBannerOff = document.getElementById("mute-banner-off");
const muteStatus = document.getElementById("mute-status");
const soundEnabledInput = document.getElementById("sound-enabled-input");
const testSoundBtn = document.getElementById("test-sound-btn");
const soundSelect = document.getElementById("alarm-sound-select");

initTheme();
init();

// Alarme disparou (mesmo com o painel fechado, quem cria o card é o
// background) — mostra aqui também um card com "Adiar"/"Desativar", pra não
// depender só do usuário perceber e clicar na notificação do navegador.
chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "ALARM_FIRED") {
    showFiredAlarmCard(message);
  }
});

/** Retorna (e cacheia em memória) os voos de UMA data, buscando no storage só
 * na primeira vez que aquela data é usada nesta sessão do painel. */
async function loadFlightsForDate(dateISO) {
  if (!(dateISO in dayFlightsCache)) {
    dayFlightsCache[dateISO] = await Storage.getFlightsForDate(dateISO);
  }
  return dayFlightsCache[dateISO];
}

const themeToggleBtn = document.getElementById("theme-toggle-btn");
const themeIconSun = document.getElementById("theme-icon-sun");
const themeIconMoon = document.getElementById("theme-icon-moon");

function applyTheme(theme) {
  document.documentElement.setAttribute("data-theme", theme);
  themeIconSun.hidden = theme === "dark";
  themeIconMoon.hidden = theme !== "dark";
}

async function initTheme() {
  const theme = await Storage.getTheme();
  applyTheme(theme);
}

themeToggleBtn.addEventListener("click", async () => {
  const current = document.documentElement.getAttribute("data-theme") === "dark" ? "dark" : "light";
  const next = current === "dark" ? "light" : "dark";
  applyTheme(next);
  await Storage.setTheme(next);
});

async function init() {
  await Storage.migrateLegacyRawRows();

  customAlarms = await Storage.getCustomAlarms();
  const [settings, alarmSettings, alarmOverrides, savedDate, fileName, totalCount, statusMap, muteUntil] = await Promise.all([
    Storage.getSettings(),
    Storage.getAlarmSettings(),
    Storage.getAlarmOverrides(),
    Storage.getSelectedDate(),
    Storage.getFileName(),
    Storage.getTotalFlightCount(),
    Storage.getFlightStatusMap(),
    Storage.getMuteUntil(),
  ]);
  currentMuteUntil = muteUntil;
  renderMuteState();

  currentSettings = settings;
  currentAlarmSettings = alarmSettings;
  currentAlarmOverrides = alarmOverrides;
  selectedDate = savedDate || todayISO();
  currentFileName = fileName;
  totalFlightCount = totalCount;
  flightStatusMap = statusMap;

  await loadFlightsForDate(selectedDate); // só o dia em uso — os demais carregam sob demanda

  populateSettingsFields();
  populateAlarmFields();
  await initSound();
  datePicker.value = selectedDate;
  updateHeaderDate();
  updateFileInfoBar(currentFileName, totalFlightCount);

  recomputeAndRender();

  // Mantém a lista de alarmes (Despertar) atualizada enquanto o painel fica
  // aberto, sem precisar de nenhuma ação do usuário — só quando a aba está
  // visível, pra não gastar trabalho à toa.
  setInterval(updatePastChips, 20000);
  setInterval(async () => {
    if (!tabPanels.despertar.hidden) renderAlertsList();
    // Silêncio temporário expira sozinho — atualiza o indicador
    if (currentMuteUntil > 0) {
      currentMuteUntil = await Storage.getMuteUntil();
      renderMuteState();
    }
  }, 30000);
}

// Marca com linha tracejada leve o horário que já passou (sem redesenhar os cards).
function updatePastChips() {
  const now = Date.now();
  document.querySelectorAll(".time-chip[data-ts]").forEach((el) => {
    el.classList.toggle("is-past", Number(el.dataset.ts) <= now);
  });
}

function updateHeaderDate() {
  headerDateLabel.textContent = selectedDate ? isoToBR(selectedDate) : "";
}

function updateFileInfoBar(fileName, totalRows) {
  const hasData = !!fileName && totalRows > 0;
  fileInfoBar.hidden = !hasData;
  if (hasData) {
    fileInfoName.textContent = fileName;
    fileInfoCount.textContent = `${totalRows} registro(s) na planilha`;
  }
  updateImportVisibility(hasData);
}

function updateImportVisibility(hasData) {
  const showImport = !hasData || forceShowImport;
  importZone.hidden = !showImport;
}

// ---------- Abas ----------
function switchTab(tab) {
  Object.entries(tabPanels).forEach(([key, panel]) => {
    panel.hidden = key !== tab;
  });
  Object.entries(tabButtons).forEach(([key, btn]) => {
    const active = key === tab;
    btn.classList.toggle("active", active);
    btn.setAttribute("aria-selected", String(active));
  });
  if (tab === "despertar") renderAlertsList();
}
tabButtons.voos.addEventListener("click", () => switchTab("voos"));
tabButtons.config.addEventListener("click", () => switchTab("config"));
tabButtons.despertar.addEventListener("click", () => switchTab("despertar"));

// ---------- Drag and drop / seleção de arquivo ----------
dropzone.addEventListener("click", () => fileInput.click());
dropzone.addEventListener("keydown", (e) => {
  if (e.key === "Enter" || e.key === " ") {
    e.preventDefault();
    fileInput.click();
  }
});
dropzone.addEventListener("dragover", (e) => {
  e.preventDefault();
  dropzone.classList.add("dragover");
});
dropzone.addEventListener("dragleave", () => dropzone.classList.remove("dragover"));
dropzone.addEventListener("drop", (e) => {
  e.preventDefault();
  dropzone.classList.remove("dragover");
  const file = e.dataTransfer.files[0];
  if (file) handleFile(file);
});
fileInput.addEventListener("change", () => {
  const file = fileInput.files[0];
  if (file) handleFile(file);
});

openTabLink.addEventListener("click", (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: chrome.runtime.getURL("apps/voos/popup.html?mode=tab") });
});

reimportBtn.addEventListener("click", () => {
  forceShowImport = true;
  updateImportVisibility(true);
});

// ---------- Data selecionada ----------
datePicker.addEventListener("change", async () => {
  selectedDate = datePicker.value || todayISO();
  updateHeaderDate();
  await Storage.setSelectedDate(selectedDate);
  await loadFlightsForDate(selectedDate); // só busca no storage se ainda não estiver em cache
  recomputeAndRender();
  requestReschedule();
});

// ---------- Limpar dados ----------
clearBtn.addEventListener("click", async () => {
  await Storage.clearFlightData();
  chrome.runtime.sendMessage({ type: "CLEAR_ALARMS" }).catch(() => {});
  dayFlightsCache = {};
  totalFlightCount = 0;
  currentFileName = "";
  flightStatusMap = {};
  forceShowImport = false;
  expandedFlights = {};
  openSections = {};
  fieldValues = {};
  currentAlarmOverrides = {};
  updateFileInfoBar("", 0);
  recomputeAndRender();
  setStatus("Dados da planilha removidos. Configurações e alertas foram mantidos.", false);
});

// ---------- Configurações ----------
function populateSettingsFields() {
  TEXT_SETTING_KEYS.forEach((k) => {
    if (setFields[k]) setFields[k].value = currentSettings[k] ?? "";
  });
  setFields.slaHoras.value = currentSettings.slaHoras ?? 0;
}

settingsSave.addEventListener("click", async () => {
  currentSettings = {};
  TEXT_SETTING_KEYS.forEach((k) => {
    currentSettings[k] = setFields[k].value.trim() || DEFAULT_SETTINGS[k];
  });
  const sla = Number(setFields.slaHoras.value);
  currentSettings.slaHoras = Number.isFinite(sla) && sla >= 0 ? sla : 0;
  await Storage.setSettings(currentSettings);
  flashMessage(settingsSavedMsg);
  // Ação explícita do usuário: descarta os campos já gerados para que os
  // chamados voltem a ser montados com os novos dados de Atendente/Ramal/E-mail.
  fieldValues = {};
  renderCards(filteredFlights); // os campos preenchidos automaticamente usam as novas configurações
});

// ---------- Silenciar alarmes ----------
function isMutedNow() {
  return Storage.isMutedValue(currentMuteUntil);
}

function muteLabel() {
  if (currentMuteUntil === Storage.MUTE_FOREVER) return "Silenciado até reativar";
  if (currentMuteUntil > 0) {
    const d = new Date(currentMuteUntil);
    const hh = String(d.getHours()).padStart(2, "0");
    const mm = String(d.getMinutes()).padStart(2, "0");
    return `Silenciado até ${hh}:${mm}`;
  }
  return "Som ativo";
}

function renderMuteState() {
  const muted = isMutedNow();
  if (!muted && currentMuteUntil !== 0) currentMuteUntil = 0;
  muteIconOn.hidden = muted;
  muteIconOff.hidden = !muted;
  muteToggleBtn.classList.toggle("is-muted", muted);
  muteToggleBtn.setAttribute("aria-pressed", String(muted));
  muteToggleBtn.title = muted ? "Reativar som dos alarmes" : "Silenciar alarmes";
  muteBanner.hidden = !muted;
  muteBannerText.textContent = muteLabel();
  muteStatus.textContent = muteLabel();
  muteStatus.classList.toggle("is-muted", muted);
  soundEnabledInput.checked = !muted;
  document.querySelectorAll(".chip[data-mute-min]").forEach((chip) => {
    const min = Number(chip.dataset.muteMin);
    chip.classList.toggle("active", min === -1 && currentMuteUntil === Storage.MUTE_FOREVER);
  });
}

async function setMute(muteUntil) {
  currentMuteUntil = muteUntil;
  renderMuteState();
  try {
    await chrome.runtime.sendMessage({ type: "SET_MUTE", muteUntil });
  } catch (_) {
    await Storage.setMuteUntil(muteUntil);
  }
  if (Storage.isMutedValue(muteUntil)) {
    // Também para qualquer som tocando agora
    chrome.runtime.sendMessage({ type: "STOP_SOUND" }).catch(() => {});
  }
}

muteToggleBtn.addEventListener("click", () => setMute(isMutedNow() ? 0 : Storage.MUTE_FOREVER));
muteBannerOff.addEventListener("click", () => setMute(0));
soundEnabledInput.addEventListener("change", () => setMute(soundEnabledInput.checked ? 0 : Storage.MUTE_FOREVER));
document.querySelectorAll(".chip[data-mute-min]").forEach((chip) => {
  chip.addEventListener("click", () => {
    const min = Number(chip.dataset.muteMin);
    setMute(min === -1 ? Storage.MUTE_FOREVER : Date.now() + min * 60 * 1000);
  });
});
testSoundBtn.addEventListener("click", () => {
  chrome.runtime.sendMessage({ type: "TEST_SOUND", soundId: soundSelect.value }).catch(() => {});
});

// ---------- Som do alarme (escolha entre vários sons) ----------
async function initSound() {
  const lista = self.ARION_SONS || [];
  soundSelect.innerHTML = lista
    .map((x) => `<option value="${escapeHtml(x.id)}">${escapeHtml(x.nome)}</option>`)
    .join("");
  const salvo = await Storage.getAlarmSound();
  soundSelect.value = lista.some((x) => x.id === salvo) ? salvo : (lista[0] && lista[0].id) || "";
}
soundSelect.addEventListener("change", async () => {
  await Storage.setAlarmSound(soundSelect.value);
  // Ouve o som escolhido por 3 segundos.
  chrome.runtime.sendMessage({ type: "TEST_SOUND", soundId: soundSelect.value }).catch(() => {});
});

// ---------- Alarme ----------
function populateAlarmFields() {
  alarmFields.minutosInspecao.value = currentAlarmSettings.minutosInspecao;
  alarmFields.minutosAcompanhamento.value = currentAlarmSettings.minutosAcompanhamento;
}

alarmsSave.addEventListener("click", async () => {
  const minInsp = Number(alarmFields.minutosInspecao.value);
  const minAcomp = Number(alarmFields.minutosAcompanhamento.value);
  currentAlarmSettings = {
    minutosInspecao: Number.isFinite(minInsp) && minInsp >= 0 ? minInsp : DEFAULT_ALARM_SETTINGS.minutosInspecao,
    minutosAcompanhamento:
      Number.isFinite(minAcomp) && minAcomp >= 0 ? minAcomp : DEFAULT_ALARM_SETTINGS.minutosAcompanhamento,
  };
  await Storage.setAlarmSettings(currentAlarmSettings);
  flashMessage(alarmsSavedMsg);
  renderAlertsList();
  requestReschedule();
});

const GOTO_ICON = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" aria-hidden="true"><path d="M7 17 17 7M9 7h8v8" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

function toggleHtml(enabled) {
  return `
            <label class="toggle-switch" title="${enabled ? "Desativar alarme" : "Ativar alarme"}">
              <input type="checkbox" class="alarm-enabled-input" ${enabled ? "checked" : ""} />
              <span class="toggle-switch__track"><span class="toggle-switch__thumb"></span></span>
            </label>`;
}

function flightAlarmHtml(entry) {
  const status = alarmStatus(entry);
  const kindLabel = entry.kind === "inspecao" ? "Inspeção" : "Acompanhamento";
  const companyLine = [entry.empresa, entry.numeroVoo].filter(Boolean).join(" ");
  // Só trava o campo quando o usuário desativou o alarme explicitamente.
  // "Disparado" continua editável — o campo de horário nativo dispara
  // "change" assim que a hora é completada, antes dos minutos.
  const disabled = status === "desativado";
  return `
        <div class="alarm-item alarm-item--${status}" data-alarm-id="${escapeHtml(entry.id)}" data-source="voo">
          <div class="alarm-item__top">
            <input
              type="time"
              class="alarm-time-input"
              value="${entry.alarmeHHMM}"
              ${disabled ? "disabled" : ""}
              aria-label="Horário do alarme de ${escapeHtml(kindLabel)} — voo ${escapeHtml(companyLine)}"
            />${toggleHtml(entry.enabled)}
          </div>
          <div class="alarm-item__body">
            <span class="alarm-item__kind">${escapeHtml(kindLabel)}${entry.customTime ? " · horário próprio" : ""}</span>
            <span>Voo: ${escapeHtml(companyLine || "—")} · <button type="button" class="alarm-goto" data-flight-id="${escapeHtml(entry.flightId)}" data-kind="${entry.kind}" title="Ir para o voo e destacar onde colar">Partida ${entry.horarioPartida} ${GOTO_ICON}</button></span>
            <span class="alarm-item__status">${statusLabel(status)}</span>
          </div>
          ${entry.customTime ? `<button type="button" class="btn-link alarm-reset-btn">Usar horário padrão</button>` : ""}
        </div>`;
}

function customAlarmHtml(alarm) {
  const status = customAlarmStatus(alarm);
  const tipo = TIPO_LABEL[alarm.tipo] || "Tarefa";
  return `
        <div class="alarm-item alarm-item--${status}" data-custom-id="${escapeHtml(alarm.id)}" data-source="custom">
          <div class="alarm-item__top">
            <input type="time" class="alarm-time-input" value="${escapeHtml(alarm.hhmm)}"
              aria-label="Horário do alarme ${escapeHtml(alarm.titulo)}" />${toggleHtml(status === "agendado")}
          </div>
          <div class="alarm-item__body">
            <span class="alarm-item__kind">${escapeHtml(alarm.titulo)}</span>
            <span>${tipo} · ${REPETIR_LABEL[alarm.repetir] || REPETIR_LABEL.nao}</span>
            ${alarm.obs ? `<span class="alarm-item__obs">${escapeHtml(alarm.obs)}</span>` : ""}
            <span class="alarm-item__status">${statusLabel(status)}</span>
          </div>
          <div class="alarm-item__links">
            <button type="button" class="btn-link alarm-edit-btn">Editar</button>
            <button type="button" class="btn-link alarm-del-btn">Excluir</button>
          </div>
        </div>`;
}

function renderAlertsList() {
  // Reconstruir o innerHTML recria os <input>: guarda qual alarme estava
  // sendo editado para devolver o foco depois de redesenhar.
  const activeEl = document.activeElement;
  const editingItem =
    activeEl && activeEl.classList && activeEl.classList.contains("alarm-time-input")
      ? activeEl.closest(".alarm-item")
      : null;
  const editingKey = editingItem ? editingItem.dataset.alarmId || editingItem.dataset.customId : null;

  // Alarmes de voo já "concluídos" somem da lista; os próprios ficam até excluir.
  const now = Date.now();
  const flightEntries = computeAlarmEntries(filteredFlights, currentAlarmSettings, currentAlarmOverrides)
    .filter((entry) => alarmStatus(entry) !== "concluido")
    .map((entry) => ({ sort: entry.alarmeTimestamp, html: flightAlarmHtml(entry) }));
  const customEntries = customAlarms.map((a) => ({
    sort: customFireTimestamp(a, now) || nextCustomTimestamp({ ...a, enabled: true, repetir: a.repetir === "nao" ? "diario" : a.repetir }, now) + 1e13,
    html: customAlarmHtml(a),
  }));
  // Listas separadas: Meus alarmes (tarefas e lembretes) e Alarmes de voo.
  const ordenar = (l) => l.sort((a, b) => a.sort - b.sort).map((e) => e.html).join("");
  alertsList.innerHTML = customEntries.length
    ? ordenar(customEntries)
    : `<div class="empty-msg">Nenhum alarme próprio. Clique em + para criar uma tarefa ou um lembrete.</div>`;
  flightAlertsList.innerHTML = flightEntries.length
    ? ordenar(flightEntries)
    : `<div class="empty-msg">Nenhum alarme de voo para a data selecionada.</div>`;

  const both = { querySelectorAll: (sel) => [...alertsList.querySelectorAll(sel), ...flightAlertsList.querySelectorAll(sel)] };
  both.querySelectorAll(".alarm-time-input").forEach((input) => {
    input.addEventListener("change", () => onAlarmTimeChange(input));
  });
  both.querySelectorAll(".alarm-enabled-input").forEach((input) => {
    input.addEventListener("change", () => onAlarmEnabledChange(input));
  });
  both.querySelectorAll(".alarm-reset-btn").forEach((btn) => {
    btn.addEventListener("click", () => onAlarmResetTime(btn));
  });
  both.querySelectorAll(".alarm-goto").forEach((btn) => {
    btn.addEventListener("click", () => goToFlight(btn.dataset.flightId, btn.dataset.kind));
  });
  both.querySelectorAll(".alarm-edit-btn").forEach((btn) => {
    btn.addEventListener("click", () => openAlarmModal(btn.closest(".alarm-item").dataset.customId));
  });
  both.querySelectorAll(".alarm-del-btn").forEach((btn) => {
    btn.addEventListener("click", () => onCustomAlarmDelete(btn));
  });

  if (editingKey) {
    const item = Array.from(both.querySelectorAll(".alarm-item")).find(
      (el) => (el.dataset.alarmId || el.dataset.customId) === editingKey
    );
    const input = item?.querySelector(".alarm-time-input");
    if (input && !input.disabled) input.focus();
  }
}

// ---------- Alarmes próprios (tarefas e lembretes) ----------
const alarmModal = document.getElementById("alarm-modal");
const amTitle = document.getElementById("alarm-modal-title");
const amFields = {
  titulo: document.getElementById("am-titulo"),
  hora: document.getElementById("am-hora"),
  repetir: document.getElementById("am-repetir"),
  obs: document.getElementById("am-obs"),
};
const amError = document.getElementById("am-error");
const amSave = document.getElementById("am-save");
let amEditingId = null;
let amTipo = "tarefa";

function setAmTipo(tipo) {
  amTipo = tipo;
  alarmModal.querySelectorAll(".seg__btn").forEach((b) => {
    const on = b.dataset.tipo === tipo;
    b.classList.toggle("is-active", on);
    b.setAttribute("aria-checked", String(on));
  });
}

function showAmError(msg, field) {
  amError.textContent = msg;
  amError.hidden = !msg;
  Object.values(amFields).forEach((el) => el.classList.toggle("invalid", el === field));
  field?.focus();
}

function openAlarmModal(id) {
  const item = id ? customAlarms.find((a) => a.id === id) : null;
  amEditingId = item ? item.id : null;
  amTitle.textContent = item ? "Editar alarme" : "Novo alarme";
  amSave.textContent = item ? "Salvar" : "Criar alarme";
  setAmTipo(item?.tipo || "tarefa");
  amFields.titulo.value = item?.titulo || "";
  amFields.hora.value = item?.hhmm || "";
  amFields.repetir.value = item?.repetir || "nao";
  amFields.obs.value = item?.obs || "";
  showAmError("");
  alarmModal.hidden = false;
  amFields.titulo.focus();
}

function closeAlarmModal() {
  alarmModal.hidden = true;
  amEditingId = null;
}

async function saveCustomAlarm() {
  const titulo = amFields.titulo.value.trim();
  const hhmm = amFields.hora.value;
  if (!titulo) return showAmError("Digite um título.", amFields.titulo);
  if (!/^\d{2}:\d{2}$/.test(hhmm)) return showAmError("Escolha o horário.", amFields.hora);

  const alarm = {
    id: amEditingId || `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
    tipo: amTipo,
    titulo,
    hhmm,
    repetir: amFields.repetir.value,
    obs: amFields.obs.value.trim(),
    enabled: true,
    data: nextDateISO(hhmm),
    snoozeUntil: 0,
  };
  const editing = !!amEditingId;
  customAlarms = await Storage.upsertCustomAlarm(alarm);
  closeAlarmModal();
  renderAlertsList();
  requestReschedule();
  showCopyToast(editing ? "Alarme salvo" : "Alarme criado");
}

async function updateCustomAlarm(id, patch) {
  const item = customAlarms.find((a) => a.id === id);
  if (!item) return;
  customAlarms = await Storage.upsertCustomAlarm({ ...item, ...patch });
  renderAlertsList();
  requestReschedule();
}

async function onCustomAlarmDelete(btn) {
  const id = btn.closest(".alarm-item").dataset.customId;
  // 1º clique pede confirmação; 2º exclui.
  if (btn.dataset.confirm !== "1") {
    btn.dataset.confirm = "1";
    btn.textContent = "Confirmar exclusão";
    setTimeout(() => {
      if (btn.isConnected) { btn.dataset.confirm = ""; btn.textContent = "Excluir"; }
    }, 3000);
    return;
  }
  customAlarms = await Storage.deleteCustomAlarm(id);
  renderAlertsList();
  requestReschedule();
}

document.getElementById("add-alarm-btn").addEventListener("click", () => openAlarmModal(null));
document.getElementById("alarm-modal-close").addEventListener("click", closeAlarmModal);
document.getElementById("am-cancel").addEventListener("click", closeAlarmModal);
amSave.addEventListener("click", saveCustomAlarm);
alarmModal.addEventListener("click", (e) => { if (e.target === alarmModal) closeAlarmModal(); });
alarmModal.querySelectorAll(".seg__btn").forEach((b) => b.addEventListener("click", () => setAmTipo(b.dataset.tipo)));
Object.values(amFields).forEach((el) => el.addEventListener("input", () => showAmError("")));
alarmModal.addEventListener("keydown", (e) => {
  if (e.key === "Escape") closeAlarmModal();
  if (e.key === "Enter" && e.target.tagName === "INPUT") { e.preventDefault(); saveCustomAlarm(); }
});

// O background muda os alarmes próprios ao disparar (ex.: "uma vez" desliga).
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local" || !changes[Storage.KEYS.CUSTOM_ALARMS]) return;
  customAlarms = changes[Storage.KEYS.CUSTOM_ALARMS].newValue || [];
  if (!tabPanels.despertar.hidden && !alertsList.contains(document.activeElement)) renderAlertsList();
});

// ---------- "Partida HH:MM" → vai para o voo e destaca onde colar ----------
function goToFlight(flightId, kind) {
  guideTarget = { flightId, kind, until: Date.now() + GUIDE_MS };
  switchTab("voos");
  renderCards(filteredFlights);
  const card = Array.from(flightList.querySelectorAll(".flight-card")).find((c) => c.dataset.flightId === flightId);
  if (!card) return showCopyToast("Voo não encontrado na data selecionada", true);
  card.scrollIntoView({ behavior: "smooth", block: "center" });
  setTimeout(() => {
    if (guideTarget && Date.now() >= guideTarget.until) clearGuide();
  }, GUIDE_MS + 50);
}

function clearGuide() {
  guideTarget = null;
  flightList.querySelectorAll(".option-btn.is-guide").forEach((b) => b.classList.remove("is-guide"));
}

async function onAlarmTimeChange(input) {
  const customId = input.closest(".alarm-item").dataset.customId;
  if (customId) {
    if (!input.value) return;
    return updateCustomAlarm(customId, { hhmm: input.value, data: nextDateISO(input.value), enabled: true, snoozeUntil: 0 });
  }
  const alarmId = input.closest(".alarm-item").dataset.alarmId;
  const hhmm = input.value;
  if (!hhmm) return;
  currentAlarmOverrides = await Storage.setAlarmOverride(alarmId, { hhmm });
  renderAlertsList();
  requestReschedule();
}

async function onAlarmEnabledChange(input) {
  const customId = input.closest(".alarm-item").dataset.customId;
  if (customId) {
    const item = customAlarms.find((a) => a.id === customId);
    // Religar um "uma vez" já passado agenda para a próxima ocorrência.
    const patch = input.checked
      ? { enabled: true, data: nextDateISO(item?.hhmm), snoozeUntil: 0 }
      : { enabled: false, snoozeUntil: 0 };
    return updateCustomAlarm(customId, patch);
  }
  const alarmId = input.closest(".alarm-item").dataset.alarmId;
  currentAlarmOverrides = await Storage.setAlarmOverride(alarmId, { enabled: input.checked });
  renderAlertsList();
  requestReschedule();
}

async function onAlarmResetTime(btn) {
  const alarmItem = btn.closest(".alarm-item");
  const alarmId = alarmItem.dataset.alarmId;
  // Mantém o estado ativado/desativado, só descarta o horário customizado.
  currentAlarmOverrides = await Storage.setAlarmOverride(alarmId, { hhmm: null });
  renderAlertsList();
  requestReschedule();
}

/** Card fixo no topo do painel quando um alarme dispara, com botões de
 * Adiar/Desativar — além da notificação do navegador, pra garantir que o
 * usuário sempre tenha um botão visível e clicável dentro da própria
 * extensão, mesmo se a notificação do sistema passar despercebida. */
function showFiredAlarmCard({ alarmId, title, message, muted }) {
  if (!alarmId || firedAlarmCards.has(alarmId)) return;

  const card = document.createElement("div");
  card.className = "fired-alarm-card";
  card.innerHTML = `
    <div class="fired-alarm-card__title">${escapeHtml(title || "Alarme")}</div>
    <div class="fired-alarm-card__msg">${escapeHtml(message || "")}</div>
    <div class="fired-alarm-card__actions">
      <button type="button" class="btn btn--primary fired-alarm-snooze">Adiar 5 min</button>
      <button type="button" class="btn btn--ghost fired-alarm-dismiss">Desativar</button>
      ${muted ? "" : `<button type="button" class="btn btn--quiet fired-alarm-stop" title="Para só o som; o alarme continua na tela">Parar som</button>`}
    </div>`;
  card.querySelector(".fired-alarm-stop")?.addEventListener("click", (e) => {
    chrome.runtime.sendMessage({ type: "STOP_SOUND" }).catch(() => {});
    e.currentTarget.remove();
  });

  card.querySelector(".fired-alarm-snooze").addEventListener("click", () =>
    resolveFiredAlarmCard(alarmId, "SNOOZE_ALARM")
  );
  card.querySelector(".fired-alarm-dismiss").addEventListener("click", () =>
    resolveFiredAlarmCard(alarmId, "DISMISS_ALARM")
  );

  firedAlarmsList.appendChild(card);
  firedAlarmCards.set(alarmId, card);
}

async function resolveFiredAlarmCard(alarmId, messageType) {
  const card = firedAlarmCards.get(alarmId);
  if (card) {
    card.remove();
    firedAlarmCards.delete(alarmId);
  }
  try {
    await chrome.runtime.sendMessage({ type: messageType, alarmId });
  } catch (_) {
    // side panel pode ter perdido a conexão com o background — sem problema,
    // o botão da notificação do navegador continua funcionando normalmente.
  }
  renderAlertsList();
}

function statusLabel(status) {
  if (status === "agendado") return "Agendado";
  if (status === "disparado") return "Disparado";
  if (status === "desativado") return "Desativado";
  return "Concluído";
}

// ---------- Leitura da planilha ----------
async function handleFile(file) {
  const validExt = /\.(xlsx|xls|csv)$/i.test(file.name);
  if (!validExt) {
    setStatus("Formato inválido. Use .xlsx, .xls ou .csv.", true);
    return;
  }

  try {
    const aoa = await readFileToAOA(file);

    if (!aoa.length) {
      setStatus("A planilha está vazia.", true);
      return;
    }

    const { rows, headerRowIndex, missingRequired } = rowsFromSheetAOA(aoa);

    if (headerRowIndex === -1) {
      const names = (missingRequired || []).map(fieldDisplayName).join(", ");
      setStatus(
        `Coluna não encontrada: ${names || "cabeçalho da planilha"}. Verifique os nomes das colunas.`,
        true
      );
      return;
    }

    if (!rows.length) {
      setStatus("Cabeçalho encontrado, mas nenhuma linha de dados abaixo dele.", true);
      return;
    }

    const parsedFlights = parseAllRows(rows);
    flightStatusMap = {};
    // Nova planilha pode trazer novos voos/IDs — recria os formulários.
    expandedFlights = {};
    openSections = {};
    fieldValues = {};
    currentAlarmOverrides = {};
    await Storage.setFlightsData(parsedFlights, file.name);
    await chrome.storage.local.remove([Storage.KEYS.FLIGHT_STATUS, Storage.KEYS.ALARM_OVERRIDES]);

    // Já que os voos acabaram de ser parseados, popula o cache em memória
    // direto a partir deles — evita ler tudo de volta do storage agora.
    dayFlightsCache = {};
    parsedFlights.forEach((f) => {
      if (!dayFlightsCache[f.dataVoo]) dayFlightsCache[f.dataVoo] = [];
      dayFlightsCache[f.dataVoo].push(f);
    });
    totalFlightCount = parsedFlights.length;
    currentFileName = file.name;

    // Após importar, vai para hoje se a planilha tiver voos hoje (ou se não há data escolhida).
    if (!datePicker.value || dayFlightsCache[todayISO()]) {
      selectedDate = todayISO();
      datePicker.value = selectedDate;
      await Storage.setSelectedDate(selectedDate);
      updateHeaderDate();
    }

    forceShowImport = false;
    updateFileInfoBar(currentFileName, totalFlightCount);
    recomputeAndRender();
    requestReschedule();

    setStatus(
      filteredFlights.length
        ? `${filteredFlights.length} voo(s) internacional(is) de partida encontrado(s) para ${isoToBR(selectedDate)}.`
        : `Planilha lida (${totalFlightCount} voo(s) reconhecido(s)), mas nenhum voo internacional de partida para ${isoToBR(selectedDate)}.`,
      false
    );
  } catch (err) {
    console.error(err);
    setStatus(`Erro ao ler a planilha: ${err.message || "verifique o arquivo."}`, true);
  }
}

const FIELD_DISPLAY_NAMES = {
  chegada_partida: "Tipo de Voo",
  natureza: "Natureza",
  data: "Data do Voo",
  empresa: "Companhia Aérea",
  voo: "Número do Voo",
  horario: "Horário de Partida",
};
function fieldDisplayName(key) {
  return FIELD_DISPLAY_NAMES[key] || key;
}

function setStatus(msg, isError) {
  statusBar.textContent = msg;
  statusBar.classList.toggle("error", !!isError);
}

function flashMessage(el) {
  el.hidden = false;
  setTimeout(() => {
    el.hidden = true;
  }, 2000);
}

let copyToastTimer = null;
function showCopyToast(text = "Copiado", isError = false) {
  clearTimeout(copyToastTimer);
  copyToast.textContent = text;
  copyToast.classList.toggle("copy-toast--error", !!isError);
  copyToast.hidden = false;
  copyToastTimer = setTimeout(() => {
    copyToast.hidden = true;
  }, isError ? 4200 : 2200);
}

function requestReschedule() {
  chrome.runtime.sendMessage({ type: "RESCHEDULE_ALARMS" }).catch(() => {});
}

// ---------- Recalcular e renderizar tudo ----------
function recomputeAndRender() {
  filteredFlights = filterFlights(dayFlightsCache[selectedDate] || [], selectedDate);
  applyStatus(filteredFlights);
  renderTable(filteredFlights);
  renderCards(filteredFlights);
  updatePastChips();
  renderAlertsList();
}

function applyStatus(flights) {
  flights.forEach((f) => {
    f.status = flightStatusMap[f.id] || { inspecao: "pendente", acompanhamento: "pendente" };
  });
}

// ---------- Tabela de consulta ----------
function renderTable(flights) {
  if (!flights.length) {
    tableWrap.innerHTML = "";
    return;
  }

  const rows = flights
    .map((f, idx) => {
      const inspLabel = eventTimeLabel(f.inspecaoTime, f.inspecaoDate, f.dataVoo);
      const acompLabel = eventTimeLabel(f.acompanhamentoTime, f.acompanhamentoDate, f.dataVoo);
      return `
      <tr class="summary-row" data-flight-id="${escapeHtml(f.id)}">
        <td class="col-num">${numBadge(idx + 1)}</td>
        <td>${escapeHtml(f.empresa)}${f.numeroVoo ? " " + escapeHtml(f.numeroVoo) : ""}</td>
        <td class="col-partida">${f.horarioVoo}</td>
        <td>${escapeHtml(inspLabel)}</td>
        <td>${escapeHtml(acompLabel)}</td>
      </tr>`;
    })
    .join("");

  tableWrap.innerHTML = `
    <div class="summary-table-scroll">
      <table class="summary-table">
        <thead>
          <tr>
            <th>Nº</th><th>Voo</th><th>Partida</th>
            <th>Inspeção, 4h antes</th><th>Acompanhamento, 1h antes</th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    </div>
  `;

  tableWrap.querySelectorAll(".summary-row").forEach((row) => {
    row.addEventListener("click", () => {
      const id = row.dataset.flightId;
      const card = flightList.querySelector(`.flight-card[data-flight-id="${cssEscape(id)}"]`);
      if (card) {
        card.scrollIntoView({ behavior: "smooth", block: "center" });
        card.classList.add("flight-card--highlight");
        setTimeout(() => card.classList.remove("flight-card--highlight"), 900);
      }
    });
  });
}

function cssEscape(str) {
  return window.CSS && CSS.escape ? CSS.escape(str) : str.replace(/["\\]/g, "\\$&");
}

/** Selo circular com o número do voo na lista (mais legível que o glifo Unicode). */
function numBadge(n) {
  return `<span class="num-badge">${n}</span>`;
}

// ---------- Cards dos voos (accordion de 3 níveis) ----------
// Nível 1 (sempre visível): resumo do voo + botões "Copiar Inspeção" / "Copiar Acompanhamento".
// Nível 2 (clique no resumo): opções ▸ INSPEÇÃO / ▸ ACOMPANHAMENTO.
// Nível 3 (clique em uma opção): gaveta com os campos editáveis daquele chamado.
// Inspeção e Acompanhamento são independentes: abrir/fechar uma não afeta a outra,
// e cada voo mantém seu próprio estado (não afeta os outros voos).

function isExpanded(flightId) {
  return !!expandedFlights[flightId];
}

function isSectionOpen(flightId, kind) {
  return !!(openSections[flightId] && openSections[flightId][kind]);
}

/** Retorna (e cria, se necessário) os campos editáveis em memória para um voo/tipo,
 * preservando qualquer edição já feita pelo usuário entre re-renderizações. */
function getFieldValues(flight, kind) {
  if (!fieldValues[flight.id]) fieldValues[flight.id] = {};
  if (!fieldValues[flight.id][kind]) {
    fieldValues[flight.id][kind] =
      kind === "acompanhamento"
        ? buildAcompanhamentoFields(flight, currentSettings)
        : buildInspecaoFields(flight, currentSettings);
  }
  return fieldValues[flight.id][kind];
}

function guideClass(flightId, kind) {
  const g = guideTarget;
  return g && g.flightId === flightId && g.kind === kind && Date.now() < g.until ? "is-guide" : "";
}

function renderCards(flights) {
  flightList.innerHTML = "";

  if (!flights.length) {
    flightList.innerHTML = `<div class="empty-msg">Nenhum voo internacional de partida para a data selecionada.</div>`;
    listActions.hidden = true;
    return;
  }

  listActions.hidden = false;

  flights.forEach((flight, idx) => {
    const card = document.createElement("article");
    card.className = "flight-card";
    card.dataset.flightId = flight.id;

    const inspDone = flight.status.inspecao === "copiado";
    const acompDone = flight.status.acompanhamento === "copiado";
    const inspLabel = eventTimeLabel(flight.inspecaoTime, flight.inspecaoDate, flight.dataVoo);
    const acompLabel = eventTimeLabel(flight.acompanhamentoTime, flight.acompanhamentoDate, flight.dataVoo);

    const expanded = isExpanded(flight.id);
    const inspOpen = isSectionOpen(flight.id, "inspecao");
    const acompOpen = isSectionOpen(flight.id, "acompanhamento");

    card.classList.toggle("flight-card--done", inspDone && acompDone);
    card.classList.toggle("fc-past", flight.acompanhamentoTimestamp <= Date.now() && !(inspDone && acompDone));

    card.innerHTML = `
      <button type="button" class="flight-card__header" data-role="header-toggle" aria-expanded="${expanded}" title="Ver / editar campos">
        <b class="fc-name">${escapeHtml(flight.empresa)}${flight.numeroVoo ? " " + escapeHtml(flight.numeroVoo) : ""}</b>
        <span class="fc-dep">Partida <strong>${flight.horarioVoo}</strong></span>
        <span class="flight-card__chevron ${expanded ? "open" : ""}" aria-hidden="true">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><path d="m6 9 6 6 6-6" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </span>
      </button>
      <div class="actions fc-pills">
        <button type="button" class="option-btn fc-pill fc-po ${inspDone ? "done" : ""} ${guideClass(flight.id, "inspecao")}" data-action="paste" data-kind="inspecao" title="Inspeção ${escapeHtml(inspLabel)} — preenche o formulário aberto no ServiceAide">
          ${inspDone ? CHECK_ICON : PASTE_ICON}<span>${inspDone ? "Inspeção feita" : "Colar insp."}</span>
        </button>
        <button type="button" class="option-btn acomp fc-pill fc-pg ${acompDone ? "done" : ""} ${guideClass(flight.id, "acompanhamento")}" data-action="paste" data-kind="acompanhamento" title="Acompanhamento ${escapeHtml(acompLabel)} — preenche o formulário aberto no ServiceAide">
          ${acompDone ? CHECK_ICON : PASTE_ICON}<span>${acompDone ? "Acomp. feito" : "Colar acomp."}</span>
        </button>
        <button type="button" class="fc-pill fc-pn informe-btn" data-informe="1" title="Captura o chamado aberto no ServiceAide e copia o informe">Informe</button>
      </div>
      <div class="flight-card__times fc-times">
        <span class="time-chip time-chip--insp ${inspDone ? "is-done" : ""} ${flight.inspecaoTimestamp <= Date.now() ? "is-past" : ""}" data-ts="${flight.inspecaoTimestamp}"><i></i>Inspeção <strong>${inspLabel}</strong></span>
        <span class="time-chip time-chip--acomp ${acompDone ? "is-done" : ""} ${flight.acompanhamentoTimestamp <= Date.now() ? "is-past" : ""}" data-ts="${flight.acompanhamentoTimestamp}"><i></i>Acomp. <strong>${acompLabel}</strong></span>
      </div>
      <div class="flight-sections" ${expanded ? "" : "hidden"}>
        <button type="button" class="section-toggle" data-section="inspecao" aria-expanded="${inspOpen}">
          <span class="arrow">${inspOpen ? "▾" : "▸"}</span>
          <span>INSPEÇÃO${inspDone ? " ✓" : ""}</span>
        </button>
        ${buildDrawerHtml("inspecao", inspOpen)}
        <button type="button" class="section-toggle acomp" data-section="acompanhamento" aria-expanded="${acompOpen}">
          <span class="arrow">${acompOpen ? "▾" : "▸"}</span>
          <span>ACOMPANHAMENTO${acompDone ? " ✓" : ""}</span>
        </button>
        ${buildDrawerHtml("acompanhamento", acompOpen)}
      </div>
      <div class="flight-card__footer" ${expanded ? "" : "hidden"}>
        <button type="button" class="btn-link" data-role="header-toggle">Ocultar campos</button>
      </div>
    `;

    fillDrawer(card, "inspecao", getFieldValues(flight, "inspecao"));
    fillDrawer(card, "acompanhamento", getFieldValues(flight, "acompanhamento"));

    flightList.appendChild(card);
  });

  // Nível 1 → 2: clicar no resumo (título/horário/qualquer parte) expande ou
  // recolhe as opções INSPEÇÃO/ACOMPANHAMENTO. Afeta somente este voo.
  flightList.querySelectorAll('[data-role="header-toggle"]').forEach((header) => {
    header.addEventListener("click", () => {
      const flightId = header.closest(".flight-card").dataset.flightId;
      expandedFlights[flightId] = !expandedFlights[flightId];
      renderCards(filteredFlights);
    });
  });

  // Botões "Colar Inspeção" / "Colar Acompanhamento": preenchem direto o
  // formulário aberto no ServiceAide (usa os valores editados, se houver).
  flightList.querySelectorAll('[data-action="paste"]').forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const flightId = btn.closest(".flight-card").dataset.flightId;
      if (btn.classList.contains("is-guide")) clearGuide();
      onPasteChamado(flightId, btn.dataset.kind, btn);
    });
  });

  // Nível 2 → 3: clicar em INSPEÇÃO ou ACOMPANHAMENTO abre/fecha somente
  // aquela gaveta — a outra permanece como estava.
  flightList.querySelectorAll(".section-toggle").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const flightId = btn.closest(".flight-card").dataset.flightId;
      const kind = btn.dataset.section;
      openSections[flightId] = openSections[flightId] || {};
      openSections[flightId][kind] = !openSections[flightId][kind];
      renderCards(filteredFlights);
    });
  });

  // Botão "Fechar Inspeção" / "Fechar Acompanhamento" dentro de cada gaveta.
  flightList.querySelectorAll(".drawer-close-btn").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const flightId = btn.closest(".flight-card").dataset.flightId;
      const kind = btn.dataset.kind;
      openSections[flightId] = openSections[flightId] || {};
      openSections[flightId][kind] = false;
      renderCards(filteredFlights);
    });
  });

  flightList.querySelectorAll(".drawer-copy-all-btn").forEach((btn) => {
    btn.addEventListener("click", () => onCopyFullChamado(btn));
  });
  flightList.querySelectorAll(".field-copy-btn").forEach((btn) => {
    btn.addEventListener("click", () => onCopyField(btn));
  });
  flightList.querySelectorAll(".informe-btn").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      onCopyInforme(btn);
    });
  });

  // Guarda cada edição do usuário em memória imediatamente, para que a gaveta
  // sobreviva a re-renderizações (trocar de aba, copiar, abrir outro voo...).
  flightList.querySelectorAll(".drawer").forEach((drawer) => {
    const flightId = drawer.closest(".flight-card").dataset.flightId;
    const kind = drawer.dataset.kind;
    drawer.querySelectorAll(".fld").forEach((el) => {
      el.addEventListener("input", () => {
        const key = [...el.classList].find((c) => c.startsWith("fld-"))?.slice(4);
        if (!key) return;
        if (!fieldValues[flightId]) fieldValues[flightId] = {};
        if (!fieldValues[flightId][kind]) fieldValues[flightId][kind] = {};
        fieldValues[flightId][kind][key] = el.value;
      });
    });
  });
}

function buildDrawerHtml(kind, isOpen) {
  const order = fieldOrderFor(kind);
  const closeLabel = kind === "acompanhamento" ? "Fechar Acompanhamento" : "Fechar Inspeção";

  const rowsHtml = order
    .map((key, idx) => {
      const isLast = idx === order.length - 1;
      const label = FIELD_LABELS[key] || key;
      const isTextarea = key === "descricao";
      const control = isTextarea
        ? `<textarea class="fld fld-${key}" rows="5"></textarea>`
        : `<input type="text" class="fld fld-${key}" autocomplete="off" />`;
      return `
        <div class="field-row">
          <label>${escapeHtml(label)}</label>
          <div class="field-control-wrap">
            ${control}
            <div class="field-btn-col">
              <button type="button" class="icon-btn field-copy-btn" data-field="${key}" title="Copiar campo" aria-label="Copiar ${escapeHtml(label)}">Copiar</button>
            </div>
          </div>
        </div>`;
    })
    .join("");

  return `
    <div class="drawer" data-kind="${kind}" ${isOpen ? "" : "hidden"}>
      ${rowsHtml}
      <div class="drawer-actions">
        <button type="button" class="btn btn--primary drawer-paste-btn" data-action="paste" data-kind="${kind}">${PASTE_ICON}Colar no ServiceAide</button>
        <button type="button" class="btn btn--ghost drawer-copy-all-btn">Copiar texto</button>
      </div>
      <button type="button" class="btn-link drawer-close-btn" data-kind="${kind}">${closeLabel}</button>
    </div>
  `;
}

function fillDrawer(card, kind, fields) {
  const drawer = card.querySelector(`.drawer[data-kind="${kind}"]`);
  Object.keys(fields).forEach((key) => {
    const el = drawer.querySelector(`.fld-${key}`);
    if (el) el.value = fields[key];
  });
}

function readDrawerFields(drawer, kind) {
  const order = fieldOrderFor(kind);
  const fields = {};
  order.forEach((key) => {
    const el = drawer.querySelector(`.fld-${key}`);
    fields[key] = el ? el.value : "";
  });
  return fields;
}

// ---------- Colar no ServiceAide ----------

const SA_FIELD_NAMES = {
  nome: "Solicitante",
  email: "E-mail",
  telefone: "Telefone",
  departamento: "Departamento",
  descricao: "Descrição",
  detalhes: "Detalhes",
  matricula: "Matrícula",
  localizacao: "Localização",
  equipamento: "Identificação do equipamento",
};

const PASTE_ERRORS = {
  "no-tab": "ServiceAide não está aberto. Abra o formulário \"Acompanhamento técnico de voo\" e tente de novo.",
  "no-form": "Formulário não encontrado na aba do ServiceAide. Abra \"Acompanhamento técnico de voo\".",
  inject: "Sem acesso ao ServiceAide. Clique em Permitir acesso no Início e recarregue a página.",
};

let pasting = false;

async function onPasteChamado(flightId, kind, btn) {
  if (pasting) return;
  const flight = filteredFlights.find((f) => f.id === flightId);
  if (!flight) return;

  // Valores gerados + qualquer edição feita na gaveta (sincronizada a cada digitação)
  const fields = getFieldValues(flight, kind);
  const saFields = buildServiceAideFields(fields, flight, currentSettings);

  pasting = true;
  const label = btn.querySelector("span");
  const oldLabel = label ? label.textContent : btn.textContent;
  btn.disabled = true;
  btn.classList.add("is-loading");
  if (label) label.textContent = "Colando…";

  let res;
  try {
    res = await pasteToServiceAide(saFields);
  } catch (err) {
    console.error(err);
    res = { ok: false, error: "inject" };
  }
  pasting = false;

  if (!res.ok) {
    btn.disabled = false;
    btn.classList.remove("is-loading");
    if (label) label.textContent = oldLabel;
    const msg = PASTE_ERRORS[res.error] || "Não foi possível colar no ServiceAide.";
    setStatus(msg, true);
    showCopyToast(msg, true);
    return;
  }

  await markCopied(flightId, kind);
  renderCards(filteredFlights);
  renderTable(filteredFlights);

  const parts = [`${res.filled.length} de ${saFields.length} campos colados.`];
  if (res.missing.length) parts.push(`Não encontrados: ${res.missing.map((k) => SA_FIELD_NAMES[k] || k).join(", ")}.`);
  const noteMsgs = {
    "nome:sem-modal": "Nome não encontrado na busca. Selecione manualmente.",
    "nome:sem-email": "Confira o Nome: o e-mail não foi preenchido.",
    "departamento:sem-opcao": "Departamento não encontrado na lista. Selecione manualmente.",
    "departamento:nao-confirmado": "Confira o Departamento: a escolha pode não ter sido aceita.",
    "localizacao:sem-lista": "Confira a Localização na lista.",
  };
  res.notes.forEach((n) => noteMsgs[n] && parts.push(noteMsgs[n]));
  const partial = res.missing.length > 0 || res.notes.length > 0;
  setStatus(parts.join(" "), partial);
  showCopyToast(partial ? parts.join(" ") : "Colado no ServiceAide ✓", partial);
}

// ---------- Copiar informe (captura do ServiceAide, lógica da arion-plugin) ----------
async function onCopyInforme(btn) {
  const now = new Date();
  btn.disabled = true;
  btn.classList.add("is-loading");
  let res;
  try {
    res = await captureFromServiceAide();
  } catch (err) {
    console.error(err);
    res = { ok: false, error: "inject" };
  }
  btn.disabled = false;
  btn.classList.remove("is-loading");

  if (!res.ok) {
    const msg =
      res.error === "no-tab"
        ? "Abra o chamado no ServiceAide para copiar o informe."
        : res.error === "inject"
        ? "Sem acesso ao ServiceAide. Clique em Permitir acesso no Início e recarregue a página."
        : "Chamado não encontrado na aba do ServiceAide.";
    setStatus(msg, true);
    showCopyToast(msg, true);
    return;
  }

  const data = { ...res.data };
  if (!cleanChamado(data.chamado)) {
    const typed = window.prompt("Número do chamado não encontrado na tela. Digite:", "");
    if (typed === null) return;
    data.chamado = typed.trim();
  }

  const text = buildInformeServiceAide(data, currentSettings, now);
  const copied = await copyText(text);
  if (!copied.ok) {
    setStatus("Não foi possível copiar para a área de transferência.", true);
    return;
  }
  const faltando = ["descricao", "nome", "telefone", "email", "detalhes"].filter((k) => !data[k]);
  const aviso = faltando.length ? ` Campos vazios: ${faltando.map((k) => SA_FIELD_NAMES[k] || k).join(", ")}.` : "";
  setStatus(`Informe ${cleanChamado(data.chamado)} copiado.${aviso}`, faltando.length > 0);
  showCopyToast("Informe copiado ✓");
}

// ---------- Cópias ----------
async function markCopied(flightId, kind) {
  flightStatusMap = await Storage.setFlightStatus(flightId, kind);
  const flight = filteredFlights.find((f) => f.id === flightId);
  if (flight) flight.status[kind] = "copiado";
}

async function onCopyField(btn) {
  const drawer = btn.closest(".drawer");
  const kind = drawer.dataset.kind;
  const key = btn.dataset.field;
  const fields = readDrawerFields(drawer, kind);
  const text = copyFieldValue(fields, key);
  const res = await copyText(text);
  setStatus(res.ok ? "Campo copiado." : "Não foi possível copiar para a área de transferência.", !res.ok);
  if (res.ok) showCopyToast();
}

async function onCopyFieldBelow(btn) {
  const drawer = btn.closest(".drawer");
  const kind = drawer.dataset.kind;
  const key = btn.dataset.field;
  const fields = readDrawerFields(drawer, kind);
  const text = copyFieldAndBelow(fields, kind, key);
  const res = await copyText(text);
  setStatus(res.ok ? "Campos copiados." : "Não foi possível copiar para a área de transferência.", !res.ok);
  if (res.ok) showCopyToast();
}

async function onCopyFullChamado(btn) {
  const drawer = btn.closest(".drawer");
  const card = btn.closest(".flight-card");
  const flightId = card.dataset.flightId;
  const kind = drawer.dataset.kind;
  const fields = readDrawerFields(drawer, kind);
  const text = composeChamadoText(fields, kind);

  await markCopied(flightId, kind);
  renderCards(filteredFlights); // atualiza selo "✓" — a gaveta fecha nesse redesenho
  renderTable(filteredFlights);

  const res = await copyText(text);
  setStatus(res.ok ? "Chamado copiado." : "Não foi possível copiar para a área de transferência.", !res.ok);
  if (res.ok) showCopyToast();
}

async function onCopyFlightBundle(btn) {
  const card = btn.closest(".flight-card");
  const flightId = card.dataset.flightId;
  const flight = filteredFlights.find((f) => f.id === flightId);
  if (!flight) return;

  const text = buildFlightBundle(flight, currentSettings);
  await markCopied(flightId, "inspecao");
  await markCopied(flightId, "acompanhamento");
  renderCards(filteredFlights);
  renderTable(filteredFlights);

  const res = await copyText(text);
  setStatus(res.ok ? "Informe e chamados do voo copiados." : "Não foi possível copiar.", !res.ok);
  if (res.ok) showCopyToast();
}

copyAllBtn.addEventListener("click", async () => {
  if (!filteredFlights.length) return;
  const text = buildAllFlightsText(filteredFlights, currentSettings);

  flightStatusMap = await Storage.setAllFlightStatus(filteredFlights.map((f) => f.id));
  applyStatus(filteredFlights);
  renderCards(filteredFlights);
  renderTable(filteredFlights);

  const res = await copyText(text);
  setStatus(res.ok ? "Todos os chamados foram copiados." : "Não foi possível copiar para a área de transferência.", !res.ok);
  if (res.ok) showCopyToast();
});

// ---------- Utilitário ----------
function escapeHtml(str) {
  return String(str ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}
