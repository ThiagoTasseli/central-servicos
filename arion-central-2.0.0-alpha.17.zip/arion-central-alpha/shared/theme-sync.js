/* theme-sync.js — tema único da Central (escuro/claro).
 * Carregado no <head> de cada página. Lê "arion:tema" e acompanha mudanças:
 * trocar o tema no trilho da Central atualiza todas as ferramentas na hora.
 */
(function () {
  var KEY = "arion:tema";
  var root = document.documentElement;
  var TEMAS = ["light", "dark", "areia", "noite", "contraste"];
  function apply(t) { root.setAttribute("data-theme", TEMAS.indexOf(t) >= 0 ? t : "light"); }
  apply("light");
  // Dentro da Central (iframe): reserva espaço para a barra de vidro.
  try { if (window.top !== window) root.setAttribute("data-hub", "1"); } catch (_) { root.setAttribute("data-hub", "1"); }
  try {
    chrome.storage.local.get(KEY, function (v) { apply(v && v[KEY]); });
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area === "local" && changes[KEY]) apply(changes[KEY].newValue);
    });
  } catch (_) {}
})();
