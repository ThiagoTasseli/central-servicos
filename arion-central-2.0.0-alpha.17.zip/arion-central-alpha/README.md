# ARION Central 2.0 — Alpha (2.0.0-alpha.17)

> **Versão experimental.** Visual minimalista. Mesmas funções da 1.3.3.
> Instala ao lado da 1.3.3 (é outra extensão). Relatar: Início → ⋯ → Relatar problema.

## O que testar nesta versão

1. Barra rápida de vidro (só ícones): Início | Copiar · Abrir · Voos | Categorizar.
2. Menu **⋯** no Início: tema, lateral/bandeja, abrir em aba, ajuda, relatar, atualização, limpar.
3. Início: a ferramenta da aba aberta aparece no topo como **Sugerida**.
4. Tema claro por padrão. Ação principal em preto.
5. Todas as funções da 1.3.3 continuam iguais.

Uma extensão só, com quatro ferramentas. Navegação por ícones no trilho lateral.

| Ícone | Ferramenta | Objetivo | Onde usar |
|---|---|---|---|
| 📖 Guia | Início | Objetivo e passo a passo de cada ferramenta | — |
| 💬 Copiar | Copiar Chamado | Captura o chamado e gera a máscara (editável) | ServiceAide |
| 🖧 Categorizar | Categorização (Atacado e Suporte TI) | Categoriza e encaminha para NOC - ATACADO, ENG - SISTEMAS, NOC - CANCELAMENTOS NGO ou NOC - ACESSOS E CADASTROS | OTRS |
| 📋 Abrir | Abertura de Chamados | Preenche o formulário e gera o texto do chamado | ServiceAide |
| ✈ Voos | Inspeção de Voos | Planilha de voos, alarmes CUPPS, chamados e informes | Planilha + ServiceAide |

## Instalar (Chrome / Edge / Brave)

1. Desinstale as extensões antigas (Máscara, NOC Atacado, Preenchimento, Central de Voos).
2. Abra `chrome://extensions` e ligue o **Modo do desenvolvedor**.
3. **Carregar sem compactação** → selecione a pasta `arion-central`.
4. Fixe o ícone ARION. Clique nele (ou `Alt+Shift+A`) para abrir o painel lateral.

Firefox 128+: `about:debugging` → **Carregar extensão temporária** → `manifest.json`. Abre na barra lateral.

> A extensão nova tem outro ID. Configurações das antigas não migram:
> refaça nome do atendente, grupos e reimporte a planilha de voos.

## Como navegar

- **Trilho de ícones** à esquerda. Clique para trocar de ferramenta.
- **Botão no topo do trilho** (ou `Alt+0`): recolhe a barra para uma faixa fina e expande de novo. Fica salvo.
- **Ponto colorido** no ícone: site da aba atual combina com a ferramenta.
- **Ponto laranja pulsando** em Voos: alarme disparado.
- **Bandeja / Fixar** no rodapé do trilho: alterna o modo de abrir.
  - *Lateral* (padrão): painel fixo ao lado da página, não fecha ao trocar de foco.
  - *Bandeja*: janelinha que abre no ícone ARION e fecha ao clicar fora.
  - A escolha fica salva e vale para os próximos cliques no ícone.
- **?** no rodapé do trilho: passo a passo da ferramenta aberta.
- **↗** abre a Central em uma aba inteira.
- `Alt+1` a `Alt+5`: Início, Copiar, Categorizar, Abrir, Voos.
- Trocar de ícone não perde o que foi preenchido. A última ferramenta usada reabre sozinha.

## Estrutura

```
arion-central/
├── manifest.json        ← único; soma permissões e sites das 4 extensões
├── background.js        ← único; painel lateral + alarmes/notificações dos voos
├── offscreen.html/.js   ← som do alarme (Chrome)
├── sounds/            (sons dos alarmes + sons.js)
├── icons/               ← ícone ARION (marca oficial)
├── shared/              ← design system único
│   ├── arion-ds.css     ← tokens de cor/tema, fontes, cabeçalho padrão
│   ├── theme-sync.js    ← tema claro/escuro em todas as páginas
│   ├── fonts/           ← DM Sans e Syne (locais, licença OFL)
│   └── arion-logo-white.png
├── hub/                 ← casca: trilho de ícones, guia, ajuda, aviso de alarme
│   ├── index.html · hub.css · hub.js
│   └── tools.js         ← cadastro das ferramentas (nome, cor, ícone, guia)
└── apps/
    ├── mascara/         ← antiga "Grupo Arion - Máscara de Chamado"
    ├── noc-atacado/     ← antiga "ARION · NOC Atacado"
    ├── preenchimento/   ← antiga "ARION · Preenchimento de Chamados"
    └── voos/            ← antiga "ARION · Central de Voos"
```

Cada ferramenta roda na própria página (iframe da extensão), com o código original.
Ajustes feitos na junção:

- Caminhos dos scripts injetados nas páginas apontam para `apps/<ferramenta>/…`.
- Central de Voos usa `window.__arionSAVoos` para não colidir com o Preenchimento no ServiceAide.
- Máscara: largura fluida e sem o botão "fixar na lateral" (já está no painel).
- Backgrounds unidos em um só.

## Padrão visual

- Cabeçalho grafite com logo ARION branco, título curto e faixa laranja/branco/verde.
- Laranja `#FF8440` = ação principal. Verde `#00BF9A` = foco, sucesso, ação secundária.
- Campos e botões com o mesmo tamanho, borda e raio em todas as ferramentas.
- Títulos em Syne, texto em DM Sans.
- Cores ficam só em `shared/arion-ds.css` (tokens `--ds-*`). Cada ferramenta mapeia suas variáveis no próprio CSS/skin.

## Segurança e privacidade

- Texto vindo da planilha e das páginas é escapado antes de ir para a tela.
- SheetJS 0.20.3 (corrige falhas da 0.18.5). Obtido do espelho npm `@e965/xlsx`;
  antes de produção, troque `apps/voos/libs/xlsx.full.min.js` pelo arquivo oficial de cdn.sheetjs.com.
- Sem chamadas a Google Fonts. Nenhum dado sai do navegador.
- Chamados do NOC e formulário do Preenchimento são apagados após 7 dias (limpeza diária).

## Aviso de versão nova (opcional)

Coloque um `versao.json` num servidor da intranet e informe o endereço no Guia:

```json
{ "versao": "1.3.3", "download": "\\\\servidor\\arion\\arion-central-v1.3.3.zip", "notas": "Correções do teste." }
```

## Adicionar uma ferramenta nova

1. Copie a pasta para `apps/<id>/`.
2. Adicione um item em `hub/tools.js` (nome, cor, ícone SVG, objetivo, passos, sites).
3. Some permissões e `host_permissions` no `manifest.json`.
4. Se injetar scripts, use caminho a partir da raiz: `apps/<id>/arquivo.js`.
