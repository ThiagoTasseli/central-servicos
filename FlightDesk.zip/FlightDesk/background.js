// importScripts só existe dentro de um service worker (Chrome/Edge). No
// Firefox, os mesmos módulos já são carregados via "background.scripts" no
// manifest, então este bloco é ignorado lá.
if (typeof importScripts === "function") {
  importScripts(
    "modules/formatters.js",
    "modules/templates.js",
    "modules/storage.js",
    "modules/spreadsheet.js", // só as partes que não dependem de XLSX/File são usadas aqui (filterFlights)
    "modules/alarms.js"
  );
}

const { todayISO } = self.Fmt;
const { filterFlights } = self.Spreadsheet;
const { computeAlarmEntries, futureAlarmEntries, parseAlarmName, ALARM_PREFIX } = self.Alarms;
const Storage = self.Storage;

// Clique no ícone da extensão abre o painel fixo (side panel) em vez de um
// popup pequeno — o painel não fecha sozinho ao perder foco (ex.: durante
// um arraste de arquivo ou ao trocar de janela pra colar um texto copiado).
// Side Panel é uma API exclusiva do Chrome/Edge; no Firefox (e em outros
// navegadores sem suporte) a extensão cai no popup normal já definido em
// "action.default_popup" no manifest.
if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
  chrome.action.setPopup({ popup: "" }).catch(() => {});
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch((err) => {
    console.error("Falha ao configurar o side panel:", err);
  });
}

// Firefox: não tem side panel e o popup FECHA sozinho ao perder o foco
// (ao colar no ServiceAide, escolher a planilha, trocar de janela...).
// Lá, o ícone da extensão abre/fecha a BARRA LATERAL, que fica aberta.
const ffSidebar =
  (typeof browser !== "undefined" && browser.sidebarAction) || chrome.sidebarAction || null;
if (!chrome.sidePanel && ffSidebar) {
  chrome.action.setPopup({ popup: "" });
  chrome.action.onClicked.addListener(() => {
    // toggle() precisa ser chamado direto no clique (gesto do usuário)
    ffSidebar.toggle();
  });
}

chrome.runtime.onInstalled.addListener(() => rescheduleFromStorage());
chrome.runtime.onStartup.addListener(() => rescheduleFromStorage());

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === "RESCHEDULE_ALARMS") {
    rescheduleFromStorage().then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message.type === "CLEAR_ALARMS") {
    clearAllAlarms().then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message.type === "SNOOZE_ALARM") {
    snoozeAlarm(message.alarmId).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message.type === "SET_MUTE") {
    Storage.setMuteUntil(message.muteUntil).then(async () => {
      if (Storage.isMutedValue(Number(message.muteUntil))) stopSound();
      sendResponse({ ok: true });
    });
    return true;
  }
  if (message.type === "STOP_SOUND") {
    stopSound();
    sendResponse({ ok: true });
    return false;
  }
  if (message.type === "TEST_SOUND") {
    playSound().then(() => {
      setTimeout(stopSound, 3000);
      sendResponse({ ok: true });
    });
    return true;
  }
  if (message.type === "DISMISS_ALARM") {
    dismissAlarm(message.alarmId).then(() => sendResponse({ ok: true }));
    return true;
  }
});

/**
 * Recalcula os voos filtrados (data selecionada) a partir das linhas cruas
 * salvas no storage e reagenda os alarmes de acordo com os minutos de
 * antecedência configurados na aba Alarme.
 *
 * Chamado ao instalar/iniciar o navegador, e sempre que o popup avisa que
 * a planilha, a data selecionada ou os minutos de alerta mudaram.
 */
async function rescheduleFromStorage() {
  await Storage.migrateLegacyRawRows();
  const selectedDate = await Storage.getSelectedDate();
  const [dayRows, alarmSettings, overrides] = await Promise.all([
    Storage.getFlightsForDate(selectedDate),
    Storage.getAlarmSettings(),
    Storage.getAlarmOverrides(),
  ]);

  const flights = filterFlights(dayRows, selectedDate);
  await scheduleAlarms(flights, alarmSettings, overrides);
}

async function clearAllAlarms() {
  const alarms = await chrome.alarms.getAll();
  await Promise.all(
    alarms.filter((a) => a.name.startsWith(ALARM_PREFIX)).map((a) => chrome.alarms.clear(a.name))
  );
}

/**
 * Cancela e recria TODOS os alarmes de voo a partir do zero — mais simples
 * e seguro do que tentar reconciliar incrementalmente, e evita alarmes
 * duplicados quando a planilha, a data ou os minutos de alerta mudam.
 * Só agenda (som + notificação) para horários de alarme ainda no futuro.
 */
async function scheduleAlarms(flights, alarmSettings, overrides) {
  await clearAllAlarms();
  const entries = computeAlarmEntries(flights, alarmSettings, overrides);
  const future = futureAlarmEntries(entries);
  for (const entry of future) {
    chrome.alarms.create(entry.id, { when: entry.alarmeTimestamp });
  }
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  const parsed = parseAlarmName(alarm.name);
  if (!parsed) return;
  const { flightId, kind } = parsed;

  const selectedDate = await Storage.getSelectedDate();
  const dayRows = await Storage.getFlightsForDate(selectedDate);
  const flights = filterFlights(dayRows, selectedDate);
  const flight = flights.find((f) => f.id === flightId);
  if (!flight) return;

  const isInspecao = kind === "inspecao";
  const horarioEvento = isInspecao ? flight.inspecaoTime : flight.acompanhamentoTime;
  const companhia = String(flight.empresa || "").toUpperCase();
  const numeroVoo = flight.numeroVoo || "";

  const title = isInspecao
    ? `ALERTA: INSPEÇÃO - Voo ${companhia} ${numeroVoo}`.trim()
    : `ALERTA: ACOMPANHAMENTO - Voo ${companhia} ${numeroVoo}`.trim();

  const message =
    `O horário do evento está se aproximando.\n\n` +
    `Partida: ${flight.horarioVoo}\n` +
    `Evento: ${horarioEvento}`;

  const muted = await Storage.isMuted();

  // Botões / requireInteraction / silent só existem no Chrome/Edge — o
  // Firefox recusa a notificação inteira se receber essas opções.
  const isChromium = !!chrome.offscreen;
  const notifOptions = { type: "basic", iconUrl: "icons/icon128.png", title, message };
  if (isChromium) {
    Object.assign(notifOptions, {
      priority: 2,
      requireInteraction: true,
      buttons: [{ title: "Adiar 5 min" }, { title: "Desativar" }],
      ...(muted ? { silent: true } : {}),
    });
  }
  try {
    await chrome.notifications.create(alarm.name, notifOptions);
  } catch (err) {
    console.error("Falha ao criar notificação:", err);
  }

  // Silenciado: só a notificação visual (e o card no painel), sem som.
  if (!muted) playSound();

  // Além da notificação do SO, avisa o painel (side panel) — se estiver
  // aberto — pra mostrar ali também um card com os mesmos botões. Se não
  // houver painel aberto pra receber, sendMessage rejeita e é ignorado.
  chrome.runtime.sendMessage({ type: "ALARM_FIRED", alarmId: alarm.name, title, message, muted }).catch(() => {});
});

// O som toca em loop (ver offscreen.html/offscreen.js) até o usuário adiar
// ou desativar o alarme — pelos botões da notificação OU pelo card no
// painel — nunca para sozinho.
const SNOOZE_MS = 5 * 60 * 1000;

async function snoozeAlarm(alarmId) {
  if (!alarmId) return;
  stopSound();
  chrome.notifications.clear(alarmId);
  // Dispara de novo em alguns minutos, sem alterar o horário salvo do alarme.
  chrome.alarms.create(alarmId, { when: Date.now() + SNOOZE_MS });
}

async function dismissAlarm(alarmId) {
  if (!alarmId) return;
  stopSound();
  chrome.notifications.clear(alarmId);
  // Mesmo efeito de desligar o alarme na aba Despertar.
  await Storage.setAlarmOverride(alarmId, { enabled: false });
}

chrome.notifications.onButtonClicked?.addListener(async (notificationId, buttonIndex) => {
  const parsed = parseAlarmName(notificationId);
  if (!parsed) return;

  if (buttonIndex === 0) {
    await snoozeAlarm(notificationId);
  } else if (buttonIndex === 1) {
    await dismissAlarm(notificationId);
  }
});

// ---------- Offscreen document para som ----------
// chrome.offscreen só existe no Chrome/Edge (service worker não tem acesso
// a <audio>). No Firefox, o background roda como event page com DOM
// completo, então tocamos o som direto por aqui, sem documento offscreen.
let creatingOffscreen;
let firefoxAudio;

async function ensureOffscreenDocument() {
  const existing = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
  });
  if (existing.length > 0) return;

  if (creatingOffscreen) {
    await creatingOffscreen;
    return;
  }

  creatingOffscreen = chrome.offscreen.createDocument({
    url: "offscreen.html",
    reasons: ["AUDIO_PLAYBACK"],
    justification: "Tocar sinal sonoro de alerta de voo.",
  });
  await creatingOffscreen;
  creatingOffscreen = null;
}

async function playSound() {
  try {
    if (chrome.offscreen) {
      await ensureOffscreenDocument();
      // pequena margem de segurança: garante que o listener do offscreen já
      // está registrado antes de mandar a mensagem.
      chrome.runtime.sendMessage({ type: "PLAY_ALERT_SOUND" }).catch(() => {});
    } else {
      if (!firefoxAudio) firefoxAudio = new Audio("sounds/alert.wav");
      firefoxAudio.loop = true;
      firefoxAudio.currentTime = 0;
      firefoxAudio.play().catch((err) => console.error("Erro ao tocar som:", err));
    }
  } catch (err) {
    console.error("Não foi possível tocar o som de alerta:", err);
  }
}

function stopSound() {
  if (chrome.offscreen) {
    chrome.runtime.sendMessage({ type: "STOP_ALERT_SOUND" }).catch(() => {});
  } else if (firefoxAudio) {
    firefoxAudio.pause();
    firefoxAudio.currentTime = 0;
  }
}
