/* modules/autofill.js
 * Ponte entre o painel e a página do ServiceAide (csm3.serviceaide.com).
 *  - pasteToServiceAide(fields): preenche o formulário
 *  - readFromServiceAide(fields): lê os dados do chamado (para o informe)
 * A lógica que roda na página fica em modules/sa-page.js.
 */
(function () {

const SERVICEAIDE_URLS = ["https://*.serviceaide.com/*"];

/** Aba do ServiceAide: a ativa da janela atual, senão a usada mais recentemente. */
async function findServiceAideTab() {
  const tabs = await chrome.tabs.query({ url: SERVICEAIDE_URLS });
  if (!tabs.length) return null;
  const active = tabs.find((t) => t.active);
  if (active) return active;
  return tabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0];
}

/** Injeta sa-page.js em todos os frames e roda `fn(arg)` em cada um. */
async function runInPage(tabId, fnName, arg) {
  await chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    files: ["modules/sa-page.js"],
  });
  return chrome.scripting.executeScript({
    target: { tabId, allFrames: true },
    func: (name, a) => (window.__arionSA ? window.__arionSA[name](a) : null),
    args: [fnName, arg],
  });
}

async function focusTab(tab) {
  try {
    await chrome.tabs.update(tab.id, { active: true });
    if (tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true });
  } catch (_) {}
}

/** Preenche o formulário. Retorna { ok, filled, missing, notes, error }. */
async function pasteToServiceAide(fields) {
  const tab = await findServiceAideTab();
  if (!tab) return { ok: false, error: "no-tab" };

  // Traz a aba para frente antes: janelas de busca (modal) precisam da página ativa
  await focusTab(tab);

  let injections;
  try {
    injections = await runInPage(tab.id, "fill", { fields });
  } catch (err) {
    console.error("Falha ao injetar no ServiceAide:", err);
    return { ok: false, error: "inject", detail: String(err && err.message) };
  }

  const best = (injections || [])
    .map((i) => i.result)
    .filter(Boolean)
    .sort((a, b) => b.filled.length - a.filled.length)[0];

  if (!best || !best.filled.length) return { ok: false, error: "no-form", tabId: tab.id };
  return { ok: true, filled: best.filled, missing: best.missing, notes: best.notes, tabId: tab.id };
}

/** Lê os campos do chamado aberto. Retorna { ok, values, error }. */
async function readFromServiceAide(fields) {
  const tab = await findServiceAideTab();
  if (!tab) return { ok: false, error: "no-tab" };

  let injections;
  try {
    injections = await runInPage(tab.id, "read", { fields });
  } catch (err) {
    console.error("Falha ao ler o ServiceAide:", err);
    return { ok: false, error: "inject" };
  }

  const results = (injections || []).map((i) => i.result).filter(Boolean);
  const best = results.sort((a, b) => b.found - a.found)[0];
  if (!best || !best.found) return { ok: false, error: "no-form" };

  // Número do chamado pode estar em outro frame (cabeçalho da tela)
  if (!best.values.chamado) {
    const other = results.find((r) => r.values.chamado);
    if (other) best.values.chamado = other.values.chamado;
  }
  return { ok: true, values: best.values };
}

/** Captura os dados do chamado aberto (lógica da arion-plugin). Retorna { ok, data, error }. */
async function captureFromServiceAide() {
  const tab = await findServiceAideTab();
  if (!tab) return { ok: false, error: "no-tab" };
  let injections;
  try {
    injections = await runInPage(tab.id, "capture", null);
  } catch (err) {
    console.error("Falha ao capturar no ServiceAide:", err);
    return { ok: false, error: "inject" };
  }
  const results = (injections || []).map((i) => i.result).filter(Boolean);
  if (!results.length) return { ok: false, error: "no-form" };
  // Junta frames: o melhor frame primeiro, completando campos vazios com os demais
  results.sort((a, b) => b.found - a.found);
  const data = { ...results[0].data };
  for (const r of results.slice(1)) {
    for (const [k, v] of Object.entries(r.data)) if (!data[k] && v) data[k] = v;
  }
  if (!results[0].found) return { ok: false, error: "no-form" };
  return { ok: true, data };
}

if (typeof self !== "undefined") {
  self.Autofill = { SERVICEAIDE_URLS, findServiceAideTab, pasteToServiceAide, readFromServiceAide, captureFromServiceAide };
}

})();
