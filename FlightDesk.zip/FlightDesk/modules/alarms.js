/* modules/alarms.js
 * Cálculo puro dos alarmes de Inspeção/Acompanhamento a partir dos voos e
 * dos minutos de antecedência configurados na aba "Alarme".
 * As chamadas reais a chrome.alarms ficam em background.js — este módulo
 * só decide QUANDO cada alarme deveria disparar, para que popup (lista de
 * próximos alertas) e background (agendamento) usem exatamente a mesma
 * lógica.
 */
(function () {

const { formatHHMM, formatISODate, dateFromISOAndHHMM } = self.Fmt;

const ALARM_PREFIX = "flight-alert::";

function alarmName(flightId, kind) {
  return `${ALARM_PREFIX}${flightId}::${kind}`;
}

function parseAlarmName(name) {
  if (!name.startsWith(ALARM_PREFIX)) return null;
  const rest = name.slice(ALARM_PREFIX.length);
  const lastSep = rest.lastIndexOf("::");
  if (lastSep === -1) return null;
  return { flightId: rest.slice(0, lastSep), kind: rest.slice(lastSep + 2) };
}

/**
 * Gera a lista de alarmes possíveis (Inspeção e Acompanhamento) para os
 * voos informados, usando os minutos de antecedência configurados como
 * padrão — e aplicando, por cima, qualquer ajuste individual feito pelo
 * usuário na aba Alarme (horário próprio e/ou ativado/desativado), no
 * estilo de um alarme de despertador de celular.
 * Cada entrada traz o horário do evento e o horário em que o alerta deve
 * disparar (evento - minutos, ou o horário customizado).
 */
function computeAlarmEntries(flights, alarmSettings, overrides = {}) {
  const minutosInspecao = Number(alarmSettings?.minutosInspecao ?? 15);
  const minutosAcompanhamento = Number(alarmSettings?.minutosAcompanhamento ?? 10);
  const entries = [];

  for (const flight of flights) {
    entries.push(
      buildEntry(flight, "inspecao", flight.inspecaoTimestamp, flight.inspecaoTime, minutosInspecao, overrides)
    );
    entries.push(
      buildEntry(
        flight,
        "acompanhamento",
        flight.acompanhamentoTimestamp,
        flight.acompanhamentoTime,
        minutosAcompanhamento,
        overrides
      )
    );
  }

  return entries.sort((a, b) => a.alarmeTimestamp - b.alarmeTimestamp);
}

function buildEntry(flight, kind, eventoTimestamp, horarioEvento, minutosAntes, overrides) {
  const id = alarmName(flight.id, kind);
  const defaultTimestamp = eventoTimestamp - minutosAntes * 60 * 1000;

  const entry = {
    id,
    flightId: flight.id,
    kind,
    empresa: flight.empresa,
    numeroVoo: flight.numeroVoo,
    horarioPartida: flight.horarioVoo,
    horarioEvento,
    eventoTimestamp,
    alarmeMinutosAntes: minutosAntes,
    alarmeTimestamp: defaultTimestamp,
    enabled: true,
    customTime: false,
  };

  const override = overrides[id];
  if (override) {
    if (override.enabled === false) entry.enabled = false;
    if (override.hhmm) {
      // Mantém a mesma data-base do alarme padrão, só troca o horário —
      // equivalente a arrastar o ponteiro de um despertador de celular.
      const baseDateISO = formatISODate(new Date(defaultTimestamp));
      entry.alarmeTimestamp = dateFromISOAndHHMM(baseDateISO, override.hhmm).getTime();
      entry.customTime = true;
    }
  }

  entry.alarmeHHMM = formatHHMM(new Date(entry.alarmeTimestamp));
  return entry;
}

/** Só os alarmes ativados cujo horário de disparo ainda está no futuro (agendáveis) */
function futureAlarmEntries(entries, now = Date.now()) {
  return entries.filter((e) => e.enabled !== false && e.alarmeTimestamp > now);
}

/** Status textual para exibição na lista de alarmes */
function alarmStatus(entry, now = Date.now()) {
  if (entry.enabled === false) return "desativado";
  if (entry.eventoTimestamp <= now) return "concluido";
  if (entry.alarmeTimestamp <= now) return "disparado";
  return "agendado";
}

if (typeof self !== "undefined") {
  self.Alarms = {
    ALARM_PREFIX,
    alarmName,
    parseAlarmName,
    computeAlarmEntries,
    futureAlarmEntries,
    alarmStatus,
  };
}

})();
