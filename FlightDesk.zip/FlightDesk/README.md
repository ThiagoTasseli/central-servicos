# Central de Voos — CUPPS

Extensão de navegador (Manifest V3) para consulta de voos internacionais de
partida e geração automática de chamados de **Inspeção** e **Acompanhamento**
no padrão CUPPS, com alertas configuráveis.

## Instalação (modo desenvolvedor)
1. Abra `chrome://extensions`
2. Ative "Modo do desenvolvedor" (canto superior direito)
3. Clique em "Carregar sem compactação"
4. Selecione esta pasta (`VoosBH-Extension`)
5. Clique no ícone da extensão — ela abre como um painel fixo (side panel)
   que não fecha ao trocar de janela. Se preferir uma aba inteira, use o
   link "abra a extensão em uma aba" dentro do painel.

## Novidades da versão 4.0.0
- **Firefox**: o ícone da extensão abre a **barra lateral**, que fica
  aberta (o popup fechava sozinho ao trocar de aba / colar no ServiceAide).
- "Copiar informe" com o mesmo visual de "Editar / copiar campos".

## Novidades da versão 3.1.0
- **Copiar informe** (um botão só, no lugar de INS / AC): captura o chamado
  aberto no ServiceAide com a mesma lógica da extensão arion-plugin
  (título, nº do chamado, solicitante, ramal, e-mail, localização,
  violação SLA da tela e descrição) e copia no modelo de informe.
- Colar usa os seletores reais do ServiceAide (arion-plugin) e, se não
  achar, procura pelo rótulo do campo.
- **Firefox**: popup abria achatado — corrigido (440×600). Também abre
  como barra lateral (Exibir → Barra lateral → ARION · Central de Voos).
  Notificações sem botões no Firefox (use os botões no card do painel).

## Novidades da versão 3.0.0

### Colar: novos campos
- **Nome**: digita "Gregory", Enter, clica em "Felipe de Freitas Santos"
  na janela de busca e espera o E-mail se completar.
- **Telefone**: preenchido só depois do Nome.
- **Departamento**: AZUL / TAP / LATAM → a própria companhia;
  demais → Operações. Escolhe na lista.
- Tudo editável em **Configurações → ServiceAide**.

### Copiar Informes — INS / AC
- No rodapé de cada voo (substitui "Copiar informe + chamados").
- Lê o chamado aberto no ServiceAide: nº da solicitação, Nome,
  Telefone, E-mail, Localização e Detalhes.
- Se o nº do chamado não for encontrado, a extensão pergunta.
- VIOLAÇÃO SLA = horário do clique (+ horas configuráveis).

## Novidades da versão 2.2.0

### Botão "Colar" no ServiceAide
- Abra o formulário **Acompanhamento técnico de voo** no ServiceAide
  (`csm3.serviceaide.com`) em uma aba.
- No card do voo, clique em **Colar Inspeção** ou **Colar Acomp.**
- A extensão preenche sozinha:
  - **Descrição** ← máscara do chamado
  - **Detalhes** ← texto da descrição
  - **Matrícula** ← `N/A`
  - **Localização** ← `CHECK IN <COMPANHIA>` (escolhe na lista, se houver)
  - **Identificação do equipamento** ← `N/A`
- Os campos preenchidos piscam em verde. Revise e clique **Salvar**.
- Edições feitas em "Editar / copiar campos" são usadas na colagem.
- Matrícula, Identificação e prefixo da Localização são editáveis em
  **Configurações → ServiceAide**.
- Os botões **Copiar** continuam como plano B.

### Silenciar alarmes
- Sino no cabeçalho: liga/desliga o som de todos os alarmes.
- Aba **Alarme**: silenciar por 30 min, 1 h, 2 h ou até reativar.
- Silenciado: a notificação continua aparecendo, sem som.
- Card do alarme disparado ganhou **Parar som**.
- Botão **Testar som (3 s)**.

### Visual ARION
- Cabeçalho grafite com logo ARION em branco.
- Faixa laranja / branco / verde, cores do logo.
- Tema escuro como padrão (claro continua disponível).
- Novos ícones da extensão.

## Uso
1. Na aba **Voos**, arraste sua planilha (.xlsx/.xls/.csv) para a área
   indicada, ou clique para selecionar o arquivo.
2. Escolha a data desejada no seletor — a extensão já vem com a data de
   hoje selecionada.
3. Os voos **internacionais de partida** daquela data aparecem em uma
   tabela (ordenada por horário) e em cards individuais logo abaixo.
4. Em cada card, clique em **Inspeção** ou **Acompanhamento** para abrir o
   formulário correspondente, com os dados já preenchidos (mas editáveis).
5. Use os botões **Copiar** ao lado de cada campo para copiar só aquele
   campo, ou **+ abaixo** para copiar o campo e tudo que vem depois dele.
   O botão laranja **Copiar** no fim do formulário copia o chamado inteiro.
6. Use **Copiar Inspeção + Acompanhamento do voo** para copiar o informe e
   os dois chamados daquele voo de uma vez, ou **Copiar todos os chamados**
   no topo da aba para copiar tudo de todos os voos filtrados.
7. Na aba **Configurações**, ajuste Atendente, Solicitante, Ramal de
   Inspeção, Ramal de Acompanhamento e E-mail — esses valores alimentam
   automaticamente os chamados.
8. Na aba **Alarme**, defina o padrão de minutos antes de cada evento que
   você quer ser avisado (padrão: 15 min para Inspeção, 10 min para
   Acompanhamento). Cada alarme individual aparece logo abaixo, com um
   campo de horário editável e um interruptor de ativado/desativado — como
   no despertador do celular. Editar o horário de um alarme não afeta os
   demais; para voltar ao horário calculado pelo padrão, use "Usar horário
   padrão" no próprio alarme.
9. Os alarmes disparam mesmo com o painel fechado: o service worker de
   background usa `chrome.alarms`, mostra uma notificação do navegador e
   toca um som (via um documento *offscreen*, exigido pelo Manifest V3
   para reprodução de áudio fora de uma página visível).

## Colunas esperadas na planilha
Tipo de Voo · Natureza · Data do Voo · Companhia Aérea · Número do Voo ·
Modelo da Aeronave · Horário de Partida · Rota · Número de Assentos ·
Tipo de Serviço · Dia da Semana.

O reconhecimento de colunas tolera variações de maiúsculas/minúsculas,
acentos, espaços extras e underscores. Se uma coluna essencial não for
encontrada, a extensão informa qual.

Filtro aplicado automaticamente: Tipo de Voo = Partida, Natureza =
Internacional (aceita "INT", "Internacional", "Internacional (INT)" etc.),
Data do Voo = data selecionada.

## Arquitetura

```
manifest.json          Manifest V3 (side panel, alarms, notifications, offscreen)
popup.html / .css / .js  Interface (abas Voos / Configurações / Alarme)
background.js          Service worker: alarmes, notificações, som
offscreen.html / .js   Documento offscreen só para tocar o som de alerta
libs/xlsx.full.min.js  SheetJS (leitura local da planilha)
sounds/alert.wav       Som do alerta

modules/
  formatters.js   Data/hora, normalização de texto, numeração ①②③
  spreadsheet.js  Mapeamento de colunas, leitura do arquivo, filtro de voos
  templates.js    Textos dos chamados, informe do voo, mapa de destinos
  storage.js      Acesso único ao chrome.storage.local (chaves centralizadas)
  alarms.js       Cálculo puro dos horários de alarme (usado por popup e background)
  clipboard.js    navigator.clipboard.writeText com tratamento de erro
```

`modules/*` é carregado tanto no popup (`<script>`, na ordem
formatters → templates → storage → spreadsheet → alarms → clipboard) quanto
no background (`importScripts`, mesma ordem, exceto `clipboard.js`, que só
faz sentido em um contexto com foco de página). Isso evita duplicar a lógica
de cálculo de horários, textos de chamado e agendamento de alarmes.

## Principais decisões técnicas
- **Side panel em vez de popup padrão**: o painel não fecha ao arrastar um
  arquivo do sistema operacional ou trocar de janela para colar um texto —
  um popup comum fecharia e perderia o estado.
- **Datas em aritmética real** (`Date` + milissegundos), não em texto, para
  lidar corretamente com Inspeção/Acompanhamento que cruzam a meia-noite.
- **Status "copiado" persistido pelo background**: a marcação de campo
  copiado é enviada ao service worker antes da cópia em si, porque o painel
  pode fechar assim que o usuário troca de janela para colar o texto.
- **Reagendamento total dos alarmes a cada mudança** (planilha, data ou
  minutos de antecedência): mais simples e à prova de duplicidade do que
  reconciliar alarmes incrementalmente.
- Textos dos chamados (máscara e descrição) seguem a especificação **ao
  pé da letra**, inclusive a diferença proposital entre "INDENTIFICAR"
  (Inspeção) e "IDENTIFICAR" (Acompanhamento) — não é um erro de digitação
  a ser corrigido.

## Como testar a importação
1. Monte uma planilha de teste com as colunas listadas acima, com pelo
   menos um voo de Partida/Internacional na data que você vai selecionar.
2. Inclua um voo cujo horário de partida seja de madrugada (ex.: 01:30)
   para validar o cálculo de Inspeção cruzando a meia-noite.
3. Arraste o arquivo para a área de importação (ou clique para selecionar)
   e confira a contagem de registros e os cards gerados.
4. Tente importar um arquivo `.txt` para ver a mensagem de formato
   inválido, e uma planilha sem a coluna "Natureza" para ver a mensagem de
   coluna ausente.

## Como testar os alertas
1. Configure minutos de antecedência baixos (ex.: 1 minuto) na aba Alarme
   e salve, ou edite o horário de um alarme específico direto na lista.
2. Importe uma planilha com um voo cuja Inspeção ou Acompanhamento caia
   poucos minutos no futuro.
3. Fixe o painel, feche-o (ou troque de janela) e aguarde — a notificação
   e o som devem disparar mesmo com o painel fechado.
4. Reabra a extensão e confira o status de cada alarme na lista da aba Alarme.

## Permissões do manifest
`storage` (persistência local), `alarms` (agendamento dos alertas),
`notifications` (aviso do navegador), `offscreen` (tocar som fora de uma
página visível) e `sidePanel` (painel fixo). Nenhuma permissão de rede é
usada — a planilha é lida 100% localmente, sem `host_permissions`.

## Limitações conhecidas
- Notificações do Chrome dependem das configurações de notificação do
  sistema operacional; se estiverem desativadas para o navegador, o alerta
  sonoro ainda toca, mas a notificação visual pode não aparecer.
- O service worker do Manifest V3 pode ser encerrado pelo navegador após
  período de inatividade; ele é reativado automaticamente pelo próprio
  `chrome.alarms` no horário agendado, mas alarmes cujo Chrome estava
  completamente fechado só dispararão quando o navegador for reaberto.
- O mapeamento de destino/país (seção "Rota") é uma lista fixa e editável
  em `modules/templates.js` (`DESTINATIONS`) — aeroportos fora da lista
  aparecem só com a sigla, sem nome de país inventado.
- Novo upload de planilha substitui os dados de voos anteriores; as
  Configurações e o padrão de minutos da aba Alarme são preservados; os
  ajustes individuais de cada alarme (horário próprio/ativado) são
  recriados a cada nova planilha, já que os voos podem mudar.
