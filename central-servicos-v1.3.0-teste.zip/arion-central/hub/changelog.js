/* changelog.js — o que mudou em cada versão (aparece no Guia). */
self.ARION_CHANGELOG = [
  {
    versao: "1.3.0-teste",
    itens: [
      "Visual padronizado nas 4 ferramentas: mesmo cabeçalho, cores, fontes, botões e campos.",
      "Tema claro/escuro único, trocado no trilho (☀/☾).",
      "Fontes locais: não depende mais do Google Fonts nem de internet.",
      "Segurança: textos da planilha e das páginas são tratados antes de aparecer na tela.",
      "Biblioteca de planilhas atualizada (SheetJS 0.20.3).",
      "Dados de chamados e solicitantes apagados após 7 dias.",
      "Aviso de versão nova pela intranet (opcional).",
    ],
  },
  { versao: "1.2.0", itens: ["Botão para recolher a barra (Alt+0)."] },
  { versao: "1.1.0", itens: ["Modo bandeja ou fixado na lateral."] },
  { versao: "1.0.0", itens: ["Primeira versão: 4 extensões em uma, navegação por ícones e guia."] },
];
