// ARION · Preenchimento de Chamados — painel lateral
// Fluxo: capturar (opcional) → verificar entradas → inserir no formulário → gerar texto → copiar.
const api = globalThis.browser ?? globalThis.chrome;
const $ = (id) => document.getElementById(id);
// Escapa texto antes de ir para innerHTML.
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const SA_URLS = ['https://*.serviceaide.com/*'];

// ---------- Campos do painel ----------
const FIELDS = [
  { id: 'nome', label: 'Nome', req: true },
  { id: 'email', label: 'E-mail' },
  { id: 'telefone', label: 'Telefone', req: true },
  { id: 'equipamentoTipo', label: 'Equipamento', req: true },
  { id: 'tipo', label: 'Solicitação ou incidente', req: true },
  { id: 'localizacao', label: 'Localização', req: true },
  { id: 'problema', label: 'Descrição do problema', req: true },
  { id: 'detalhes', label: 'Detalhes' },
  { id: 'matricula', label: 'Matrícula', req: true },
  { id: 'departamento', label: 'Departamento', req: true },
  { id: 'equipamento', label: 'Identificação do equipamento', req: true },
];
const DEFAULTS = { matricula: 'N/A', equipamento: 'N/A' };
const DEFAULT_EQUIPS = ['CUPPS', 'CUSS', 'FIDS'];
let equips = [...DEFAULT_EQUIPS];

// ---------- Máscara: [ Equipamento ] [ TIPO ] [ LOCALIZAÇÃO ] [ DESCRIÇÃO ] ----------
const up = (t) => (t || '').trim().toLocaleUpperCase('pt-BR');
function buildMask(v) {
  return [v.equipamentoTipo, v.tipo, v.localizacao, v.problema].map((p) => `[${up(p)}]`).join(' ');
}
function updateMask() {
  const v = readValues();
  const empty = !v.equipamentoTipo && !v.tipo && !v.localizacao && !v.problema;
  $('mascara').textContent = empty ? '[ EQUIPAMENTO ] [ TIPO ] [ LOCALIZAÇÃO ] [ PROBLEMA ]' : buildMask(v);
}

// ---------- Modelo de texto (edite aqui para mudar o formato) ----------
const titleCase = (t) => t.toLowerCase().replace(/(^|\s)(\S)/g, (m, s, c) => s + c.toUpperCase());
function buildText(v) {
  return [
    buildMask(v),
    '',
    `SOLICITANTE: ${titleCase(v.nome)}`,
    `E-MAIL: ${v.email || 'N/A'}`,
    `RAMAL: ${v.telefone}`,
    `MATRÍCULA: ${v.matricula}`,
    `DEPARTAMENTO: ${v.departamento}`,
    `LOCALIZAÇÃO: ${up(v.localizacao)}`,
    `EQUIPAMENTO: ${v.equipamento}`,
    `DESCRIÇÃO: ${detalhesOf(v).replace(/\r/g, '')}`,
  ].join('\n');
}
const detalhesOf = (v) => v.detalhes || v.problema;

// ---------- Utilidades ----------
const readValues = () => Object.fromEntries(FIELDS.map((f) => [f.id, $(f.id).value.trim()]));
function setStatus(msg, kind = '', el = 'status') { $(el).textContent = msg; $(el).className = 'status ' + kind; }
// formTs: usado pela limpeza automática (dados com mais de 7 dias são apagados).
const saveForm = () => api.storage.local.set({ form: Object.fromEntries(FIELDS.map((f) => [f.id, $(f.id).value])), formTs: Date.now() });

// ---------- Configuração de equipamentos ----------
function renderEquips() {
  const sel = $('equipamentoTipo');
  const cur = sel.value;
  sel.innerHTML = '<option value="">Selecione…</option>' + equips.map((e) => `<option value="${esc(e)}">${esc(e)}</option>`).join('');
  if (cur && !equips.includes(cur)) sel.insertAdjacentHTML('beforeend', `<option value="${esc(cur)}">${esc(cur)}</option>`);
  sel.value = cur;
  $('cfgList').innerHTML = equips.map((e, i) => `<li><span>${esc(e)}</span><button class="icon-btn" data-del="${i}" type="button" title="Remover">✕</button></li>`).join('');
}
async function saveEquips() { await api.storage.local.set({ equips }); renderEquips(); }
function addEquip() {
  const name = up($('cfgNew').value).replace(/[<>"]/g, '');
  if (!name || equips.includes(name)) return;
  equips.push(name);
  $('cfgNew').value = '';
  saveEquips();
}

// ---------- Verificar entradas ----------
function verify(v) {
  const missing = FIELDS.filter((f) => f.req && !v[f.id]);
  const badMail = v.email && !/^\S+@\S+\.\S+$/.test(v.email);
  FIELDS.forEach((f) => $(f.id).classList.toggle('invalid', missing.includes(f) || (f.id === 'email' && badMail)));
  document.querySelector('.invalid')?.focus();
  if (missing.length) return { ok: false, msg: 'Preencha: ' + missing.map((f) => f.label).join(', ') + '.' };
  if (badMail) return { ok: false, msg: 'E-mail inválido.' };
  return { ok: true };
}

// ---------- Inserir no formulário (página do ServiceAide) ----------
// Ordem importa: o Nome vem primeiro (a janela de busca preenche o e-mail na página).
function buildPayload(v) {
  const [first, ...rest] = v.nome.split(/\s+/);
  return [
    { key: 'nome', labels: ['Nome'], mode: 'modal', search: first, pick: rest.join(' '), waitFor: ['Email', 'E-mail'], value: v.nome },
    { key: 'telefone', labels: ['Telefone'], value: v.telefone },
    { key: 'descricao', labels: ['Descrição'], value: buildMask(v) },
    { key: 'detalhes', labels: ['Detalhes', 'Detalhe'], value: detalhesOf(v) },
    { key: 'matricula', labels: ['Matrícula'], value: v.matricula },
    { key: 'departamento', labels: ['Departamento'], value: v.departamento, mode: 'select' },
    { key: 'localizacao', labels: ['Localização'], value: up(v.localizacao), mode: 'autocomplete' },
    { key: 'equipamento', labels: ['Identificação do equipamento', 'Identificação do equip.'], value: v.equipamento },
  ];
}
const PAGE_LABELS = { nome: 'Nome', telefone: 'Telefone', descricao: 'Descrição', detalhes: 'Detalhes', matricula: 'Matrícula', departamento: 'Departamento', localizacao: 'Localização', equipamento: 'Identificação do equipamento' };
const ERRORS = {
  'no-tab': 'ServiceAide não está aberto. Abra o chamado e tente de novo.',
  'no-form': 'Formulário não encontrado na aba do ServiceAide.',
  inject: 'Sem acesso à aba. Em chrome://extensions → Detalhes, libere serviceaide.com e recarregue a página.',
};

async function findTab() {
  let tabs = await api.tabs.query({ url: SA_URLS, currentWindow: true });
  if (!tabs.length) tabs = await api.tabs.query({ url: SA_URLS });
  return tabs.find((t) => t.active) || tabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0))[0] || null;
}

// Injeta sa-page.js em todos os frames e roda uma ação; devolve o resultado de cada frame.
async function runInPage(action, arg, focus) {
  const tab = await findTab();
  if (!tab) return { error: 'no-tab' };
  if (focus) {
    try { // a janela de busca do Nome precisa da página ativa
      await api.tabs.update(tab.id, { active: true });
      await api.windows.update(tab.windowId, { focused: true });
    } catch (_) {}
  }
  try {
    const target = { tabId: tab.id, allFrames: true };
    await api.scripting.executeScript({ target, files: ['apps/preenchimento/sa-page.js'] });
    const out = await api.scripting.executeScript({
      target,
      func: (act, a) => (window.__arionSA ? window.__arionSA[act](a) : null),
      args: [action, arg ?? null],
    });
    return { results: out.map((o) => o.result).filter(Boolean) };
  } catch (err) {
    console.error(err);
    return { error: 'inject' };
  }
}

async function fillPage(fields) {
  const r = await runInPage('fill', { fields }, true);
  if (r.error) return r;
  const best = r.results.sort((a, b) => b.filled.length - a.filled.length)[0];
  return best && best.filled.length ? best : { error: 'no-form' };
}

// ---------- Ação principal ----------
async function onFill() {
  const v = readValues();
  const check = verify(v);
  if (!check.ok) return setStatus(check.msg, 'err');

  $('fill').disabled = true;
  setStatus('Buscando o solicitante…');
  const res = await fillPage(buildPayload(v));
  $('fill').disabled = false;

  if (res.error) {
    showText(v);
    return setStatus(ERRORS[res.error] + ' O modelo foi gerado mesmo assim.', 'err');
  }

  // Resultado da busca do Nome
  const n = res.nome || { status: 'selecionado', email: '' };
  const [first, ...rest] = v.nome.split(/\s+/);
  if (n.status === 'nome-nao-encontrado') return setStatus(`Nome não encontrado: "${first}".`, 'err');
  if (n.status === 'sobrenome-nao-encontrado') return setStatus(`"${first}" encontrado, mas sobrenome "${rest.join(' ')}" não.`, 'err');

  let mailMsg = 'E-mail vazio no chamado.';
  if (n.email) {
    $('email').value = n.email;
    saveForm();
    mailMsg = `E-mail encontrado: ${n.email}.`;
  }

  showText(readValues());
  const todo = [...res.missing.map((k) => PAGE_LABELS[k] || k), ...res.notes.map((x) => PAGE_LABELS[x.split(':')[0]] || x)];
  if (todo.length) setStatus(`${mailMsg} Confira na página: ${[...new Set(todo)].join(', ')}.`, 'err');
  else setStatus(`Chamado preenchido ✓ ${mailMsg}`, n.email ? 'ok' : 'err');
}
function showText(v) { $('out').value = buildText(v); $('result').hidden = false; }

// ---------- Capturar (mesma lógica da arion-plugin) ----------
const cleanChamado = (t) => (t.match(/\b\d{3}-\d{4,}\b/) || [t.trim()])[0];
function normalizeRequester(value) { // "Sobrenome, Nome" → "Nome Sobrenome"
  const p = value.split(',');
  return p.length === 2 ? `${p[1].trim()} ${p[0].trim()}` : value.trim();
}
// Lê "[A] [B] [C] [D]" de volta nos 4 campos da máscara.
function parseMask(text) {
  const parts = [...(text || '').matchAll(/\[([^\]]*)\]/g)].map((m) => m[1].trim());
  if (parts.length !== 4) return null;
  const [eq, tp, loc, prob] = parts;
  const tipo = /incid/i.test(tp) ? 'INCIDENTE' : /solic/i.test(tp) ? 'SOLICITAÇÃO' : '';
  return { equipamentoTipo: up(eq), tipo, localizacao: loc, problema: prob };
}

async function onCapture() {
  $('capture').disabled = true;
  setStatus('Capturando…', '', 'capStatus');
  const r = await runInPage('capture');
  $('capture').disabled = false;
  if (r.error) return setStatus(ERRORS[r.error], 'err', 'capStatus');
  const best = r.results.sort((a, b) => b.found - a.found)[0];
  if (!best || !best.found) return setStatus('Nenhum dado capturado.', 'err', 'capStatus');

  const d = best.data;
  const c = {
    chamado: cleanChamado(d.chamado || ''),
    nome: normalizeRequester(d.nome || ''),
    telefone: (d.telefone || '').trim(),
    email: (d.email || '').trim(),
    localizacao: (d.localizacao || '').trim(),
    titulo: (d.descricao || '').trim(),
    detalhes: (d.detalhes || '').trim(),
    sla: (d.sla || '').trim(),
  };

  // Preenche o painel com o que veio
  const set = (id, val) => { if (val) $(id).value = val; };
  set('nome', c.nome); set('telefone', c.telefone); set('email', c.email);
  set('localizacao', c.localizacao); set('detalhes', c.detalhes);
  const m = parseMask(c.titulo);
  if (m) {
    if (m.equipamentoTipo && !equips.includes(m.equipamentoTipo)) { equips.push(m.equipamentoTipo); await saveEquips(); }
    Object.entries(m).forEach(([k, val]) => set(k, val));
  } else set('problema', c.titulo);
  updateMask();
  saveForm();

  // Informe no formato da arion-plugin
  $('capOut').value = [
    c.titulo,
    '',
    `CHAMADO: ${c.chamado}`,
    `SOLICITANTE: ${c.nome}`,
    `RAMAL: ${c.telefone}`,
    `E-MAIL: ${c.email}`,
    `LOCALIZAÇÃO: ${c.localizacao}`,
    `VIOLAÇÃO SLA: ${c.sla}`,
    `DESCRIÇÃO: ${c.detalhes}`,
  ].join('\n');
  $('capResult').hidden = false;
  setStatus(`${best.found} campo(s) capturado(s) ✓`, 'ok', 'capStatus');
}

// ---------- Copiar ----------
async function copyFrom(id, statusEl, msg) {
  try { await navigator.clipboard.writeText($(id).value); }
  catch (_) { $(id).select(); document.execCommand('copy'); }
  setStatus(msg, 'ok', statusEl);
}

async function onClear() {
  FIELDS.forEach((f) => { $(f.id).value = DEFAULTS[f.id] ?? ''; $(f.id).classList.remove('invalid'); });
  $('result').hidden = true;
  $('capResult').hidden = true;
  setStatus(''); setStatus('', '', 'capStatus');
  updateMask();
  await api.storage.local.remove('form');
}

(async function init() {
  const { form = {}, equips: saved } = await api.storage.local.get(['form', 'equips']);
  if (Array.isArray(saved) && saved.length) equips = saved;
  renderEquips();
  FIELDS.forEach((f) => { $(f.id).value = form[f.id] ?? DEFAULTS[f.id] ?? ''; });
  renderEquips(); // mantém equipamento salvo que saiu da lista
  updateMask();

  const onChange = () => { updateMask(); saveForm(); };
  document.addEventListener('input', onChange);
  document.addEventListener('change', onChange);

  $('cfgToggle').addEventListener('click', (e) => { e.preventDefault(); $('cfg').hidden = !$('cfg').hidden; });
  $('cfgAdd').addEventListener('click', addEquip);
  $('cfgNew').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); addEquip(); } });
  $('cfgList').addEventListener('click', (e) => {
    const i = e.target.dataset.del;
    if (i === undefined) return;
    equips.splice(Number(i), 1);
    saveEquips();
  });

  $('capture').addEventListener('click', onCapture);
  $('capCopy').addEventListener('click', () => copyFrom('capOut', 'capStatus', 'Informe copiado ✓'));
  $('fill').addEventListener('click', onFill);
  $('copy').addEventListener('click', () => copyFrom('out', 'status', 'Modelo copiado ✓'));
  $('clear').addEventListener('click', onClear);
})();
