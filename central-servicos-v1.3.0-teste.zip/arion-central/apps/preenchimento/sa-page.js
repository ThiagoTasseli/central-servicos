/* modules/sa-page.js
 * Roda DENTRO da página do ServiceAide (injetado via chrome.scripting).
 * Define window.__arionSA com:
 *   fill(payload) → preenche o formulário, campo a campo, em ordem
 *   read(spec)    → lê os campos do chamado + número da solicitação
 *
 * Os campos são localizados PELO RÓTULO visível ("Nome", "Descrição"...),
 * sem depender de IDs internos do site.
 */
(function () {
  const VERSION = 5;
  if (window.__arionSA && window.__arionSA.version === VERSION) return; // já injetado neste frame

  const CONTROL_SEL = [
    'input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"])' +
      ':not([type="button"]):not([type="submit"]):not([type="file"]):not([type="image"])',
    "textarea",
    "select",
    '[contenteditable]:not([contenteditable="false"])',
    "iframe",
  ].join(",");

  const OPTION_SEL = [
    '[role="option"]',
    ".x-boundlist-item",
    ".ui-menu-item",
    ".ui-menu-item-wrapper",
    ".dropdown-item",
    ".select2-results__option",
    ".tt-suggestion",
    ".autocomplete-suggestion",
    ".k-list-item",
    ".k-item",
    "mat-option",
    "li",
  ].join(",");

  // ---------- Seletores reais do ServiceAide (mesmos da extensão arion-plugin) ----------
  const FALLBACK_SLA =
    "#tabcontainer-body > div.x-panel.x-tabpanel-child.x-panel-default.x-closable.x-panel-closable.x-panel-default-closable > div > div.x-panel.x-panel-default > div > div > div > div.x-panel.ca-panel-collapse-icon-left.ca-panel-collapse-icon-sidebar.ca-panel-no-border.ca-panel-no-shadow.x-box-item.x-panel-ca-sidebar > div.x-panel-body.x-panel-body-ca-sidebar.x-panel-body-ca-sidebar > div.x-container.x-container-default > div:nth-child(1) > div.x-panel-body.x-panel-body-ca-collapsiblepanel.x-panel-body-ca-collapsiblepanel > div.x-container.x-container-default > div.x-container.x-container-default.x-box-layout-ct > div > div > label";

  const SA_SELECTORS = {
    chamado: ['label[data-caid="title"]'],
    nome: ['input[autoidentifier="txtbox_RequesterUserNameVIP"]', 'input[name="RequesterUserNameVIP"]'],
    telefone: ['input[autoidentifier="txtbox_RequesterAltPhone"]', 'input[name="RequesterAltPhone"]'],
    email: ['input[autoidentifier="txtbox_RequesterAltEmail"]', 'input[name="RequesterAltEmail"]'],
    localizacao: ['input[autoidentifier="txtbox_Localização"]'],
    descricao: ['textarea[autoidentifier="txtbox_Description"]', 'textarea[name="Description"]'],
    detalhes: ['textarea[autoidentifier="txtbox_Details"]', 'textarea[name="DescriptionLong"]'],
    slaFallback: [FALLBACK_SLA],
  };

  function bySelectors(list) {
    for (const sel of list || []) {
      try {
        const el = document.querySelector(sel);
        if (el) return el;
      } catch (_) {}
    }
    return null;
  }

  // ---------- utilitários ----------
  const norm = (s) =>
    String(s || "")
      .normalize("NFD")
      .replace(/[̀-ͯ]/g, "")
      .replace(/[*:]/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
  const compact = (s) => norm(s).replace(/[^a-z0-9]/g, "");
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  const visible = (el) => {
    if (!el || !el.getClientRects || !el.getClientRects().length) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== "hidden" && cs.display !== "none";
  };
  const usable = (el) => visible(el) && !el.disabled && !el.readOnly;
  const after = (a, b) => !!(a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING);

  function fire(el, type) {
    el.dispatchEvent(new Event(type, { bubbles: true }));
  }

  function key(el, k, code, keyCode) {
    for (const type of ["keydown", "keypress", "keyup"]) {
      el.dispatchEvent(
        new KeyboardEvent(type, { bubbles: true, cancelable: true, key: k, code, keyCode, which: keyCode })
      );
    }
  }

  function click(el) {
    for (const type of ["mouseover", "mousedown", "mouseup", "click"]) {
      el.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
    }
  }

  function dblclick(el) {
    el.dispatchEvent(new MouseEvent("dblclick", { bubbles: true, cancelable: true, view: window }));
  }

  // ---------- localizar campo pelo rótulo ----------
  function findByLabel(labels, { readonlyOk = false } = {}) {
    const ok = readonlyOk ? visible : usable;
    const wanted = labels.map(compact);
    const matches = (t) => wanted.includes(compact(t));

    // 1) <label for> ou <label> envolvendo o campo
    for (const lab of document.querySelectorAll("label")) {
      if (!visible(lab) || !matches(lab.textContent)) continue;
      if (lab.htmlFor) {
        const el = document.getElementById(lab.htmlFor);
        if (el && ok(el)) return el;
      }
      const inner = lab.querySelector(CONTROL_SEL);
      if (inner && ok(inner)) return inner;
    }

    // 2) aria-label / placeholder / title / aria-labelledby
    for (const el of document.querySelectorAll(CONTROL_SEL)) {
      if (!ok(el)) continue;
      const attrs = [el.getAttribute("aria-label"), el.getAttribute("placeholder"), el.getAttribute("title")];
      if (attrs.some((a) => a && matches(a))) return el;
      const lb = el.getAttribute("aria-labelledby");
      if (lb) {
        const t = lb
          .split(/\s+/)
          .map((id) => document.getElementById(id)?.textContent || "")
          .join(" ");
        if (matches(t)) return el;
      }
    }

    // 3) texto visível igual ao rótulo → primeiro campo após ele
    const textEls = [...document.querySelectorAll("label, span, div, td, th, dt, p, b, strong, legend")].filter(
      (el) => el.textContent.length < 80 && matches(el.textContent) && visible(el)
    );
    const innermost = textEls.filter((el) => !textEls.some((o) => o !== el && el.contains(o)));

    for (const lab of innermost) {
      let node = lab.parentElement;
      for (let depth = 0; depth < 6 && node; depth++, node = node.parentElement) {
        const ctrl = [...node.querySelectorAll(CONTROL_SEL)].find((c) => visible(c) && after(lab, c));
        if (ctrl) {
          if (ok(ctrl)) return ctrl;
          break; // bloqueado: não pula para o campo de outro rótulo
        }
      }
    }
    return null;
  }

  // ---------- ler / escrever valor ----------
  function readValue(el) {
    if (!el) return "";
    if (el.tagName === "IFRAME") {
      try {
        return (el.contentDocument?.body?.innerText || "").trim();
      } catch (_) {
        return "";
      }
    }
    if (el.isContentEditable) return (el.innerText || "").trim();
    if (el.tagName === "SELECT") return (el.selectedOptions[0]?.textContent || "").trim();
    return String(el.value || "").trim();
  }

  function setNativeValue(el, value) {
    const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, "value");
    if (desc && desc.set) desc.set.call(el, value);
    else el.value = value;
  }

  const escapeHtml = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

  function setValue(el, value) {
    if (el.tagName === "IFRAME") {
      let doc;
      try {
        doc = el.contentDocument;
      } catch (_) {
        return false;
      }
      if (!doc || !doc.body) return false;
      doc.body.focus();
      doc.body.innerHTML = escapeHtml(value).replace(/\n/g, "<br>");
      doc.body.dispatchEvent(new InputEvent("input", { bubbles: true }));
      doc.body.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: " " }));
      return true;
    }

    if (el.isContentEditable) {
      el.focus();
      const sel = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(el);
      sel.removeAllRanges();
      sel.addRange(range);
      const ok = document.execCommand("insertText", false, value);
      if (!ok || compact(el.innerText) !== compact(value)) el.innerText = value;
      el.dispatchEvent(new InputEvent("input", { bubbles: true }));
      fire(el, "blur");
      return true;
    }

    if (el.tagName === "SELECT") {
      const target = compact(value);
      const opt =
        [...el.options].find((o) => compact(o.textContent) === target) ||
        [...el.options].find((o) => compact(o.textContent).includes(target));
      if (!opt) return false;
      el.value = opt.value;
      fire(el, "input");
      fire(el, "change");
      return true;
    }

    el.focus();
    try {
      el.select();
    } catch (_) {}
    let ok = false;
    try {
      ok = document.execCommand("insertText", false, value);
    } catch (_) {}
    if (!ok || el.value !== value) {
      setNativeValue(el, value);
      fire(el, "input");
    }
    el.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "Unidentified" }));
    el.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: "Unidentified" }));
    fire(el, "change");
    return true;
  }

  // ---------- lista de sugestões (autocomplete) ----------
  async function pickSuggestion(input, value) {
    const target = compact(value);
    const deadline = Date.now() + 3500;
    while (Date.now() < deadline) {
      await sleep(250);
      const opts = [...document.querySelectorAll(OPTION_SEL)].filter(
        (o) => visible(o) && o !== input && !o.contains(input) && o.textContent.length < 120
      );
      const exact = opts.find((o) => compact(o.textContent) === target);
      const opt =
        exact ||
        opts.find((o) => {
          const t = compact(o.textContent);
          return t && t.length >= 4 && (t.includes(target) || target.includes(t));
        });
      if (opt) {
        click(opt);
        return "selecionado";
      }
    }
    return "sem-lista";
  }

  // ---------- busca em janela (modal): digita, Enter, clica no nome ----------
  function findTextTarget(text) {
    const target = compact(text);
    const els = [...document.querySelectorAll("td, li, a, span, div, [role='row'], [role='gridcell'], tr")].filter(
      (el) => visible(el) && el.textContent.length < 200 && compact(el.textContent).includes(target)
    );
    // o mais interno
    return els.filter((el) => !els.some((o) => o !== el && el.contains(o)))[0] || null;
  }

  // Linhas da janela de busca (grade ExtJS do ServiceAide e genéricos).
  const ROW_SEL = ".x-grid-item, .x-grid-row, tr, [role='row'], li, .x-boundlist-item, [role='option']";

  function rowsWith(words) {
    const want = words.map(compact).filter(Boolean);
    if (!want.length) return [];
    const rows = [...document.querySelectorAll(ROW_SEL)].filter((el) => {
      if (!visible(el) || el.textContent.length > 300) return false;
      const t = compact(el.textContent);
      return want.every((w) => t.includes(w));
    });
    // mais internos primeiro
    return rows.filter((el) => !rows.some((o) => o !== el && el.contains(o)));
  }

  function readEmail(labels) {
    const el = bySelectors(SA_SELECTORS.email) || findByLabel(labels, { readonlyOk: true });
    return readValue(el);
  }

  /**
   * Nome: digita o 1º nome + Enter.
   *  - nenhuma linha com o 1º nome  → "nome-nao-encontrado"
   *  - acha o 1º nome, mas não o sobrenome → "sobrenome-nao-encontrado"
   *  - clica na pessoa e lê o E-mail → { status: "selecionado", email }
   */
  async function pickFromModal(input, first, rest, emailLabels) {
    const emailBefore = readEmail(emailLabels);
    key(input, "Enter", "Enter", 13);

    let firstRows = [];
    let triedButton = false;
    const deadline = Date.now() + 6000;
    while (Date.now() < deadline) {
      await sleep(300);
      // ServiceAide pode selecionar sozinho quando há um único resultado
      const em = readEmail(emailLabels);
      if (em && em !== emailBefore) return { status: "selecionado", email: em };
      firstRows = rowsWith([first]).filter((r) => !r.contains(input));
      if (firstRows.length) break;
      if (!triedButton && Date.now() > deadline - 4000) {
        triedButton = true;
        const btn = input.parentElement?.querySelector("button, [role='button'], .search, [class*='search'], [class*='lookup'], [class*='trigger']");
        if (btn && btn !== input) click(btn);
      }
    }
    if (!firstRows.length) return { status: "nome-nao-encontrado", email: "" };

    // Sobrenome: todas as palavras; depois só o último sobrenome
    const restWords = rest.split(/\s+/).filter((w) => w.length > 1);
    let target = null;
    if (!restWords.length) target = firstRows.length === 1 ? firstRows[0] : null;
    else {
      await sleep(400); // deixa a lista terminar de carregar
      const pool = rowsWith([first]).filter((r) => !r.contains(input));
      const full = pool.filter((r) => restWords.every((w) => compact(r.textContent).includes(compact(w))));
      const last = pool.filter((r) => compact(r.textContent).includes(compact(restWords[restWords.length - 1])));
      target = full[0] || (last.length === 1 ? last[0] : null);
    }
    if (!target) return { status: "sobrenome-nao-encontrado", email: "" };

    const cell = [...target.querySelectorAll("td, .x-grid-cell, [role='gridcell'], span, div")].find(
      (c) => visible(c) && compact(c.textContent).includes(compact(first))
    ) || target;
    target.scrollIntoView({ block: "nearest" });
    click(cell);
    if (cell !== target) click(target);
    await sleep(700);

    if (visible(target)) {
      dblclick(cell);
      await sleep(600);
    }
    if (visible(target)) {
      const confirm = [...document.querySelectorAll("button, a, [role='button'], input[type='button']")].find(
        (b) => visible(b) && /^(selecionar|ok|confirmar|escolher|aplicar|select)$/.test(norm(b.textContent || b.value))
      );
      if (confirm) {
        click(confirm);
        await sleep(600);
      }
    }

    // Espera o E-mail se completar
    const until = Date.now() + 4000;
    let email = "";
    while (Date.now() < until) {
      email = readEmail(emailLabels);
      if (email) break;
      await sleep(250);
    }
    return { status: "selecionado", email };
  }

  // ---------- lista de seleção (não aceita digitação) ----------
  // Ex.: Departamento — caixa bloqueada com seta; clica, abre a lista, clica na opção.
  const LIST_HINT = /list|drop|popup|menu|boundlist|picker|options|select|combo/i;

  function optionCandidates() {
    return [...document.querySelectorAll(OPTION_SEL + ", [role='listbox'] *, ul *")].filter(
      (o) => o.textContent && o.textContent.length < 120 && !o.querySelector("li, [role='option']")
    );
  }

  function insideList(el) {
    for (let n = el; n && n !== document.body; n = n.parentElement) {
      if (n.getAttribute && n.getAttribute("role") === "listbox") return true;
      if (typeof n.className === "string" && LIST_HINT.test(n.className)) return true;
    }
    return false;
  }

  function matchOption(target, before) {
    const opts = optionCandidates().filter((o) => visible(o));
    // Prioriza opções que surgiram ao abrir a lista e/ou estão dentro de uma lista
    const score = (o) => (before.has(o) ? 0 : 2) + (insideList(o) ? 1 : 0);
    const ranked = (arr) => arr.sort((a, b) => score(b) - score(a))[0];
    const exact = opts.filter((o) => compact(o.textContent) === target);
    if (exact.length) return ranked(exact);
    const starts = opts.filter((o) => compact(o.textContent).startsWith(target));
    if (starts.length) return ranked(starts);
    return null;
  }

  function findTrigger(el) {
    // Seta ao lado do campo (botão, span/div com classe de "trigger/arrow")
    let n = el.parentElement;
    for (let d = 0; d < 3 && n; d++, n = n.parentElement) {
      const t = [...n.querySelectorAll("button, [role='button'], span, div, a, i")].find(
        (x) =>
          x !== el &&
          !x.contains(el) &&
          visible(x) &&
          after(el, x) &&
          (/trigger|arrow|caret|drop|select|toggle|picker/i.test(String(x.className)) || x.tagName === "BUTTON")
      );
      if (t) return t;
    }
    return null;
  }

  function scrollableLists() {
    return [...document.querySelectorAll("ul, div, [role='listbox']")].filter((x) => {
      if (!visible(x) || x.scrollHeight <= x.clientHeight + 4) return false;
      const cs = getComputedStyle(x);
      return /(auto|scroll)/.test(cs.overflowY) && x.querySelector("li, [role='option']");
    });
  }

  async function chooseFromList(el, value) {
    const target = compact(value);
    if (el.tagName === "SELECT") return setValue(el, value) ? "selecionado" : "sem-opcao";

    const before = new Set(optionCandidates().filter((o) => visible(o)));

    el.scrollIntoView({ block: "center" });
    el.focus();
    click(el);
    await sleep(400);

    let opt = null;
    const deadline = Date.now() + 4000;
    let triggered = false;
    while (Date.now() < deadline && !opt) {
      opt = matchOption(target, before);
      if (opt) break;
      if (!triggered) {
        triggered = true;
        const trig = findTrigger(el);
        if (trig) click(trig);
      }
      // Lista virtualizada: rola para carregar mais opções
      for (const list of scrollableLists()) {
        if (list.scrollTop + list.clientHeight < list.scrollHeight) list.scrollTop += list.clientHeight;
      }
      await sleep(250);
    }
    if (!opt) {
      key(el, "Escape", "Escape", 27);
      return "sem-opcao";
    }

    opt.scrollIntoView({ block: "nearest" });
    await sleep(80);
    click(opt);
    await sleep(400);

    // Confere se o campo ficou com o valor
    if (compact(readValue(el)).startsWith(target)) return "selecionado";
    dblclick(opt);
    await sleep(300);
    return compact(readValue(el)).startsWith(target) ? "selecionado" : "nao-confirmado";
  }

  function flash(el) {
    const prev = el.style.boxShadow;
    el.style.transition = "box-shadow 200ms";
    el.style.boxShadow = "0 0 0 3px #00BF9A";
    setTimeout(() => {
      el.style.boxShadow = prev;
    }, 2200);
  }

  // ---------- API ----------
  async function fill(payload) {
    const result = { filled: [], missing: [], notes: [], nome: null, url: location.href };

    // Este frame tem o formulário? (pelo menos um rótulo conhecido)
    if (!payload.fields.some((f) => bySelectors(SA_SELECTORS[f.key]) || findByLabel(f.labels))) {
      result.missing = payload.fields.map((f) => f.key);
      return result;
    }

    // Campo a campo, em ordem (Nome primeiro: a janela de busca muda a tela)
    for (const f of payload.fields) {
      if (f.mode === "select") {
        const el = findByLabel(f.labels, { readonlyOk: true });
        if (!el) {
          result.missing.push(f.key);
          continue;
        }
        const r = await chooseFromList(el, f.value);
        if (r === "sem-opcao") {
          result.missing.push(f.key);
          result.notes.push(f.key + ":sem-opcao");
          continue;
        }
        if (r === "nao-confirmado") result.notes.push(f.key + ":nao-confirmado");
        fire(el, "change");
        flash(el);
        result.filled.push(f.key);
        await sleep(120);
        continue;
      }

      const bySel = bySelectors(SA_SELECTORS[f.key]);
      const el = (bySel && usable(bySel) ? bySel : null) || findByLabel(f.labels);
      if (!el || !setValue(el, f.mode === "modal" ? f.search : f.value)) {
        result.missing.push(f.key);
        continue;
      }

      if (f.mode === "modal") {
        const r = await pickFromModal(el, f.search, f.pick, f.waitFor);
        result.nome = r;
        if (r.status !== "selecionado") {
          // Sem a pessoa certa não adianta seguir: avisa e para.
          result.filled.push(f.key);
          result.stopped = true;
          return result;
        }
      } else if (f.mode === "autocomplete" && el.tagName === "INPUT") {
        const r = await pickSuggestion(el, f.value);
        if (r === "sem-lista") result.notes.push(f.key + ":sem-lista");
        fire(el, "blur");
      } else {
        fire(el, "blur");
      }

      flash(el);
      result.filled.push(f.key);
      await sleep(120);
    }
    return result;
  }

  /** Número da solicitação, ex.: 100-28152 (não confunde com telefone 93500-0908). */
  function findTicketNumber() {
    const re = /(?<![\d-])(\d{3}-\d{4,7})(?![\d-])/;
    const sources = [location.hash, document.title];
    // Elementos com texto que cita a solicitação/chamado/ticket primeiro
    const hinted = [...document.querySelectorAll("h1, h2, h3, h4, span, div, td, a, label")]
      .filter((el) => visible(el) && el.textContent.length < 160 && /solicita|chamado|ticket|request|incidente/i.test(el.textContent))
      .map((el) => el.textContent);
    sources.push(...hinted);
    sources.push(document.body ? document.body.innerText : "");
    for (const s of sources) {
      const m = String(s || "").match(re);
      if (m) return m[1];
    }
    return "";
  }

  function read(spec) {
    const values = {};
    let found = 0;
    for (const f of spec.fields) {
      const el = findByLabel(f.labels, { readonlyOk: true });
      values[f.key] = readValue(el);
      if (el) found++;
    }
    values.chamado = findTicketNumber();
    return { values, found, url: location.href };
  }

  // ---------- Captura do chamado (mesma lógica da arion-plugin) ----------
  function readEl(el) {
    if (!el) return "";
    const tag = el.tagName.toLowerCase();
    if (tag === "input" || tag === "textarea" || tag === "select") {
      return el.value?.trim() || el.getAttribute("title")?.trim() || el.textContent?.trim() || "";
    }
    return el.getAttribute("title")?.trim() || el.textContent?.trim() || "";
  }

  function tryGet(list) {
    for (const sel of list || []) {
      try {
        const v = readEl(document.querySelector(sel));
        if (v) return v;
      } catch (_) {}
    }
    return "";
  }

  function getSla() {
    const root = document.querySelector('[data-caid="slaInnerData"]');
    if (root?.textContent?.includes("Resolver em")) {
      const dates = [...root.querySelectorAll("label")]
        .map((l) => l.textContent?.trim() || "")
        .filter((t) => /\d{2}\/\d{2}\/\d{4}/.test(t));
      if (dates.length) return dates[dates.length - 1];
    }
    return tryGet(SA_SELECTORS.slaFallback);
  }

  function capture() {
    const data = {};
    let found = 0;
    for (const [k, list] of Object.entries(SA_SELECTORS)) {
      if (k === "slaFallback") continue;
      data[k] = tryGet(list);
      if (data[k]) found++;
    }
    data.sla = getSla();
    if (data.sla) found++;
    // Plano B: campos pelo rótulo visível, se os seletores não acharem
    if (!data.descricao || !data.detalhes) {
      const lab = read({
        fields: [
          { key: "nome", labels: ["Nome"] },
          { key: "telefone", labels: ["Telefone"] },
          { key: "email", labels: ["Email", "E-mail"] },
          { key: "localizacao", labels: ["Localização"] },
          { key: "descricao", labels: ["Descrição"] },
          { key: "detalhes", labels: ["Detalhes", "Detalhe"] },
        ],
      });
      for (const [k, v] of Object.entries(lab.values)) {
        if (!data[k] && v) {
          data[k] = v;
          found++;
        }
      }
    }
    return { data, found, url: location.href };
  }

  window.__arionSA = { version: VERSION, fill, read, capture };
})();
