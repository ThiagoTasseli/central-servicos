/* modules/regras.js
 * Regras de negócio do NOC: clientes, operadoras, máscara e textos
 * (Atacado e Suporte TI (Engenharia)).
 * Para ajustar um texto exato (ex.: "CLARO S.A" × "CLARO S.A."), mude só aqui.
 */
(function () {

const NG = 'Não Geográficos (Urbanos)';
const UFS = 'AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO'.split(' ');

// mascara: texto da operadora na máscara.
// empresa: texto digitado em "Empresa (Razão social)" e "Empresa (Nome fantasia)".
const OPERADORAS = {
  claro:      { nome: 'Claro',             mascara: 'CLARO S.A.',             empresa: 'CLARO S.A' },
  telefonica: { nome: 'Telefônica (Vivo)', mascara: 'TELEFONICA BRASIL S.A.', empresa: 'TELEFONICA BRASIL S.A' },
  telmex:     { nome: 'Telmex',            mascara: 'TELMEX',                 empresa: 'TELMEX DO BRASIL S/A' },
  algar:      { nome: 'Algar Telecom',     mascara: 'ALGAR TELECOM',          empresa: 'ALGAR TELECOM' }
};

// Tipos de identificador no fim da máscara.
const SUFIXOS = {
  ci:      { rotulo: 'Chamado interno',    prefixo: 'CI: ' },
  inc:     { rotulo: 'Chamado Vivo (INC)', prefixo: '' },
  agencia: { rotulo: 'BRAD',               prefixo: 'BRAD: ' },
  sigla:   { rotulo: 'Sigla',              prefixo: 'SIGLA: ' },
  brad:    { rotulo: 'BRAD',               prefixo: 'BRAD:' },
  np:      { rotulo: 'NP',                 prefixo: 'NP:' }
};

// Modelos de máscara. 'rest' = Restauração (usa o cliente). Os outros só geram a máscara.
//  reinc: [REINCIDENCIA MONITORAMENTO] - OPERADORA - BRADESCO - DESIGNAÇÃO - BRAD:nº
//  canc:  NGO - OPERADORA - CANCELAMENTO - INTERNET - OP:operadora - DESIGNAÇÃO - NP:nº
const MODELOS = {
  ng:    { nome: 'Restauração · Não Geográficos (Urbanos)', modelo: 'rest', clientes: ['carrefour', 'mcdonalds', 'fust', 'algar', 'diversos'] },
  brad:  { nome: 'Restauração · Bradesco',                  modelo: 'rest', clientes: ['bradesco'] },
  proj:  { nome: 'Restauração · Projetos BB, CEF e Correios', modelo: 'rest', clientes: ['bb', 'cef', 'correios'] },
  reinc: { nome: 'Reincidência · Bradesco',                 modelo: 'reinc', operadoras: ['telmex', 'telefonica'], sufixo: 'brad' },
  canc:  { nome: 'Cancelamento',                            modelo: 'canc',  operadoras: ['telefonica', 'claro', 'telmex', 'algar'], sufixo: 'np' }
};
const SO_MASCARA = ['reinc', 'canc'];
const grupoDoCliente = c => Object.keys(MODELOS).find(g => (MODELOS[g].clientes || []).includes(c)) || '';

// Ordem importa: o primeiro cliente encontrado vence (título antes do corpo).
const CLIENTES = {
  fust:      { nome: 'Projeto FUST',      localidade: NG,      prefixo: NG,                 projeto: 'PROJETO FUST',      operadoras: ['telefonica'],          sufixo: 'inc',                                   detectar: /\bFUST\b|\bINEP\b/i },
  bradesco:  { nome: 'BRAD (Bradesco)',   localidade: 'BRAD',              prefixo: 'BRAD',             projeto: 'BRADESCO',          operadoras: ['telefonica', 'telmex'], sufixo: { telefonica: 'agencia', telmex: 'ci' }, detectar: /BRADESCO|\bBRAD\b/i },
  bb:        { nome: 'Projeto BB',        localidade: 'Projeto BB',        prefixo: 'Projeto BB',       projeto: 'PROJETO BB',        operadoras: ['claro'],               sufixo: 'ci',                                    detectar: /PROJETO BB|BANCO DO BRASIL/i },
  cef:       { nome: 'Projeto CEF',       localidade: 'Projeto CEF',       prefixo: 'Projeto CEF',      projeto: 'PROJETO CEF',       operadoras: ['claro'],               sufixo: 'ci',                                    detectar: /PROJETO CEF|CAIXA ECON|\bCEF\b/i },
  correios:  { nome: 'Projeto Correios',  localidade: 'Projeto Correios',  prefixo: 'Projeto Correios', projeto: 'PROJETO CORREIOS',  operadoras: ['claro'],               sufixo: 'ci',                                    detectar: /CORREIOS|\bECT\b/i },
  carrefour: { nome: 'Projeto Carrefour', localidade: NG, prefixo: NG,                 projeto: 'PROJETO CARREFOUR', operadoras: ['claro'],               sufixo: 'ci',                                    detectar: /CARREFOUR/i },
  mcdonalds: { nome: 'Arcos Dourados',    localidade: NG,    prefixo: NG,                 projeto: 'ARCOS DOURADOS',    operadoras: ['telefonica', 'claro'], sufixo: 'sigla',                                 mascaraOperadora: { claro: 'CLARO.' }, detectar: /MC\s?DONALD|ARCOS DOURADOS/i },
  algar:     { nome: 'Projeto Algar',     localidade: 'Projeto EILD Algar - {UF}', prefixo: NG,         projeto: 'PROJETO ALGAR',     operadoras: ['algar'],               sufixo: 'ci',                                    detectar: /ALGAR/i },
  diversos:  { nome: 'Projeto Diversos',  localidade: NG,  prefixo: NG,                 projeto: 'PROJETO DIVERSOS',  operadoras: ['claro'],               sufixo: 'ci',                                    detectar: /PROJETO DIVERSOS/i }
};

// Localidade no OTRS: digita "busca" e clica na opção "opcao".
// opcao null = clica na primeira da lista.
// Carrefour, McDonald's, FUST e Diversos: Localidade "Não Geográficos (Urbanos)";
// o Cliente só entra na máscara. Algar mantém "Projeto EILD Algar - UF".
const LOC_NG = { busca: 'urbanos', opcao: NG };
const LOCALIDADE_BUSCA = {
  fust:      LOC_NG,
  bradesco:  { busca: 'brad',       opcao: null },
  bb:        { busca: 'bb',         opcao: 'Projeto BB' },
  cef:       { busca: 'cef',        opcao: 'Projeto CEF' },
  correios:  { busca: 'correios',   opcao: 'Projeto Correios' },
  carrefour: LOC_NG,
  mcdonalds: LOC_NG,
  algar:     { busca: 'algar - {UF}', opcao: 'Projeto EILD Algar - {UF}' },
  diversos:  LOC_NG
};

const FIXOS = {
  tipo: 'Restauração',
  servicoSgf: 'INTERNET',
  subServicoSgf: 'Indisponibilidade',
  servico: 'Internet',
  sla: '24 Horas 24x7',
  site: 'NGO - NAO GEOGRAFICO'
};

const FILA = 'NOC - ATACADO';
const ASSUNTO_NOTA = 'NOTA DE ENCAMINHAMENTO';

// ---------------- tipos de chamado ----------------
const TIPOS = {
  atacado: { nome: 'NOC Atacado' },
  suporte: { nome: 'Suporte TI (Engenharia)' }
};

// Suporte TI (Engenharia). Motivo = Sub serviço SGF = Serviço no OTRS.
const MOTIVOS = ['Notebook', 'Celular', 'Acessos', 'E-mails', 'Softwares', 'Outras'];
const SUPORTE = {
  filaCategoria: 'Service Desk',
  filaEncaminhar: 'ENG - SISTEMAS',
  equipe: 'Eng. Sistemas',
  fixos: {
    tipo: 'Solicitação',
    servicoSgf: 'SUPORTE TI (Engenharia)',
    sla: 'Sem SLA',
    site: 'NGO - NAO GEOGRAFICO',
    empresa: 'Grupo Arion'
  }
};

// ---------------- extração ----------------

// No corpo, só nomes completos: siglas curtas (BRAD, BB, CEF) aparecem em rótulos e listas.
const DETECTAR_CORPO = {
  fust: /NOC[_\s-]?FUST|\bINEP\b/i,
  bradesco: /BRADESCO/i,
  bb: /BANCO DO BRASIL|PROJETO BB\b/i,
  cef: /CAIXA ECON[OÔ]MICA|PROJETO CEF\b/i,
  correios: /CORREIOS/i,
  carrefour: /CARREFOUR/i,
  mcdonalds: /MC\s?DONALD|ARCOS DOURADOS/i,
  algar: /ALGAR TELECOM|EILD ALGAR|PROJETO ALGAR/i,
  diversos: /PROJETO DIVERSOS/i
};

function detectarCliente(titulo, texto) {
  for (const [id, c] of Object.entries(CLIENTES)) if (c.detectar.test(titulo)) return id;
  for (const [id, re] of Object.entries(DETECTAR_CORPO)) if (re.test(texto)) return id;
  return '';
}

// Correios, BB, CEF, Carrefour, Diversos: sempre Claro. FUST: Vivo. Algar: Algar.
// Bradesco: Vivo ou Telmex. McDonald's: Vivo ou Claro. "VIVO" no chamado → Telefônica.
function detectarOperadora(cliente, texto) {
  const c = CLIENTES[cliente];
  if (!c) return '';
  if (c.operadoras.length === 1) return c.operadoras[0];
  if (/\bVIVO\b/i.test(texto)) return 'telefonica';
  if (cliente === 'bradesco') return /TELMEX|EMBRATEL/i.test(texto) ? 'telmex' : '';
  if (cliente === 'mcdonalds') return /\bCLARO\b/i.test(texto) ? 'claro' : 'telefonica';
  return c.operadoras[0];
}

function primeiro(fontes, re) {
  for (const f of fontes) {
    const m = f && f.match(re);
    if (m) return (m[1] || m[0]).trim();
  }
  return '';
}

function detectarUF(titulo, texto, designacao) {
  const cand = [
    primeiro([titulo, texto], /ALGAR\s*-\s*([A-Z]{2})\b/i),
    primeiro([designacao], /^VIVO\.([A-Z]{2})\./i),
    primeiro([titulo], /\s-\s([A-Z]{2})\s-\s/),
    primeiro([texto], /\s-\s*([A-Z]{2})\s+CEP/i)
  ].map(s => s.toUpperCase());
  return cand.find(u => UFS.includes(u)) || '';
}

function extrair({ titulo = '', texto = '' }) {
  const fontes = [titulo, texto];
  const cliente = detectarCliente(titulo, texto);
  const operadora = detectarOperadora(cliente, texto + '\n' + titulo);

  // FUST: designação no formato VIVO.UF.CÓDIGO (ex.: VIVO.BA.BLIVR000017).
  const vivo = primeiro(fontes, /\b(VIVO\.[A-Z]{2}\.[A-Z0-9]+)\b/i).toUpperCase();
  const bl = primeiro(fontes, /\b(B[DL]\d{6,})\b/i).toUpperCase();
  const designacao =
    (cliente === 'fust' ? vivo || bl : bl || vivo) ||
    primeiro(fontes, /DESIGNA(?:[CÇ][AÃ]O|DOR)\s*:?\s*([A-Z0-9][A-Z0-9./_-]{4,})/i);

  const valores = {
    ci: primeiro(fontes, /\bC\.?I\.?\s*:?\s*(\d{4,})/i) || primeiro(fontes, /\bREC(?:\s*ID)?\s*:?\s*(\d{4,})/i) || primeiro(fontes, /CHAMADO INTERNO\s*:?\s*(\d{4,})/i),
    inc: primeiro(fontes, /\bINC\s*:?\s*(\d{6,})\b/i),
    agencia: primeiro(fontes, /\bAG(?:[EÊ]NCIA)?\.?\s*(?:N[º°o]\.?)?\s*:?\s*(\d{3,5})\b/i),
    sigla: primeiro(fontes, /SIGLA\s*:?\s*([A-Z0-9]{2,10})\b/i),
    brad: primeiro(fontes, /\bBRAD\s*:?\s*(\d{2,6})\b/i),
    np: primeiro(fontes, /\bNP\s*:?\s*(\d{3,})\b/i)
  };

  const d = { tipoCh: 'atacado', cliente, operadora, designacao, uf: '', op: '' };
  // Reincidência e Cancelamento: só máscara, sem cliente/localidade.
  const so = /REINCID/i.test(titulo) ? 'reinc' : /CANCELAMENTO/i.test(titulo) ? 'canc' : '';
  if (so) {
    d.grupo = so; d.cliente = '';
    d.operadora = operadoraDoTexto(texto + '\n' + titulo);
    d.op = primeiro([titulo, texto], /\bOP\s*:\s*([^\n]+?)(?=\s+-\s|\n|$)/i).toUpperCase();
  }
  if (cliente === 'algar') d.uf = detectarUF(titulo, texto, designacao);
  d.identificador = valores[tipoSufixo(d)] || '';
  return completar(d);
}

function operadoraDoTexto(t) {
  if (/TELMEX|EMBRATEL/i.test(t)) return 'telmex';
  if (/\bVIVO\b|TELEFONICA|TELEF[ÔO]NICA/i.test(t)) return 'telefonica';
  if (/ALGAR/i.test(t)) return 'algar';
  if (/\bCLARO\b/i.test(t)) return 'claro';
  return '';
}

// ---------------- máscara ----------------

function tipoSufixo(d) {
  if (d.grupo && MODELOS[d.grupo] && MODELOS[d.grupo].sufixo) return MODELOS[d.grupo].sufixo;
  const c = CLIENTES[d.cliente];
  if (!c) return 'ci';
  return typeof c.sufixo === 'string' ? c.sufixo : (c.sufixo[d.operadora] || 'ci');
}

function localidade(d) {
  const c = CLIENTES[d.cliente];
  return c ? c.localidade.replace('{UF}', d.uf || '??') : '';
}

// Operadoras aceitas para o modelo/cliente atual.
function operadorasPermitidas(d) {
  const g = MODELOS[d.grupo];
  if (g && g.operadoras) return g.operadoras;
  const c = CLIENTES[d.cliente];
  return c ? c.operadoras : Object.keys(OPERADORAS);
}

function faltando(d) {
  const f = [];
  const c = CLIENTES[d.cliente];
  const soMascara = SO_MASCARA.includes(d.grupo);
  if (!d.grupo) f.push('modelo');
  if (!soMascara && !c) f.push('cliente');
  if (!d.operadora) f.push('operadora');
  else if (!operadorasPermitidas(d).includes(d.operadora)) f.push('operadora inválida para o cliente');
  if (d.grupo === 'canc' && !d.op) f.push('OP');
  if (!d.designacao) f.push('designação');
  if (!d.identificador) f.push(SUFIXOS[tipoSufixo(d)].rotulo.toLowerCase());
  if (d.cliente === 'algar' && !UFS.includes(d.uf)) f.push('UF');
  return f;
}

function mascara(d) {
  const op = OPERADORAS[d.operadora];
  const suf = SUFIXOS[tipoSufixo(d)].prefixo + d.identificador;
  if (d.grupo === 'reinc') return ['[REINCIDENCIA MONITORAMENTO]', op.mascara, 'BRADESCO', d.designacao, suf].join(' - ');
  if (d.grupo === 'canc') return ['NGO', op.mascara, 'CANCELAMENTO', 'INTERNET', 'OP:' + d.op, d.designacao, suf].join(' - ');
  const c = CLIENTES[d.cliente];
  const nomeOp = (c.mascaraOperadora && c.mascaraOperadora[d.operadora]) || op.mascara;
  return [c.prefixo, nomeOp, 'RESTAURAÇÃO', 'INTERNET', c.projeto, d.designacao, suf].join(' - ');
}

// Recalcula os campos derivados após qualquer edição.
function completar(d) {
  d.tipoCh = d.tipoCh === 'suporte' ? 'suporte' : 'atacado';
  if (d.tipoCh === 'suporte') {
    d.motivo = MOTIVOS.includes(d.motivo) ? d.motivo : 'Acessos';
    d.tipoSufixo = 'ci';
    d.faltando = [];
    d.mascara = `Grupo Arion - SOLICITAÇÃO - SUPORTE TI (Engenharia) - ${d.motivo}`;
    d.empresa = SUPORTE.fixos.empresa;
    return d;
  }
  // Modelo (grupo) e cliente andam juntos.
  if (!d.grupo) d.grupo = grupoDoCliente(d.cliente);
  const g = MODELOS[d.grupo];
  if (g && g.clientes) {
    if (g.clientes.length === 1) d.cliente = g.clientes[0];
    else if (!g.clientes.includes(d.cliente)) d.cliente = '';
  } else if (g) d.cliente = '';
  d.soMascara = SO_MASCARA.includes(d.grupo);
  d.tipoSufixo = tipoSufixo(d);
  // FUST: o chamado interno é sempre INC + código (aceita só os números).
  if (d.tipoSufixo === 'inc' && d.identificador) {
    d.identificador = 'INC' + String(d.identificador).toUpperCase().replace(/^INC\s*:?\s*/, '');
  }
  d.faltando = faltando(d);
  d.mascara = d.faltando.length ? '' : mascara(d);
  d.localidade = localidade(d);
  if (d.soMascara) { d.localidadeBusca = ''; d.localidadeOpcao = ''; d.empresa = ''; return d; }
  const lb = LOCALIDADE_BUSCA[d.cliente];
  const uf = d.uf || '';
  d.localidadeBusca = lb ? lb.busca.replace('{UF}', uf) : d.localidade;
  d.localidadeOpcao = lb ? (lb.opcao ? lb.opcao.replace('{UF}', uf) : null) : d.localidade;
  d.empresa = d.operadora ? OPERADORAS[d.operadora].empresa : '';
  return d;
}

// ---------------- textos ----------------

const esc = s => String(s || '').replace(/[&<>"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));

// Modelo escolhido: título em negrito, linha de traços separando a máscara.
function textoCategorizacao(d) {
  return '<p><strong>Arion - Central de Atendimento</strong><br>' +
    'Este ticket foi categorizado e encaminhado para a fila Service Desk.<br>' +
    '--------------------------------------------<br>' +
    'Mascara gerada<br>' +
    `${esc(d.mascara)}</p>`;
}

function textoCategorizacaoSuporte() {
  return '<p><strong>Arion - Central de Atendimento</strong><br>' +
    `Este ticket foi categorizado e encaminhado para a fila ${SUPORTE.filaCategoria}.</p>`;
}

function textoNotaSuporte() {
  return '<p><strong>Arion - Central de Atendimento</strong></p>' +
    `<p>Ticket encaminhado para a equipe:  ${SUPORTE.equipe}</p>` +
    '<p>Gentileza prosseguir com a tratativa.</p>';
}

function textoNota() {
  return '<p><strong>Arion - Central de Atendimento</strong></p>' +
    `<p>Ticket encaminhado para a fila: ${FILA}</p>` +
    '<p>Atividade: Aguardando atuação da operadora de transito (ISP)</p>' +
    '<p>Gentileza acompanhar diariamente a tratativa até sua conclusão.</p>';
}

const api = { LOCALIDADE_BUSCA, NG, UFS, OPERADORAS, SUFIXOS, CLIENTES, FIXOS, FILA, ASSUNTO_NOTA, TIPOS, MOTIVOS, SUPORTE, MODELOS, SO_MASCARA, extrair, completar, tipoSufixo, operadorasPermitidas, textoCategorizacao, textoCategorizacaoSuporte, textoNota, textoNotaSuporte };
if (typeof self !== 'undefined') self.Regras = api;
if (typeof module !== 'undefined') module.exports = api;

})();
