/* alpha-mascara.js — comportamento do visual minimalista (Alpha).
 * Só mostra/esconde e resume; a lógica continua no popup.js.
 */
(function () {
  const $ = (id) => document.getElementById(id);
  const tabService = document.querySelector('.tab-service');
  const tabSettings = document.querySelector('.tab-settings');
  const emConfig = () => tabSettings.classList.contains('active');

  // Engrenagem: alterna Configurações ⇄ Service Aide.
  $('aCfg').addEventListener('click', () => (emConfig() ? tabService : tabSettings).click());
  $('aVoltar').addEventListener('click', () => tabService.click());
  new MutationObserver(() => { $('aSub').textContent = emConfig() ? 'Configurações' : 'Service Aide'; })
    .observe(tabSettings, { attributes: true, attributeFilter: ['class'] });

  // Editar: mostra os campos capturados.
  let editando = false;
  $('aEdit').addEventListener('click', () => {
    editando = !editando;
    render();
    if (editando) $('serviceTitulo').focus();
  });

  const v = (id) => ($(id).value || '').trim();
  const longo = new Set(['Descrição', 'Título']);
  const esc = (t) => String(t).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  function render() {
    const linhas = [
      ['Título', v('serviceTitulo')],
      ['Chamado', v('serviceChamado')],
      ['Solicitante', [v('serviceSolicitante'), v('serviceRamal') && 'r. ' + v('serviceRamal')].filter(Boolean).join(' · ')],
      ['E-mail', v('serviceEmail')],
      ['Local', v('serviceLocalizacao')],
      ['SLA', v('serviceSLA')],
      ['Descrição', v('serviceDescricao')],
    ].filter(([, x]) => x);
    // Visualização completa: nada cortado; textos longos ocupam a linha toda.
    $('aResumo').innerHTML = linhas.map(([k, x]) => longo.has(k) && x.length > 28
      ? `<dt class="a-kv__full">${k}</dt><dd class="a-kv__full">${esc(x)}</dd>`
      : `<dt>${k}</dt><dd>${esc(x)}</dd>`).join('');
    $('aResumo').hidden = editando || !linhas.length;
    $('aVazio').hidden = editando || !!linhas.length;
    $('aCampos').hidden = !editando;
    $('aEdit').textContent = editando ? 'Concluir' : 'Editar';

    const ch = v('serviceChamado');
    $('aCtxTxt').textContent = ch ? `Chamado ${ch} capturado` : 'Abra o chamado no Service Aide';
    $('aCtxDot').classList.toggle('a-dot--off', !ch);

    const m = $('serviceMaskOutput');
    $('aMask').classList.toggle('ok', !!m.value.trim());
    m.style.height = 'auto';
    m.style.height = Math.max(60, m.scrollHeight) + 'px';
  }

  // Os campos mudam pela captura (sem evento): confere a cada meio segundo.
  let ultimo = '';
  setInterval(() => {
    const atual = ['serviceTitulo', 'serviceChamado', 'serviceSolicitante', 'serviceRamal', 'serviceEmail', 'serviceLocalizacao', 'serviceSLA', 'serviceDescricao', 'serviceMaskOutput'].map(v).join('|');
    if (atual !== ultimo) { ultimo = atual; render(); }
  }, 500);
  document.addEventListener('input', render);
  render();
})();
