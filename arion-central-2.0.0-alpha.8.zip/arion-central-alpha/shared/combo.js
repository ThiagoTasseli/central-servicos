/* shared/combo.js
 * Todo <select> vira uma caixa onde dá para digitar e filtrar as opções.
 * O <select> original continua na página (escondido): o resto do código segue
 * lendo/gravando .value e ouvindo "input"/"change" como antes.
 */
(function () {
if (window.__arionCombo) return;
window.__arionCombo = true;

const CSS = `
.acombo{position:relative;display:block;width:100%;min-width:0;flex:1 1 auto}
.acombo .acombo__input{width:100%;box-sizing:border-box;background-image:none!important;padding-right:30px;text-overflow:ellipsis;cursor:text}
.acombo::after{content:"";position:absolute;right:11px;top:50%;width:6px;height:6px;margin-top:-5px;border-right:1.6px solid #a5a7ac;border-bottom:1.6px solid #a5a7ac;transform:rotate(45deg);pointer-events:none}
.acombo--off .acombo__input{opacity:.6;cursor:not-allowed}
.acombo__list{position:absolute;left:0;right:0;top:calc(100% + 4px);z-index:9999;max-height:220px;overflow:auto;margin:0;padding:4px;list-style:none;
 background:var(--ds-surface,var(--input-bg,#232428));border:1px solid var(--ds-border,var(--border,#3a3c42));border-radius:8px;
 box-shadow:0 8px 24px rgba(0,0,0,.35);font:13px var(--ds-font,system-ui,sans-serif);color:var(--ds-text,var(--text,#f1f2f4))}
.acombo__list[hidden]{display:none}
.acombo__item{padding:7px 9px;border-radius:6px;cursor:pointer;overflow-wrap:anywhere}
.acombo__item.is-active{background:var(--ds-teal-soft,var(--arion-teal-soft,rgba(0,191,154,.16)))}
.acombo__item.is-sel{font-weight:700}
.acombo__vazio{padding:8px 9px;color:var(--ds-text-faint,#7c7e83)}
`;
const st = document.createElement('style');
st.textContent = CSS;
document.head.appendChild(st);

const norm = s => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();
const textoOpcao = o => (o.text || '').replace(/ /g, ' ').trim();

function melhorar(sel) {
  if (sel.__combo || sel.multiple || sel.size > 1) return;
  sel.__combo = true;

  const wrap = document.createElement('div');
  wrap.className = 'acombo';
  const inp = document.createElement('input');
  inp.type = 'text';
  inp.className = (sel.className ? sel.className + ' ' : '') + 'acombo__input';
  inp.autocomplete = 'off';
  inp.spellcheck = false;
  inp.setAttribute('role', 'combobox');
  inp.setAttribute('aria-autocomplete', 'list');
  if (sel.id) inp.setAttribute('aria-label', (document.querySelector(`label[for="${sel.id}"]`) || sel.closest('label') || {}).textContent || sel.id);
  const lista = document.createElement('ul');
  lista.className = 'acombo__list';
  lista.hidden = true;
  lista.setAttribute('role', 'listbox');

  sel.parentNode.insertBefore(wrap, sel);
  wrap.append(inp, lista, sel);   // input antes do select: o <label> passa a focar o input
  sel.style.display = 'none';
  sel.tabIndex = -1;
  // <label for="id">: clicar no rótulo foca o campo digitável (o id fica no <select>).
  if (sel.id) document.querySelectorAll(`label[for="${sel.id}"]`).forEach(l => l.addEventListener('click', e => {
    // Botões dentro do rótulo (ex.: engrenagem) fazem só a própria ação.
    if (e.target.closest('button, a, input, select, textarea')) return;
    if (!l.contains(inp)) { e.preventDefault(); inp.focus(); }
  }));

  let aberto = false, ativo = -1, itens = [];

  const atual = () => sel.options[sel.selectedIndex];
  const sincronizar = () => {
    if (aberto) return;
    const o = atual();
    inp.value = o ? textoOpcao(o) : '';
    inp.disabled = sel.disabled;
    wrap.classList.toggle('acombo--off', sel.disabled);
  };

  function montar(filtro) {
    const f = norm(filtro);
    itens = [...sel.options].filter(o => !o.disabled && !o.hidden && (!f || norm(textoOpcao(o)).includes(f)));
    lista.innerHTML = '';
    if (!itens.length) {
      const v = document.createElement('li');
      v.className = 'acombo__vazio';
      v.textContent = 'Nada encontrado';
      lista.appendChild(v);
      ativo = -1;
      return;
    }
    itens.forEach((o, i) => {
      const li = document.createElement('li');
      li.className = 'acombo__item' + (o === atual() ? ' is-sel' : '');
      li.setAttribute('role', 'option');
      li.textContent = textoOpcao(o) || '—';
      li.addEventListener('mousedown', e => { e.preventDefault(); escolher(i); });
      li.addEventListener('mousemove', () => marcar(i, false));
      lista.appendChild(li);
    });
    const iSel = itens.indexOf(atual());
    marcar(f ? 0 : Math.max(iSel, 0), true);
  }

  function marcar(i, rolar) {
    ativo = i;
    [...lista.querySelectorAll('.acombo__item')].forEach((li, k) => {
      li.classList.toggle('is-active', k === i);
      if (k === i && rolar) li.scrollIntoView({ block: 'nearest' });
    });
  }

  function abrir() {
    if (sel.disabled) return;
    aberto = true;
    montar('');
    lista.hidden = false;
  }

  function fechar() {
    aberto = false;
    lista.hidden = true;
    sincronizar();
  }

  function escolher(i) {
    const o = itens[i];
    if (!o) return;
    if (sel.value !== o.value) {
      setValor.call(sel, o.value);
      sel.dispatchEvent(new Event('input', { bubbles: true }));
      sel.dispatchEvent(new Event('change', { bubbles: true }));
    }
    fechar();
    inp.blur();
  }

  inp.addEventListener('focus', () => { abrir(); inp.select(); });
  inp.addEventListener('click', () => { if (!aberto) { abrir(); } inp.select(); });
  inp.addEventListener('blur', () => setTimeout(fechar, 0));
  inp.addEventListener('input', e => { e.stopPropagation(); if (!aberto) { aberto = true; lista.hidden = false; } montar(inp.value); });
  inp.addEventListener('change', e => e.stopPropagation());
  inp.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown') { e.preventDefault(); if (!aberto) abrir(); else marcar(Math.min(ativo + 1, itens.length - 1), true); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); marcar(Math.max(ativo - 1, 0), true); }
    else if (e.key === 'Enter') { if (aberto) { e.preventDefault(); e.stopPropagation(); escolher(ativo); } }
    else if (e.key === 'Escape') { if (aberto) { e.preventDefault(); e.stopPropagation(); fechar(); inp.blur(); } }
    else if (e.key === 'Tab') fechar();
  });

  // Código que grava sel.value / selectedIndex: reflete na caixa.
  const setValor = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value').set;
  const getValor = Object.getOwnPropertyDescriptor(HTMLSelectElement.prototype, 'value').get;
  Object.defineProperty(sel, 'value', {
    configurable: true,
    get() { return getValor.call(sel); },
    set(v) { setValor.call(sel, v); sincronizar(); }
  });
  new MutationObserver(sincronizar).observe(sel, { childList: true, subtree: true, attributes: true, attributeFilter: ['disabled', 'selected'], characterData: true });
  sel.addEventListener('change', sincronizar);
  sincronizar();
}

function varrer(raiz) {
  (raiz.querySelectorAll ? raiz.querySelectorAll('select') : []).forEach(melhorar);
}

function iniciar() {
  varrer(document);
  new MutationObserver(ms => ms.forEach(m => m.addedNodes.forEach(n => {
    if (n.nodeType !== 1) return;
    if (n.tagName === 'SELECT') melhorar(n); else varrer(n);
  }))).observe(document.body, { childList: true, subtree: true });
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', iniciar); else iniciar();
})();
