/* aeroportos.js — aba "Aeroportos" da Categorização (alpha.25).
 * Incidente de aeroporto:
 *   1. Categorizar: igual ao Atacado (Restauração · INTERNET · Indisponibilidade · Internet · 24x7).
 *      Aeroporto dos POPs → Localidade e Site do POP. Outro → Não Geográficos (Aeroportos) e Site NGO.
 *      Título e Assunto = o título que veio.
 *   2. Fila: você escolhe. Nota de encaminhamento + Mover (com confirmação).
 */
(function () {
  const $ = (id) => document.getElementById(id);
  const R = self.Regras;
  const M = window.ArionModal;
  const get = (k) => new Promise((r) => chrome.storage.local.get(k, (v) => r(v[k])));
  const set = (k, v) => new Promise((r) => chrome.storage.local.set({ [k]: v }, r));
  const msg = (t, erro) => { try { window.__noc.toast(t, erro); } catch (_) {} };
  const tk = () => (window.__noc && window.__noc.ticket) || null;
  const norm = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[‒-―−]/g, '-').replace(/\s+/g, ' ').toLowerCase();

  let filas = R.FILAS_OTRS.slice();
  let st = { cat: '', enc: '', fila: '' };   // cat: ''|'ok' · enc: ''|'nota'|'ok'
  let atualId = '';

  // ---------- modo ----------
  const bAero = document.querySelector('#aTipo button[data-modo="aero"]');
  function modo(on, salvar = true) {
    document.body.classList.toggle('modo-aero', on);
    $('aero').hidden = !on;
    bAero.classList.toggle('on', on);
    if (on) {
      document.body.classList.remove('modo-comercial', 'modo-enc');
      $('comercial').hidden = true; $('encaminhar').hidden = true;
      document.querySelectorAll('#aTipo button[data-modo="comercial"], #aTipo button[data-modo="encaminhar"]').forEach((b) => b.classList.remove('on'));
      carregarFilas();
      atualId = ''; trocouTicket();
    }
    if (salvar) set('noc_modo', on ? 'aeroportos' : '');
  }
  bAero.addEventListener('click', () => modo(true));
  document.querySelectorAll('#aTipo button:not([data-modo="aero"])').forEach((b) => b.addEventListener('click', () => modo(false, false)));

  // ---------- localidades ----------
  const OPCOES = [...R.AEROPORTOS.map((a) => a.localidade), R.AERO_NG.localidade];
  $('ae-loc').innerHTML = OPCOES.map((o) => `<option>${M.esc(o)}</option>`).join('');

  async function carregarFilas() {
    const cache = await get('otrs_filas');
    if (cache && cache.lista && cache.lista.length) filas = cache.lista;
  }

  // ---------- fila (busca) ----------
  const inp = $('ae-fila'), ul = $('ae-list');
  let ativo = 0, achadas = [];
  function sugerir() {
    const q = norm(inp.value.trim());
    achadas = q ? filas.filter((f) => norm(f).includes(q)).slice(0, 12) : filas.slice(0, 12);
    ativo = 0;
    ul.innerHTML = achadas.length
      ? achadas.map((f, i) => `<li role="option" data-i="${i}" class="${i === 0 ? 'on' : ''}">${M.esc(f)}</li>`).join('')
      : '<li class="vazio">Nenhuma fila com esse nome</li>';
    ul.hidden = false;
  }
  function escolherFila(f) { inp.value = f; ul.hidden = true; if (st.fila && st.fila !== f) { st.cat = ''; st.enc = ''; } st.fila = f; salvar(); render(); }
  inp.addEventListener('focus', sugerir);
  inp.addEventListener('input', () => { sugerir(); if (st.fila && inp.value !== st.fila) { st.fila = ''; render(); } });
  inp.addEventListener('keydown', (e) => {
    if (ul.hidden) return;
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      ativo = Math.max(0, Math.min(achadas.length - 1, ativo + (e.key === 'ArrowDown' ? 1 : -1)));
      ul.querySelectorAll('li').forEach((li, i) => li.classList.toggle('on', i === ativo));
    } else if (e.key === 'Enter' && achadas[ativo]) { e.preventDefault(); escolherFila(achadas[ativo]); }
    else if (e.key === 'Escape') ul.hidden = true;
  });
  ul.addEventListener('mousedown', (e) => { const li = e.target.closest('li[data-i]'); if (li) { e.preventDefault(); escolherFila(achadas[+li.dataset.i]); } });
  inp.addEventListener('blur', () => setTimeout(() => (ul.hidden = true), 120));

  // ---------- estado por chamado ----------
  const chave = () => 'aero_' + (tk() && tk().ticketId);
  const salvar = () => tk() && set(chave(), st);
  function preencher(t) {
    const a = R.aeroportoDo(t.titulo, t.texto);
    $('ae-loc').value = a.localidade;
    $('ae-loc').dispatchEvent(new Event('change'));
    $('ae-titulo').value = R.tituloAeroporto(t.titulo);
    $('ae-desig').value = R.designacaoDo(t.titulo || '', t.texto || '');
    $('ae-emp').value = '';
    $('ae-det').textContent = a.sigla ? `✓ ${a.sigla} é POP` : 'Sem POP: Não Geográfico';
    $('ae-det').className = 'c-b ' + (a.sigla ? 'ok' : 'no');
  }
  async function trocouTicket() {
    const t = tk();
    const id = t && t.ticketId ? t.ticketId : '';
    if (id === atualId) return;
    atualId = id;
    st = { cat: '', enc: '', fila: '', ...((id && (await get(chave()))) || {}) };
    if (t) preencher(t);
    inp.value = st.fila || '';
    render();
  }

  function dados() {
    const a = R.aeroPorLocalidade($('ae-loc').value);
    const titulo = $('ae-titulo').value.trim();
    return {
      a,
      d: {
        localidade: a.localidade, localidadeOpcao: a.localidade,
        localidadeBusca: a.sigla || 'aeroportos',
        site: a.site, empresa: $('ae-emp').value.trim(),
        designacao: $('ae-desig').value.trim().toUpperCase(),
        mascara: titulo,
      },
    };
  }

  function render() {
    const t = tk();
    $('ae-dot').classList.toggle('a-dot--off', !t);
    $('ae-ctx-t').textContent = t ? `Ticket#${t.numero || t.ticketId}` : 'Abra o chamado no OTRS';
    const { a, d } = dados();
    $('ae-site').textContent = a.sigla ? `Site do POP ${a.sigla}` : 'NGO - NAO GEOGRAFICO';
    const f = st.fila;
    const pronto = !!t && !!d.mascara && !!f;

    // Botões iguais ao Atacado: 1 Categorizar · 2 Encaminhar (nota → Mover).
    const bCat = $('ae-cat');
    if (!bCat.classList.contains('carregando')) {
      bCat.disabled = !pronto;
      bCat.className = 'a-btn ' + (st.cat === 'ok' ? 'a-btn--done' : 'a-btn--pri');
      bCat.innerHTML = st.cat === 'ok' ? '<span class="a-n">✓</span>Categorizado' : '<span class="a-n">1</span>Categorizar';
      bCat.title = st.cat === 'ok' ? 'Clique para categorizar de novo' : '';
    }
    const bEnc = $('ae-enc');
    if (!bEnc.classList.contains('carregando')) {
      bEnc.disabled = !pronto || st.enc === 'ok';
      bEnc.className = 'a-btn ' + (st.enc === 'ok' ? 'a-btn--done' : st.enc === 'nota' ? 'a-btn--perigo' : 'a-btn--acc');
      bEnc.innerHTML = st.enc === 'ok' ? '<span class="a-n">✓</span>Encaminhado'
        : st.enc === 'nota' ? 'Mover para a fila' : '<span class="a-n">2</span>Encaminhar';
      bEnc.title = f ? `Fila: ${f}` : '';
    }
    $('ae-fila-txt').textContent = !f ? 'Escolha a fila de destino.'
      : st.enc === 'nota' ? `Clique em Mover para enviar à fila ${f}.` : `Fila: ${f}`;
  }
  $('ae-loc').addEventListener('change', render);
  $('ae-titulo').addEventListener('input', render);
  $('ae-limpar').onclick = async () => {
    const t = tk();
    st = { cat: '', enc: '', fila: '' };
    inp.value = '';
    if (t) { preencher(t); await salvar(); }
    render();
  };

  const notaHtml = (f) => R.textoNotaEquipe(f);
  const carregando = (b, on, txt) => { b.classList.toggle('carregando', on); if (on) { b.disabled = true; b.textContent = txt; } };

  // ---------- ação ----------
  $('ae-cat').onclick = async () => {
    const t = tk();
    if (!t) return;
    const { d } = dados();
    if (!d.mascara) return msg('Título vazio', true);
    if (!filas.includes(st.fila)) { inp.focus(); return msg('Escolha a fila da lista', true); }
    const b = $('ae-cat');
    carregando(b, true, 'Categorizando…');
    const r = await OTRS.categorizarAeroporto(t.ticketId, {
      d, fixos: R.FIXOS, texto: R.textoCategorizacaoAero(d, st.fila), enviar: $('ae-auto').checked,
    }).catch((e) => ({ ok: false, erro: e.message }));
    carregando(b, false);
    if (!r || r.erro || !r.ok) {
      render();
      const f = r && r.falhas && r.falhas.length ? 'Não preencheu: ' + r.falhas.join(', ') : '';
      return msg((r && r.erro) || f || 'Não categorizou', true);
    }
    st.cat = 'ok'; await salvar(); render();
    msg(r.enviado ? `Categorizado${r.siteUsado ? ' · Site ' + r.siteUsado : ''}` : 'Preenchido: confira e clique em Enviar no OTRS.');
  };

  $('ae-enc').onclick = async () => {
    const t = tk();
    if (!t || !st.fila) return;
    if (!filas.includes(st.fila)) return msg('Escolha uma fila da lista', true);
    const b = $('ae-enc');

    if (!st.enc) {
      carregando(b, true, 'Enviando nota…');
      const r = await OTRS.nota(t.ticketId, { assunto: R.ASSUNTO_NOTA, texto: notaHtml(st.fila), enviar: $('ae-auto').checked, isp: false })
        .catch((e) => ({ ok: false, erro: e.message }));
      carregando(b, false);
      if (!r || r.erro || !r.ok) { render(); return msg((r && (r.erro || (r.falhas || []).join(', '))) || 'Nota não preenchida', true); }
      st.enc = 'nota'; await salvar(); render();
      msg(r.enviado ? 'Nota enviada. Agora clique em Mover.' : 'Nota preenchida: confira e clique em Enviar no OTRS.');
      return;
    }

    if (st.enc === 'nota') {
      const ok = await M.confirmar({
        titulo: `Mover para ${st.fila}?`,
        html: 'O chamado sai da fila atual. <b>Não tem desfazer.</b>',
        ok: 'Mover', perigo: true,
      });
      if (!ok) return;
      carregando(b, true, 'Movendo…');
      const r = await OTRS.mover(t.ticketId, st.fila).catch((e) => ({ ok: false, erro: e.message }));
      carregando(b, false);
      if (!r || !r.ok) { render(); return msg((r && (r.erro || (r.falhas || []).join(', '))) || 'Não moveu', true); }
      st.enc = 'ok'; await salvar(); render();
      msg(`Movido para ${st.fila}`);
    }
  };

  // ---------- início ----------
  setInterval(trocouTicket, 800);
  // Mesmo "Enviar automaticamente" do Atacado (padrão ligado).
  get('auto').then((v) => { $('ae-auto').checked = v === undefined ? true : !!v; });
  $('ae-auto').addEventListener('change', () => set('auto', $('ae-auto').checked));
  chrome.storage.onChanged.addListener((ch, area) => { if (area === 'local' && ch.auto) $('ae-auto').checked = !!ch.auto.newValue; });
  render();
  get('noc_modo').then((m) => { if (m === 'aeroportos') modo(true, false); });
})();
