/* modules/regras.js
 * Regras de negócio do NOC: clientes, operadoras, máscara e textos
 * (Atacado e Suporte TI (Engenharia)).
 * Para ajustar um texto exato (ex.: "CLARO S.A" × "CLARO S.A."), mude só aqui.
 */
(function () {

const NG = 'Não Geográficos (Urbanos)';
const UFS = 'AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO'.split(' ');

// mascara: texto da operadora na máscara.
// empresa: texto digitado em "Empresa (Razão social)" e "Empresa (Nome fantasia)".
const OPERADORAS = {
  claro:      { nome: 'Claro',             mascara: 'CLARO S.A.',             empresa: 'CLARO S.A' },
  telefonica: { nome: 'Telefônica (Vivo)', mascara: 'TELEFONICA BRASIL S.A.', empresa: 'TELEFONICA BRASIL S.A' },
  telmex:     { nome: 'Telmex',            mascara: 'TELMEX',                 empresa: 'TELMEX DO BRASIL S/A' },
  algar:      { nome: 'Algar Telecom',     mascara: 'ALGAR TELECOM',          empresa: 'ALGAR TELECOM' }
};

// Tipos de identificador no fim da máscara.
const SUFIXOS = {
  ci:      { rotulo: 'Chamado interno',    prefixo: 'CI: ' },
  inc:     { rotulo: 'Chamado Vivo (INC)', prefixo: '' },
  agencia: { rotulo: 'BRAD',               prefixo: 'BRAD: ' },
  sigla:   { rotulo: 'Sigla',              prefixo: 'SIGLA: ' },
  brad:    { rotulo: 'BRAD',               prefixo: 'BRAD:' },
  np:      { rotulo: 'NP',                 prefixo: 'NP:' }
};

// Modelos de máscara. 'rest' = Restauração (usa o cliente). Os outros só geram a máscara.
//  reinc: [REINCIDENCIA MONITORAMENTO] - OPERADORA - BRADESCO - DESIGNAÇÃO - BRAD:nº
//  canc:  NGO - OPERADORA - CANCELAMENTO - INTERNET - OP:operadora - DESIGNAÇÃO - NP:nº
const MODELOS = {
  ng:    { nome: 'Restauração · Não Geográficos (Urbanos)', modelo: 'rest', clientes: ['carrefour', 'mcdonalds', 'mcdcnf', 'algar', 'diversos'] },
  brad:  { nome: 'Restauração · Bradesco',                  modelo: 'rest', clientes: ['bradesco'] },
  proj:  { nome: 'Restauração · Projetos BB, CEF, Correios e FUST', modelo: 'rest', clientes: ['bb', 'cef', 'correios', 'fust'] },
  reinc: { nome: 'Reincidência · Bradesco',                 modelo: 'reinc', operadoras: ['telmex', 'telefonica'], sufixo: 'brad' },
  canc:  { nome: 'Cancelamento',                            modelo: 'canc',  operadoras: ['telefonica', 'claro', 'telmex', 'algar'], sufixo: 'np' },
  cancng: { nome: 'Cancelar Serviços · NGO', modelo: 'cancng' },
  cmdb:   { nome: 'Solicitação · Cadastro no CMDB', modelo: 'cmdb' }
};
const SO_MASCARA = ['reinc', 'canc'];
const grupoDoCliente = c => Object.keys(MODELOS).find(g => (MODELOS[g].clientes || []).includes(c)) || '';

// Ordem importa: o primeiro cliente encontrado vence (título antes do corpo).
const CLIENTES = {
  fust:      { nome: 'Projeto FUST',      localidade: 'Projeto FUST', prefixo: 'Projeto FUST',                 projeto: 'PROJETO FUST',      operadoras: ['telefonica'],          sufixo: 'inc',                                   detectar: /\bFUST\b|\bINEP\b/i },
  bradesco:  { nome: 'BRAD (Bradesco)',   localidade: 'BRAD',              prefixo: 'BRAD',             projeto: 'BRADESCO',          operadoras: ['telefonica', 'telmex'], sufixo: { telefonica: 'agencia', telmex: 'ci' }, detectar: /BRADESCO|\bBRAD\b/i },
  bb:        { nome: 'Projeto BB',        localidade: 'Projeto BB',        prefixo: 'Projeto BB',       projeto: 'PROJETO BB',        operadoras: ['claro'],               sufixo: 'ci',                                    detectar: /PROJETO BB|BANCO DO BRASIL/i },
  cef:       { nome: 'Projeto CEF',       localidade: 'Projeto CEF',       prefixo: 'Projeto CEF',      projeto: 'PROJETO CEF',       operadoras: ['claro'],               sufixo: 'ci',                                    detectar: /PROJETO CEF|CAIXA ECON|\bCEF\b/i },
  correios:  { nome: 'Projeto Correios',  localidade: 'Projeto Correios',  prefixo: 'Projeto Correios', projeto: 'PROJETO CORREIOS',  operadoras: ['claro'],               sufixo: 'ci',                                    detectar: /CORREIOS|\bECT\b/i },
  carrefour: { nome: 'Projeto Carrefour', localidade: NG, prefixo: NG,                 projeto: 'PROJETO CARREFOUR', operadoras: ['claro'],               sufixo: 'ci',                                    detectar: /CARREFOUR/i },
  mcdonalds: { nome: 'Arcos Dourados',    localidade: NG,    prefixo: NG,                 projeto: 'ARCOS DOURADOS',    operadoras: ['telefonica', 'claro'], sufixo: 'sigla',                                 mascaraOperadora: { claro: 'CLARO.' }, detectar: /MC\s?DONALD|ARCOS DOURADOS/i },
  // Arcos Dourados em Confins (cliente POP): igual ao Arcos Dourados; só a fila do Encaminhar muda.
  mcdcnf:    { nome: 'Arcos Dourados - CNF', localidade: NG, prefixo: NG,             projeto: 'ARCOS DOURADOS',    operadoras: ['telefonica', 'claro'], sufixo: 'sigla',                                 mascaraOperadora: { claro: 'CLARO.' }, detectar: /(?!)/, confins: true },
  algar:     { nome: 'Projeto Algar',     localidade: 'Projeto EILD Algar - {UF}', prefixo: 'Projeto EILD Algar - {UF}', semOperadora: true, projeto: 'PROJETO ALGAR',     operadoras: ['algar'],               sufixo: 'ci',                                    detectar: /ALGAR/i },
  diversos:  { nome: 'Projeto Diversos',  localidade: NG,  prefixo: NG,                 projeto: 'PROJETO DIVERSOS',  operadoras: ['claro'],               sufixo: 'ci',                                    detectar: /PROJETO DIVERSOS/i }
};

// Localidade no OTRS: digita "busca" e clica na opção "opcao".
// opcao null = clica na primeira da lista.
// Carrefour, McDonald's e Diversos: Localidade "Não Geográficos (Urbanos)";
// o Cliente só entra na máscara. Algar mantém "Projeto EILD Algar - UF".
const LOC_NG = { busca: 'urbanos', opcao: NG };
const LOCALIDADE_BUSCA = {
  fust:      { busca: 'fust',       opcao: 'Projeto FUST' },
  bradesco:  { busca: 'brad',       opcao: null },
  bb:        { busca: 'bb',         opcao: 'Projeto BB' },
  cef:       { busca: 'cef',        opcao: 'Projeto CEF' },
  correios:  { busca: 'correios',   opcao: 'Projeto Correios' },
  carrefour: LOC_NG,
  mcdonalds: LOC_NG,
  mcdcnf:    LOC_NG,
  algar:     { busca: 'algar - {UF}', opcao: 'Projeto EILD Algar - {UF}' },
  diversos:  LOC_NG
};

const FIXOS = {
  tipo: 'Restauração',
  servicoSgf: 'INTERNET',
  subServicoSgf: 'Indisponibilidade',
  servico: 'Internet',
  sla: '24 Horas 24x7',
  site: 'NGO - NAO GEOGRAFICO'
};

const FILA = 'NOC - ATACADO';

// ---------------- Cancelar Serviços (pedido do SGF) ----------------
// Chamado "Cancelar Serviços do Pedido: N" (fila ATENDIMENTO, criado por SGF Arion).
// POPs não têm esse processo: só categoriza quem não é POP → Localidade NGO.
const CANC_NGO = {
  fila: 'NOC - CANCELAMENTOS NGO',
  tipo: 'Cancelamento',
  enviarN1: 'Sim',
  isp: 'Não'
};
const POPS = [
  { nome: 'GRU',       re: /\bGRU\b|GUARULHOS/i },
  { nome: 'GIG',       re: /\bGIG\b|GALE[AÃ]O/i },
  { nome: 'BSB',       re: /\bBSB\b/i },
  { nome: 'CNF',       re: /\bCNF\b|BH AIRP|CONFINS/i },
  { nome: 'VCP',       re: /\bVCP\b|VIRACOPOS/i },
  { nome: 'FLN',       re: /\bFLN\b/i },
  { nome: 'MEA',       re: /\bMEA\b/i },
  { nome: 'VIX',       re: /\bVIX\b/i },
  { nome: 'POA',       re: /\bPOA\b/i },
  { nome: 'FOR',       re: /\bFOR\b/ },
  { nome: 'Congonhas', re: /CONGONHAS|\bCGH\b/i },
  { nome: 'Curitiba',  re: /CURITIBA|\bCWB\b/i },
  { nome: 'Cuiabá',    re: /CUIAB[AÁ]|\bCGB\b/i },
  { nome: 'NAT',       re: /\bNAT\b/ }
];
// ---------------- Cadastro no CMDB (NOC - ACESSOS E CADASTROS) ----------------
const NG_AERO = 'Não Geográficos (Aeroportos)';
const CMDB = {
  fila: 'NOC - ACESSOS E CADASTROS',
  isp: 'Não',
  fixos: { tipo: 'Solicitação', servicoSgf: 'INTERNET', servico: 'Internet', sla: '24 Horas 24x7', site: 'NGO - NAO GEOGRAFICO' },
  loc: {
    urbanos:    { opcao: NG,      busca: 'urbanos' },
    aeroportos: { opcao: NG_AERO, busca: 'aeroportos' }
  }
};
const ehCmdb = (titulo, texto) => /\bCMDB\b/i.test(titulo) || /\bCMDB\b/i.test(texto);
const ehAeroporto = (titulo, texto) => /AEROPORTO/i.test(titulo + '\n' + texto);
// Empresa do Cadastro no CMDB: só o nome da Rede parceira. Sem o campo, fica vazio (digita no painel).
function empresaDoTexto(titulo, texto) {
  return rotulo(texto, 'Rede [Pp]arceira') || '';
}

// ---------------- Arcos Dourados em Confins (cliente POP) ----------------
// Categorização igual; só o Encaminhar muda de fila (escolhida no painel).
const CNF_FILAS = ['OPE - FIELD SERVICES', 'NOC - SUPORTE AVANÇADO'];
const ehConfins = (titulo, texto) => /\bCNF\b|CONFINS/i.test(titulo + '\n' + texto);

// Localidades do OTRS (lista tirada do campo em 07/11/2026). Serve para conferir a opção.
const LOCALIDADES = [
  "Aeroporto de Aracaju (AJU)",
  "Aeroporto de Belém (BEL)",
  "Aeroporto de Boa Vista (BVB)",
  "Aeroporto de Brasília (BSB)",
  "Aeroporto de Campinas (VCP)",
  "Aeroporto de Confins (CNF)",
  "Aeroporto de Curitiba (CWB)",
  "Aeroporto de Florianópolis (FLN)",
  "Aeroporto de Fortaleza (FOR)",
  "Aeroporto de Foz do Iguaçu (IGU)",
  "Aeroporto de Guarulhos (GRU)",
  "Aeroporto de Macaé (MEA)",
  "Aeroporto de Natal (NAT)",
  "Aeroporto de Porto Alegre (POA)",
  "Aeroporto de Recife (REC)",
  "Aeroporto de Rio de Janeiro (GIG)",
  "Aeroporto de Salvador (SSA)",
  "Aeroporto de Tabatinga (TBT)",
  "Aeroporto de Vitória (VIX)",
  "Aeroporto Maestro Marinho Franco",
  "Arion",
  "BRAD",
  "CGH - Aeroporto de Congonhas",
  "Grupo Arion",
  "METRO AZ-Ana Rosa",
  "METRO AZ-Armênia",
  "METRO AZ-Carandiru",
  "METRO AZ-Conceição",
  "METRO AZ-Jabaquara",
  "METRO AZ-Japão-Liberdade",
  "METRO AZ-Jardim São Paulo",
  "METRO AZ-Luz",
  "METRO AZ-Parada Inglesa",
  "METRO AZ-Paraíso",
  "METRO AZ-Portuguesa-Tietê",
  "METRO AZ-Praça da Árvore",
  "METRO AZ-Santa Cruz",
  "METRO AZ-Santana",
  "METRO AZ-São Bento",
  "METRO AZ-São Joaquim",
  "METRO AZ-São Judas",
  "METRO AZ-Saúde",
  "METRO AZ-Sé",
  "METRO AZ-Tiradentes",
  "METRO AZ-Tucuruvi",
  "METRO AZ-Vergueiro",
  "METRO AZ-Vila Mariana",
  "METRO LV-Alto do Ipiranga",
  "METRO LV-Ana Rosa",
  "METRO LV-Brigadeiro",
  "METRO LV-Chácara Klabin",
  "METRO LV-Clínicas",
  "METRO LV-Consolação",
  "METRO LV-Sacomã",
  "METRO LV-Santos-Imigrantes",
  "METRO LV-Santuário N.S. de Fátima-Sumaré",
  "METRO LV-Tamanduateí",
  "METRO LV-Trianon-Masp",
  "METRO LV-Vila Madalena",
  "METRO LV-Vila Prudente",
  "METRO VE-Anhangabaú",
  "METRO VE-Artur Alvim",
  "METRO VE-Belém",
  "METRO VE-Brás",
  "METRO VE-Bresser-Moóca",
  "METRO VE-Carrão",
  "METRO VE-Corinthians-Itaquera",
  "METRO VE-Guilhermina-Esperança",
  "METRO VE-Marechal Deodoro",
  "METRO VE-Palmeiras-Barra Funda",
  "METRO VE-Patriarca",
  "METRO VE-Pedro II",
  "METRO VE-Penha",
  "METRO VE-República",
  "METRO VE-Santa Cecília",
  "METRO VE-Sé",
  "METRO VE-Tatuapé",
  "METRO VE-Vila Matilde",
  "Monitoramento ARION",
  "Não Geográficos (Aeroportos)",
  "Não Geográficos (Urbanos)",
  "Projeto Atacado - AC",
  "Projeto Atacado - AL",
  "Projeto Atacado - AM",
  "Projeto Atacado - AP",
  "Projeto Atacado - BA",
  "Projeto Atacado - CE",
  "Projeto Atacado - DF",
  "Projeto Atacado - ES",
  "Projeto Atacado - GO",
  "Projeto Atacado - MA",
  "Projeto Atacado - MG",
  "Projeto Atacado - MS",
  "Projeto Atacado - MT",
  "Projeto Atacado - PA",
  "Projeto Atacado - PB",
  "Projeto Atacado - PE",
  "Projeto Atacado - PI",
  "Projeto Atacado - PR",
  "Projeto Atacado - RJ",
  "Projeto Atacado - RN",
  "Projeto Atacado - RO",
  "Projeto Atacado - RR",
  "Projeto Atacado - RS",
  "Projeto Atacado - SC",
  "Projeto Atacado - SE",
  "Projeto Atacado - SP",
  "Projeto Atacado - TO",
  "Projeto BB",
  "Projeto CEF",
  "Projeto Correios",
  "Projeto EILD Algar - BA",
  "Projeto EILD Algar - DF",
  "Projeto EILD Algar - MA",
  "Projeto EILD Algar - MG",
  "Projeto EILD Algar - MS",
  "Projeto EILD Algar - PR",
  "Projeto EILD Algar - RO",
  "Projeto EILD Algar - RS",
  "Projeto EILD Algar - SC",
  "Projeto EILD Algar - SP",
  "Projeto EILD Algar- CE",
  "Projeto EILD IUH - AM",
  "Projeto EILD IUH - BA",
  "Projeto EILD IUH - ES",
  "Projeto EILD IUH - MA",
  "Projeto EILD IUH - MG",
  "Projeto EILD IUH - PA",
  "Projeto EILD IUH - RJ",
  "Projeto EILD IUH - SC",
  "Projeto EILD IUH - SP",
  "Projeto FUST",
  "Socicam - Aeroporto Alta Floresta (AFL)",
  "Socicam - Aeroporto de Cuiabá (CGB)",
  "Socicam - Aeroporto de Rondonópolis (ROO)",
  "Socicam - Aeroporto de Sinop (OPS)",
  "Transportation/Infraestrutura"
  ];
const normLoc = (t) => String(t || '').replace(/\u00a0/g, ' ').replace(/\s*-\s*/g, ' - ').replace(/\s+/g, ' ').trim().toUpperCase();
const localidadeExiste = (t) => !t || /\{UF\}/.test(t) || LOCALIDADES.some((l) => normLoc(l) === normLoc(t));

const ehCancNgo = (titulo, texto) =>
  /CANCELAR SERVI[CÇ]OS DO PEDIDO/i.test(titulo) ||
  (/Tipo do pedido:\s*Cancelamento/i.test(texto) && /Cancelamento de produtos:/i.test(texto));

// Rótulos do pedido do SGF. O texto pode vir sem quebras de linha (cópia do DOM),
// então o valor vai até a próxima quebra OU o próximo rótulo conhecido.
const ROTULOS_SGF = ['Pedido', 'Tipo do pedido', 'Raz[aã]o Social', 'Nome Fantasia', 'CNPJ', 'Contato', 'Telefone',
  'E-?mail', 'Respons[aá]vel', 'Cancelamento de produtos', 'Endere[cç]o', 'Cidade', 'Observa[cç][aã]o', 'Data'];
const PROX = '(?=\\s*(?:' + ROTULOS_SGF.join('|') + ')\\s*:|\\r?\\n|$)';
// Texto sem quebras: corta no próximo "Palavra:" colado (ex.: "NORTH TELECOMLocal: …"). Sensível a maiúsculas.
const corta = v => v.replace(/[A-ZÀ-Ú][a-zà-ú]{2,}(?:\s[A-Za-zÀ-ú]+){0,2}\s*:.*$/, '').trim();

function rotulo(texto, nome) {
  const t = String(texto || '');
  const m = t.match(new RegExp(nome + '\\s*:[ \\t]*([^\\n]*?)' + PROX, 'i'));
  if (m && corta(m[1])) return corta(m[1]);
  // Valor na linha de baixo (tabela).
  const m2 = t.match(new RegExp(nome + '\\s*:\\s*\\n\\s*([^\\n]+)', 'i'));
  return m2 && !/:\s*$/.test(m2[1]) ? m2[1].trim() : '';
}

function produtosCancelados(texto) {
  const t = String(texto || '');
  const i = t.search(/Cancelamento de produtos:/i);
  if (i < 0) return [];
  let sec = t.slice(i).replace(/^Cancelamento de produtos:\s*/i, '');
  const fim = sec.search(/\n\s*\n/);
  if (fim > 0) sec = sec.slice(0, fim);
  sec = sec.slice(0, 800);
  // Código do produto (ex.: IPSP10000025817) + descrição.
  const COD = /[A-Z]{2,6}\d{8,}/g;
  const pos = [...sec.matchAll(COD)].map(m => m.index);
  if (pos.length) return pos.map((p, k) => sec.slice(p, pos[k + 1]).split('\n')[0].trim())
    .map(l => l.replace(/\s{2,}.*$/, '').trim()).filter(Boolean);
  return sec.split('\n').map(l => l.trim()).filter(Boolean).slice(0, 5);
}

function extrairSgf(titulo, texto) {
  const pedido = (String(titulo).match(/Pedido:\s*(\d+)/i) || [])[1] || rotulo(texto, 'Pedido');
  const t1 = (String(titulo).match(/Cancelar Servi[cç]os do Pedido:\s*\d+/i) || [])[0] || '';
  const sgf = {
    pedido,
    tituloOriginal: t1 || (pedido ? `Cancelar Serviços do Pedido: ${pedido}` : ''),
    razao: rotulo(texto, 'Raz[aã]o Social'),
    fantasia: rotulo(texto, 'Nome Fantasia'),
    cnpj: rotulo(texto, 'CNPJ'),
    contato: rotulo(texto, 'Contato'),
    telefone: rotulo(texto, 'Telefone'),
    email: rotulo(texto, 'E-?mail'),
    responsavel: rotulo(texto, 'Respons[aá]vel'),
    produtos: produtosCancelados(texto)
  };
  const alvo = [sgf.razao, sgf.fantasia, ...sgf.produtos].join('\n');
  const pop = POPS.find(p => p.re.test(alvo));
  sgf.pop = pop ? pop.nome : '';
  return sgf;
}
// ---------------- Incidentes de aeroporto (aba Aeroportos) ----------------
// Igual ao Atacado (Restauração · INTERNET · Indisponibilidade · Internet · 24x7).
// Aeroporto dos POPs → Localidade e Site do POP. Outro aeroporto → Não Geográficos (Aeroportos) e Site NGO.
// Título e Assunto = o título que veio. Fila: escolhida no painel.
const AEROPORTOS = [
  { sigla: 'GRU', localidade: 'Aeroporto de Guarulhos (GRU)',        site: ['GRU', 'GUARULHOS'],      re: /\bGRU\b|GUARULHOS/i },
  { sigla: 'GIG', localidade: 'Aeroporto de Rio de Janeiro (GIG)',   site: ['GIG', 'GALEAO'],         re: /\bGIG\b|GALE[AÃ]O/i },
  { sigla: 'BSB', localidade: 'Aeroporto de Brasília (BSB)',         site: ['BSB', 'BRASILIA'],       re: /\bBSB\b|BRAS[IÍ]LIA/i },
  { sigla: 'CNF', localidade: 'Aeroporto de Confins (CNF)',          site: ['CNF', 'CONFINS'],        re: /\bCNF\b|CONFINS|BH AIRP/i },
  { sigla: 'VCP', localidade: 'Aeroporto de Campinas (VCP)',         site: ['VCP', 'VIRACOPOS'],      re: /\bVCP\b|VIRACOPOS/i },
  { sigla: 'FLN', localidade: 'Aeroporto de Florianópolis (FLN)',    site: ['FLN', 'FLORIANOPOLIS'],  re: /\bFLN\b|FLORIAN[OÓ]POLIS/i },
  { sigla: 'MEA', localidade: 'Aeroporto de Macaé (MEA)',            site: ['MEA', 'MACAE'],          re: /\bMEA\b|MACA[EÉ]/i },
  { sigla: 'VIX', localidade: 'Aeroporto de Vitória (VIX)',          site: ['VIX', 'VITORIA'],        re: /\bVIX\b|AEROPORTO DE VIT[OÓ]RIA/i },
  { sigla: 'POA', localidade: 'Aeroporto de Porto Alegre (POA)',     site: ['POA', 'PORTO ALEGRE'],   re: /\bPOA\b|PORTO ALEGRE/i },
  { sigla: 'FOR', localidade: 'Aeroporto de Fortaleza (FOR)',        site: ['FOR', 'FORTALEZA'],      re: /\bFOR\b|FORTALEZA/ },
  { sigla: 'CGH', localidade: 'CGH - Aeroporto de Congonhas',        site: ['CGH', 'CONGONHAS'],      re: /\bCGH\b|CONGONHAS/i },
  { sigla: 'CWB', localidade: 'Aeroporto de Curitiba (CWB)',         site: ['CWB', 'CURITIBA'],       re: /\bCWB\b|CURITIBA/i },
  { sigla: 'CGB', localidade: 'Socicam - Aeroporto de Cuiabá (CGB)', site: ['CGB', 'CUIABA'],         re: /\bCGB\b|CUIAB[AÁ]/i },
  { sigla: 'NAT', localidade: 'Aeroporto de Natal (NAT)',            site: ['NAT', 'NATAL'],          re: /\bNAT\b|AEROPORTO DE NATAL/ }
];
const AERO_NG = { sigla: '', localidade: NG_AERO, site: null };
// Primeiro aeroporto dos POPs citado no título; se não houver, no texto.
function aeroportoDo(titulo, texto) {
  return AEROPORTOS.find(a => a.re.test(String(titulo || ''))) || AEROPORTOS.find(a => a.re.test(String(texto || ''))) || AERO_NG;
}
const aeroPorLocalidade = (loc) => AEROPORTOS.find(a => a.localidade === loc) || AERO_NG;
const tituloAeroporto = (titulo) => String(titulo || '').split('|')[0].replace(/^Ticket#\s*\d+\s*[—-]\s*/i, '').trim();
const designacaoDo = (titulo, texto) => (String(titulo + '\n' + texto).match(/\b(B[DL]\d{6,})\b/i) || [])[1]?.toUpperCase() || '';
// Filas do OTRS (09/11/2026): lista da aba Aeroportos.
const FILAS_OTRS = ["COM - ATACADO", "COM - CIDADES PRIVADAS", "COM - ENTERPRISE", "COM - INFRAESTRUTURA", "COM - OPERADORA - CONTRATAÇÃO DE CIRCUITO", "ENG - REDES", "ENG - SISTEMAS", "ENG - TI", "FIN - FINANCEIRO", "FIN – BLOQUEIO FINANCEIRO", "IMPLANTAÇÃO", "METRO - ENGENHARIA", "METRO - SUPORTE AVANÇADO", "METRO – FIELD", "METRO – PENDENTE", "Monitoramento Análise N3", "Monitoramento Crítico", "Monitoramento Vip", "NOC - ACESSOS E CADASTROS", "NOC - ATACADO", "NOC - BLOQUEIO DE CLIENTES", "NOC - CANCELAMENTOS NGO", "NOC - N3 PENDENTES", "NOC - PENDENTES", "NOC - QUALIDADE ATACADO", "NOC - RETIRA EQUIPAMENTO", "NOC - SERVICE DESK", "NOC - SUPORTE AVANÇADO", "NOC – PENDENTE PAGAMENTO", "OPE - FIELD SERVICES", "OPE - PENDENTES", "PRÉ - PRÉ VENDA", "PÓS - AEROPORTOS", "PÓS - CANCELAMENTOS", "PÓS - NGO", "PÓS - OPERADORAS", "PÓS – MIGRAÇÃO / REPARO", "RH - RECURSOS HUMANOS"];
function textoCategorizacaoAero(d, fila) {
  return textoCategorizacao(d).replace('para a fila Service Desk.', `para a fila ${esc(fila)}.`);
}
function textoNotaEquipe(fila) {
  return '<p><strong>Arion - Central de Atendimento</strong></p>' +
    `<p>Ticket encaminhado para a equipe: ${esc(fila)}</p>` +
    '<p>Gentileza prosseguir com a tratativa.</p>';
}

const ASSUNTO_NOTA = 'NOTA DE ENCAMINHAMENTO';

// ---------------- tipos de chamado ----------------
const TIPOS = {
  atacado: { nome: 'NOC Atacado' },
  suporte: { nome: 'Suporte TI (Engenharia)' }
};

// Suporte TI (Engenharia). Motivo = Sub serviço SGF = Serviço no OTRS.
const MOTIVOS = ['Notebook', 'Celular', 'Acessos', 'E-mails', 'Softwares', 'Outras'];
const SUPORTE = {
  filaCategoria: 'Service Desk',
  filaEncaminhar: 'ENG - SISTEMAS',
  equipe: 'Eng. Sistemas',
  fixos: {
    tipo: 'Solicitação',
    servicoSgf: 'SUPORTE TI (Engenharia)',
    sla: 'Sem SLA',
    site: 'NGO - NAO GEOGRAFICO',
    empresa: 'Grupo Arion'
  }
};

// ---------------- extração ----------------

// No corpo, só nomes completos: siglas curtas (BRAD, BB, CEF) aparecem em rótulos e listas.
const DETECTAR_CORPO = {
  fust: /NOC[_\s-]?FUST|\bINEP\b/i,
  bradesco: /BRADESCO/i,
  bb: /BANCO DO BRASIL|PROJETO BB\b/i,
  cef: /CAIXA ECON[OÔ]MICA|PROJETO CEF\b/i,
  correios: /CORREIOS/i,
  carrefour: /CARREFOUR/i,
  mcdonalds: /MC\s?DONALD|ARCOS DOURADOS/i,
  algar: /ALGAR TELECOM|EILD ALGAR|PROJETO ALGAR/i,
  diversos: /PROJETO DIVERSOS/i
};

function detectarCliente(titulo, texto) {
  let id = '';
  for (const [k, c] of Object.entries(CLIENTES)) if (c.detectar.test(titulo)) { id = k; break; }
  if (!id) for (const [k, re] of Object.entries(DETECTAR_CORPO)) if (re.test(texto)) { id = k; break; }
  // Arcos Dourados: sempre "Arcos Dourados". O "Arcos Dourados - CNF" é escolhido à mão (alpha.20).
  return id;
}

// Correios, BB, CEF, Carrefour, Diversos: sempre Claro. FUST: Vivo. Algar: Algar.
// Bradesco: Vivo ou Telmex. McDonald's: Vivo ou Claro. "VIVO" no chamado → Telefônica.
function detectarOperadora(cliente, texto) {
  const c = CLIENTES[cliente];
  if (!c) return '';
  if (c.operadoras.length === 1) return c.operadoras[0];
  if (/\bVIVO\b/i.test(texto)) return 'telefonica';
  if (cliente === 'bradesco') return /TELMEX|EMBRATEL/i.test(texto) ? 'telmex' : '';
  if (cliente === 'mcdonalds' || cliente === 'mcdcnf') return /\bCLARO\b/i.test(texto) ? 'claro' : 'telefonica';
  return c.operadoras[0];
}

function primeiro(fontes, re) {
  for (const f of fontes) {
    const m = f && f.match(re);
    if (m) return (m[1] || m[0]).trim();
  }
  return '';
}

function detectarUF(titulo, texto, designacao) {
  const cand = [
    primeiro([titulo, texto], /ALGAR\s*-\s*([A-Z]{2})\b/i),
    primeiro([designacao], /^VIVO\.([A-Z]{2})\./i),
    primeiro([titulo], /\s-\s([A-Z]{2})\s-\s/),
    primeiro([texto], /\s-\s*([A-Z]{2})\s+CEP/i)
  ].map(s => s.toUpperCase());
  return cand.find(u => UFS.includes(u)) || '';
}

// ---------------- Solicitação de Tratativa de Qualidade (Atacado) ----------------
// Título "SOLICITAÇÃO DE TRATATIVA DE QUALIDADE | OQ-… | TQ-… | Cliente | Operadora | Designação".
// Categoriza como o cliente do título, mas Título e Assunto ficam com o título que veio.
const QUALIDADE = { fila: 'NOC - QUALIDADE ATACADO' };
const RE_QUALIDADE = /SOLICITA[CÇ][AÃ]O DE TRATATIVA DE QUALIDADE/i;
function tituloQualidade(titulo) {
  const t = String(titulo || '');
  const i = t.search(RE_QUALIDADE);
  if (i < 0) return '';
  // O título lido pode vir repetido ("título | cabeçalho"): fica com o 1º bloco de 6 partes.
  const partes = t.slice(i).split('|').map(x => x.trim());
  return partes.slice(0, 6).join(' | ');
}

function extrair(arg) {
  const d = extrairBase(arg);
  const tq = tituloQualidade(arg && arg.titulo);
  if (tq && d.tipoCh !== 'suporte' && !['cancng', 'cmdb'].includes(d.grupo)) {
    d.qualidade = true;
    d.tituloQualidade = tq;
    completar(d);
  }
  return d;
}

function extrairBase({ titulo = '', texto = '' }) {
  if (ehCmdb(titulo, texto) && !ehCancNgo(titulo, texto)) {
    return completar({ tipoCh: 'atacado', grupo: 'cmdb', cliente: '', operadora: '', designacao: '', identificador: '', uf: '', op: '',
      empresaCmdb: empresaDoTexto(titulo, texto), locng: ehAeroporto(titulo, texto) ? 'aeroportos' : 'urbanos' });
  }
  if (ehCancNgo(titulo, texto)) {
    const s = extrairSgf(titulo, texto);
    return completar({ tipoCh: 'atacado', grupo: 'cancng', cliente: '', operadora: '', designacao: '', identificador: '', uf: '', op: '',
      sgf: s, razao: s.razao, fantasia: s.fantasia, telefone: s.telefone, pop: s.pop });
  }
  const fontes = [titulo, texto];
  const cliente = detectarCliente(titulo, texto);
  const operadora = detectarOperadora(cliente, texto + '\n' + titulo);

  // FUST: designação no formato VIVO.UF.CÓDIGO (ex.: VIVO.BA.BLIVR000017).
  const vivo = primeiro(fontes, /\b(VIVO\.[A-Z]{2}\.[A-Z0-9]+)\b/i).toUpperCase();
  const bl = primeiro(fontes, /\b(B[DL]\d{6,})\b/i).toUpperCase();
  const designacao =
    (cliente === 'fust' ? vivo || bl : bl || vivo) ||
    primeiro(fontes, /DESIGNA(?:[CÇ][AÃ]O|DOR)\s*:?\s*([A-Z0-9][A-Z0-9./_-]{4,})/i);

  const valores = {
    ci: primeiro(fontes, /\bC\.?I\.?\s*:?\s*(\d{4,})/i) || primeiro(fontes, /\bREC(?:\s*ID)?\s*:?\s*(\d{4,})/i) || primeiro(fontes, /CHAMADO INTERNO\s*:?\s*(\d{4,})/i),
    inc: primeiro(fontes, /\bINC\s*:?\s*(\d{6,})\b/i),
    agencia: primeiro(fontes, /\bAG(?:[EÊ]NCIA)?\.?\s*(?:N[º°o]\.?)?\s*:?\s*(\d{3,5})\b/i),
    sigla: primeiro(fontes, /SIGLA\s*:?\s*([A-Z0-9]{2,10})\b/i),
    brad: primeiro(fontes, /\bBRAD\s*:?\s*(\d{2,6})\b/i),
    np: primeiro(fontes, /\bNP\s*:?\s*(\d{3,})\b/i)
  };

  const d = { tipoCh: 'atacado', cliente, operadora, designacao, uf: '', op: '' };
  // Reincidência e Cancelamento: só máscara, sem cliente/localidade.
  const so = /REINCID/i.test(titulo) ? 'reinc' : /CANCELAMENTO/i.test(titulo) ? 'canc' : '';
  if (so) {
    d.grupo = so; d.cliente = '';
    d.operadora = operadoraDoTexto(texto + '\n' + titulo);
    d.op = primeiro([titulo, texto], /\bOP\s*:\s*([^\n]+?)(?=\s+-\s|\n|$)/i).toUpperCase();
  }
  if (cliente === 'algar') d.uf = detectarUF(titulo, texto, designacao);
  d.identificador = valores[tipoSufixo(d)] || '';
  return completar(d);
}

function operadoraDoTexto(t) {
  if (/TELMEX|EMBRATEL/i.test(t)) return 'telmex';
  if (/\bVIVO\b|TELEFONICA|TELEF[ÔO]NICA/i.test(t)) return 'telefonica';
  if (/ALGAR/i.test(t)) return 'algar';
  if (/\bCLARO\b/i.test(t)) return 'claro';
  return '';
}

// ---------------- máscara ----------------

function tipoSufixo(d) {
  if (d.grupo && MODELOS[d.grupo] && MODELOS[d.grupo].sufixo) return MODELOS[d.grupo].sufixo;
  const c = CLIENTES[d.cliente];
  if (!c) return 'ci';
  return typeof c.sufixo === 'string' ? c.sufixo : (c.sufixo[d.operadora] || 'ci');
}

function localidade(d) {
  const c = CLIENTES[d.cliente];
  return c ? c.localidade.replace('{UF}', d.uf || '??') : '';
}

// Operadoras aceitas para o modelo/cliente atual.
function operadorasPermitidas(d) {
  const g = MODELOS[d.grupo];
  if (g && g.operadoras) return g.operadoras;
  const c = CLIENTES[d.cliente];
  return c ? c.operadoras : Object.keys(OPERADORAS);
}

function faltando(d) {
  const f = [];
  const c = CLIENTES[d.cliente];
  const soMascara = SO_MASCARA.includes(d.grupo);
  if (!d.grupo) f.push('modelo');
  if (!soMascara && !c) f.push('cliente');
  if (!d.operadora) f.push('operadora');
  else if (!operadorasPermitidas(d).includes(d.operadora)) f.push('operadora inválida para o cliente');
  if (d.grupo === 'canc' && !d.op) f.push('OP');
  if (!d.designacao) f.push('designação');
  if (!d.identificador) f.push(SUFIXOS[tipoSufixo(d)].rotulo.toLowerCase());
  if (d.cliente === 'algar' && !UFS.includes(d.uf)) f.push('UF');
  return f;
}

function mascara(d) {
  const op = OPERADORAS[d.operadora];
  const suf = SUFIXOS[tipoSufixo(d)].prefixo + d.identificador;
  if (d.grupo === 'reinc') return ['[REINCIDENCIA MONITORAMENTO]', op.mascara, 'BRADESCO', d.designacao, suf].join(' - ');
  if (d.grupo === 'canc') return ['NGO', op.mascara, 'CANCELAMENTO', 'INTERNET', 'OP:' + d.op, d.designacao, suf].join(' - ');
  const c = CLIENTES[d.cliente];
  const prefixo = c.prefixo.replace('{UF}', d.uf || '??');
  // Algar: "Projeto EILD Algar - SP - RESTAURAÇÃO - INTERNET - PROJETO ALGAR - <designação> - CI:" (sem a operadora).
  if (c.semOperadora) return [prefixo, 'RESTAURAÇÃO', 'INTERNET', c.projeto, d.designacao, suf].join(' - ');
  const nomeOp = (c.mascaraOperadora && c.mascaraOperadora[d.operadora]) || op.mascara;
  return [prefixo, nomeOp, 'RESTAURAÇÃO', 'INTERNET', c.projeto, d.designacao, suf].join(' - ');
}

// Recalcula os campos derivados após qualquer edição.
function completar(d) {
  d.tipoCh = d.tipoCh === 'suporte' ? 'suporte' : 'atacado';
  if (d.tipoCh === 'suporte') {
    d.motivo = MOTIVOS.includes(d.motivo) ? d.motivo : 'Acessos';
    d.tipoSufixo = 'ci';
    d.faltando = [];
    d.mascara = `Grupo Arion - SOLICITAÇÃO - SUPORTE TI (Engenharia) - ${d.motivo}`;
    d.empresa = SUPORTE.fixos.empresa;
    return d;
  }
  if (d.grupo === 'cmdb') {
    d.cliente = ''; d.soMascara = false; d.tipoSufixo = 'ci';
    d.locng = CMDB.loc[d.locng] ? d.locng : 'urbanos';
    const L = CMDB.loc[d.locng];
    d.empresaCmdb = String(d.empresaCmdb || '').trim();
    d.faltando = d.empresaCmdb ? [] : ['empresa'];
    d.mascara = d.faltando.length ? '' : [L.opcao, d.empresaCmdb.toUpperCase(), 'SOLICITAÇÃO', 'INTERNET', 'CADASTRO NO CMDB'].join(' - ');
    d.localidade = L.opcao; d.localidadeBusca = L.busca; d.localidadeOpcao = L.opcao;
    d.empresa = d.empresaCmdb;
    return d;
  }
  if (d.grupo === 'cancng') {
    d.cliente = ''; d.soMascara = false; d.tipoSufixo = 'ci';
    d.sgf = d.sgf || {};
    d.faltando = [];
    if (!d.razao) d.faltando.push('razão social');
    if (!d.sgf.pedido) d.faltando.push('pedido');
    // Título e Assunto = máscara: Localidade - RAZÃO SOCIAL - CANCELAMENTO - INTERNET - Pedido: N
    d.mascara = d.faltando.length ? '' : [NG, String(d.razao).toUpperCase(), 'CANCELAMENTO', 'INTERNET', 'Pedido: ' + d.sgf.pedido].join(' - ');
    d.localidade = NG; d.localidadeBusca = LOC_NG.busca; d.localidadeOpcao = NG;
    d.empresa = '';
    return d;
  }
  // Modelo (grupo) e cliente andam juntos.
  if (!d.grupo) d.grupo = grupoDoCliente(d.cliente);
  const g = MODELOS[d.grupo];
  if (g && g.clientes) {
    if (g.clientes.length === 1) d.cliente = g.clientes[0];
    else if (!g.clientes.includes(d.cliente)) d.cliente = '';
  } else if (g) d.cliente = '';
  d.soMascara = SO_MASCARA.includes(d.grupo);
  d.tipoSufixo = tipoSufixo(d);
  // FUST: o chamado interno é sempre INC + código (aceita só os números).
  if (d.tipoSufixo === 'inc' && d.identificador) {
    d.identificador = 'INC' + String(d.identificador).toUpperCase().replace(/^INC\s*:?\s*/, '');
  }
  d.faltando = faltando(d);
  d.mascara = d.faltando.length ? '' : mascara(d);
  // Tratativa de Qualidade: não precisa de CI/Sigla/NP; a "máscara" é o título que veio.
  if (d.qualidade && d.tituloQualidade) {
    d.faltando = d.faltando.filter(f => ['modelo', 'cliente', 'designação', 'UF'].includes(f) || f.startsWith('operadora'));
    d.mascara = d.faltando.length ? '' : d.tituloQualidade;
  }
  d.localidade = localidade(d);
  if (d.soMascara) { d.localidadeBusca = ''; d.localidadeOpcao = ''; d.empresa = ''; return d; }
  const lb = LOCALIDADE_BUSCA[d.cliente];
  const uf = d.uf || '';
  d.localidadeBusca = lb ? lb.busca.replace('{UF}', uf) : d.localidade;
  d.localidadeOpcao = lb ? (lb.opcao ? lb.opcao.replace('{UF}', uf) : null) : d.localidade;
  d.empresa = d.operadora ? OPERADORAS[d.operadora].empresa : '';
  return d;
}

// ---------------- textos ----------------

const esc = s => String(s || '').replace(/[&<>"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));

// Modelo escolhido: título em negrito, linha de traços separando a máscara.
function textoCategorizacao(d) {
  return '<p><strong>Arion - Central de Atendimento</strong><br>' +
    'Este ticket foi categorizado e encaminhado para a fila Service Desk.<br>' +
    '--------------------------------------------<br>' +
    'Mascara gerada<br>' +
    `${esc(d.mascara)}</p>`;
}

function textoCategorizacaoSuporte() {
  return '<p><strong>Arion - Central de Atendimento</strong><br>' +
    `Este ticket foi categorizado e encaminhado para a fila ${SUPORTE.filaCategoria}.</p>`;
}

function textoNotaSuporte() {
  return '<p><strong>Arion - Central de Atendimento</strong></p>' +
    `<p>Ticket encaminhado para a equipe:  ${SUPORTE.equipe}</p>` +
    '<p>Gentileza prosseguir com a tratativa.</p>';
}

function textoCategorizacaoCancNgo() {
  return '<p><strong>Arion - Central de Atendimento</strong><br>' +
    'Este ticket foi categorizado e encaminhado para a fila Service Desk.</p>';
}

function textoNotaCancNgo() {
  return '<p><strong>Arion - Central de Atendimento</strong></p>' +
    `<p>Ticket encaminhado para a equipe: ${CANC_NGO.fila}</p>` +
    '<p>Gentileza prosseguir com a tratativa.</p>';
}

function textoNotaCmdb() {
  return '<p><strong>Arion - Central de Atendimento</strong></p>' +
    `<p>Ticket encaminhado para a equipe:  ${CMDB.fila}</p>` +
    '<p>Gentileza prosseguir com a tratativa.</p>';
}

function textoNota(fila = FILA) {
  return '<p><strong>Arion - Central de Atendimento</strong></p>' +
    `<p>Ticket encaminhado para a fila: ${fila}</p>` +
    '<p>Atividade: Aguardando atuação da operadora de transito (ISP)</p>' +
    '<p>Gentileza acompanhar diariamente a tratativa até sua conclusão.</p>';
}

const api = { LOCALIDADE_BUSCA, NG, UFS, OPERADORAS, SUFIXOS, CLIENTES, FIXOS, FILA, ASSUNTO_NOTA, TIPOS, MOTIVOS, SUPORTE, MODELOS, SO_MASCARA, extrair, completar, tipoSufixo, operadorasPermitidas, textoCategorizacao, textoCategorizacaoSuporte, textoNota, textoNotaSuporte, CANC_NGO, POPS, extrairSgf, textoCategorizacaoCancNgo, textoNotaCancNgo, CMDB, ehAeroporto, empresaDoTexto, textoNotaCmdb, CNF_FILAS, ehConfins, LOCALIDADES, localidadeExiste, QUALIDADE, tituloQualidade, AEROPORTOS, AERO_NG, aeroportoDo, aeroPorLocalidade, tituloAeroporto, designacaoDo, FILAS_OTRS, textoNotaEquipe, textoCategorizacaoAero };
if (typeof self !== 'undefined') self.Regras = api;
if (typeof module !== 'undefined') module.exports = api;

})();
