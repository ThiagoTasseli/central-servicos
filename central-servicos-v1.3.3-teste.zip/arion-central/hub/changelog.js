/* changelog.js — o que mudou em cada versão (aparece no Guia). */
self.ARION_CHANGELOG = [
  {
    versao: "1.3.3-teste",
    itens: [
      "NOC: escolha o tipo de chamado no topo (NOC Atacado ou Suporte TI (Engenharia)).",
      "NOC: novas máscaras — Cancelamento, Reincidência, Bradesco (Vivo e Telmex), McDonald's e Projeto Carrefour.",
      "NOC: \"Não Geográficos (Urbanos)\" abre a escolha do cliente. O identificador muda conforme o modelo (CI, BRAD, SIGLA, NP).",
      "NOC: Suporte TI (Engenharia) categoriza e encaminha para ENG - SISTEMAS.",
      "Voos · Alarme: listas separadas — Meus alarmes e Alarmes de voo.",
      "Voos · Alarme: alarme adiado aparece como Agendado.",
      "Voos · Alarme: 10 sons para escolher, com nomes simples, incluindo avião decolando.",
      "Máscara: removidos o Connecta (Smart IT), as permissões onbmc.com e a lista de nomes no campo Técnico.",
      "Todos os campos de seleção aceitam digitar para filtrar as opções.",
    ],
  },
  {
    versao: "1.3.2-teste",
    itens: [
      "Chamados: o e-mail digitado pelo usuário não é mais sobrescrito pelo e-mail do solicitante.",
      "Chamados: Departamento com sugestões ao digitar (41 departamentos do ServiceAide).",
    ],
  },
  {
    versao: "1.3.1-teste",
    itens: [
      "Voos · Alarme: botão + abre um modal para criar tarefas e lembretes (ex.: passagem de turno), com repetição diária ou seg a sex.",
      "Voos · Alarme: \"Partida HH:MM ↗\" leva ao voo e destaca, com um pulso, o botão de colar certo.",
      "Chamados: botão Localizar no Nome — avisa se encontrou nome e sobrenome e não repete a busca ao preencher.",
    ],
  },
  {
    versao: "1.3.0-teste",
    itens: [
      "Visual padronizado nas 4 ferramentas: mesmo cabeçalho, cores, fontes, botões e campos.",
      "Tema claro/escuro único, trocado no trilho (☀/☾).",
      "Fontes locais: não depende mais do Google Fonts nem de internet.",
      "Segurança: textos da planilha e das páginas são tratados antes de aparecer na tela.",
      "Biblioteca de planilhas atualizada (SheetJS 0.20.3).",
      "Dados de chamados e solicitantes apagados após 7 dias.",
      "Aviso de versão nova pela intranet (opcional).",
    ],
  },
  { versao: "1.2.0", itens: ["Botão para recolher a barra (Alt+0)."] },
  { versao: "1.1.0", itens: ["Modo bandeja ou fixado na lateral."] },
  { versao: "1.0.0", itens: ["Primeira versão: 4 extensões em uma, navegação por ícones e guia."] },
];
