/* comercial.js — aba "Comercial" da Categorização (CSTI). Versão de teste.
 * Capturar: lê o chamado do OTRS aberto (número, cliente, empresa, contato, e-mail, descrição) + data/hora.
 * Preencher planilha: copia a linha A–E (CHAMADO, NOME DO CLIENTE, EMPRESA, DATA, HORA) e foca a planilha.
 * Abrir chamado: abre "Novo chamado de Restauração/Solicitação" no OTRS e preenche os campos (sem enviar).
 */
(function () {
  const $ = (id) => document.getElementById(id);
  const R = self.Regras;
  const get = (k) => new Promise((r) => chrome.storage.local.get(k, (v) => r(v[k])));
  const set = (k, v) => new Promise((r) => chrome.storage.local.set({ [k]: v }, r));
  const msg = (t, erro) => { try { toast(t, erro); } catch (_) {} };

  const PROCESSO = 'Process-a946dec6796857d27b1b3ae9f0d48c51'; // Novo chamado de Restauração/Solicitação
  const AJUSTES_PADRAO = {
    localidade: 'Não Geográficos (Urbanos)', tipo: 'Solicitação', sgf: 'INTERNET',
    servico: 'Internet', sla: '24 Horas 24x7', site: 'NGO - NAO GEOGRAFICO'
  };
  const CAMPOS = ['chamado', 'data', 'hora', 'nome', 'empresa', 'contato', 'email', 'descricao'];
  const AJ = ['localidade', 'tipo', 'sgf', 'servico', 'sla', 'site', 'assunto'];

  let c = { fontes: {} };        // captura atual
  let aj = { ...AJUSTES_PADRAO };
  let textoEditado = false;
  let assuntoEditado = false;

  // ---------- modo (aba Comercial) ----------
  const bCom = document.querySelector('#aTipo button[data-modo="comercial"]');
  function modo(com) {
    document.body.classList.toggle('modo-comercial', com);
    $('comercial').hidden = !com;
    bCom.classList.toggle('on', com);
    set('noc_modo', com ? 'comercial' : '');
  }
  bCom.addEventListener('click', () => modo(true));
  document.querySelectorAll('#aTipo button[data-tipo]').forEach((b) => b.addEventListener('click', () => modo(false)));

  // ---------- extração ----------
  const limpa = (v) => String(v || '').replace(/\s+/g, ' ').trim();
  // O texto pode vir sem quebras de linha: o valor vai até a quebra OU o próximo rótulo conhecido.
  const ROTULOS = ['De', 'From', 'Remetente', 'Para', 'Cc', 'Assunto', 'Data', 'Empresa', 'Raz[aã]o Social', 'Nome Fantasia',
    'Rede parceira', 'Telefone', 'Celular', 'Contato', 'Tel', 'E-?mail', 'Descri[cç][aã]o', 'Nome do cliente', 'Nome', 'Cliente', 'Solicitante'];
  const PROX = '(?=(?:' + ROTULOS.join('|') + ')\\s*:|\\n|$)';
  function rotulo(texto, nomes) {
    for (const n of nomes) {
      const m = String(texto).match(new RegExp('(?:^|[^A-Za-zÀ-ú])' + n + '\\s*:[ \\t]*([^\\n]{1,160}?)' + PROX, 'i')) ||
        String(texto).match(new RegExp(n + '\\s*:[ \\t]*([^\\n]{1,160}?)' + PROX, 'i'));
      if (m && limpa(m[1])) return limpa(m[1]);
    }
    return '';
  }
  function formataFone(f) {
    const n = String(f).replace(/\D/g, '').replace(/^55(?=\d{10,11}$)/, '');
    if (n.length === 11) return `(${n.slice(0, 2)}) ${n.slice(2, 7)}-${n.slice(7)}`;
    if (n.length === 10) return `(${n.slice(0, 2)}) ${n.slice(2, 6)}-${n.slice(6)}`;
    return limpa(f);
  }
  function extrairCliente(titulo, texto) {
    const t = String(texto || '');
    const out = {}, fonte = {};
    // Remetente: "De: Nome <email>" / "From: …"
    const rem = t.match(/(?:De|From|Remetente)\s*:\s*"?([^"<\n:]{2,80}?)"?\s*<([^>\s]+@[^>\s]+)>/i);
    out.nome = rotulo(t, ['Nome do cliente', 'Nome', 'Cliente', 'Solicitante']);
    if (out.nome) fonte.nome = 'do texto';
    else if (rem) { out.nome = limpa(rem[1]); fonte.nome = 'do remetente'; }
    out.empresa = rotulo(t, ['Empresa', 'Raz[aã]o Social', 'Nome Fantasia', 'Rede parceira']);
    if (out.empresa) fonte.empresa = 'do texto';
    const fone = rotulo(t, ['Telefone', 'Celular', 'Contato', 'Tel']) ;
    const foneNum = (fone.match(/\(?\d{2}\)?\s?9?\d{4}[-\s.]?\d{4}/) || [])[0] ||
      (t.match(/\(?\b\d{2}\)?\s?9\d{4}[-\s.]?\d{4}\b/) || [])[0] || '';
    if (foneNum) { out.contato = formataFone(foneNum); fonte.contato = fone ? 'do texto' : 'da assinatura'; }
    const emails = (t.match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/g) || []).filter((e) => !/grupoarion|otrs/i.test(e));
    const em = rotulo(t, ['E-?mail']).match(/[\w.+-]+@[\w-]+(?:\.[\w-]+)+/);
    out.email = (em && em[0]) || (rem && !/grupoarion/i.test(rem[2]) ? rem[2] : '') || emails[0] || '';
    if (out.email) fonte.email = em ? 'do texto' : rem ? 'do remetente' : 'do texto';
    const desc = t.match(/Descri[cç][aã]o\s*:\s*([\s\S]{3,600}?)(?:\n\s*\n|(?:Att|Atenciosamente|Obrigad[oa])\b|$)/i);
    out.descricao = desc ? limpa(desc[1]) : '';
    if (out.descricao) fonte.descricao = 'do texto';
    return { out, fonte };
  }

  // ---------- tela ----------
  function badge(k) {
    const el = $('b-' + k);
    if (!el) return;
    const f = c.fontes[k];
    el.className = 'c-b ' + (f === 'editado' ? 'ed' : f ? 'ok' : (c.chamado ? 'no' : ''));
    el.textContent = f === 'editado' ? '✎ editado' : f ? '✓ ' + f : (c.chamado ? (k === 'nome' ? 'Não localizado' : 'Não localizado · digite') : '');
    $('c-' + k).closest('.a-f').classList.toggle('erro', !!c.chamado && !f && (k === 'empresa'));
  }
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  function textoPadrao() {
    return 'Arion - Central de Atendimento\n' +
      'Este ticket foi categorizado e encaminhado para a fila Service Desk.\n\n' +
      `Chamado: ${c.chamado || ''}\n` +
      `Nome do Cliente: ${c.nome || ''}\n` +
      `Empresa: ${c.empresa || ''}\n` +
      `Contato (Número): ${c.contato || ''}\n` +
      `E-mail: ${c.email || ''}\n` +
      `Data/Hora: ${[c.data, c.hora].filter(Boolean).join(' ')}\n` +
      `Descrição: ${c.descricao || ''}`;
  }
  const assuntoPadrao = () => [aj.localidade, String(c.empresa || 'EMPRESA').toUpperCase(), String(aj.tipo || '').toUpperCase(), 'INTERNET'].join(' - ');
  const linha = () => [c.chamado, c.nome, c.empresa, c.data, c.hora].map((v) => String(v || '').replace(/[\t\n]/g, ' '));

  function render() {
    CAMPOS.forEach((k) => { if (document.activeElement !== $('c-' + k)) $('c-' + k).value = c[k] || ''; });
    ['nome', 'empresa', 'contato', 'email', 'descricao'].forEach(badge);
    $('c-ctx').hidden = !c.chamado;
    $('c-ctx-t').textContent = c.chamado ? `Capturado às ${c.hora} · ${c.data}` : '';
    $('c-linha').innerHTML = c.chamado ? '<tr>' + linha().map((v) => `<td title="${esc(v)}">${esc(v)}</td>`).join('') + '</tr>' : '<tr><td colspan="5" style="text-align:center;color:var(--ds-text-faint)">Capture um chamado.</td></tr>';
    const st = $('c-plan-st');
    st.className = 'c-b ' + (c.planilha ? 'ok' : '');
    st.textContent = c.planilha === 'copiada' ? '✓ linha copiada' : c.planilha ? '✓ ' + c.planilha : '';
    if (!textoEditado) $('c-texto').value = c.chamado ? textoPadrao() : '';
    if (!assuntoEditado && document.activeElement !== $('c-assunto')) $('c-assunto').value = c.chamado ? assuntoPadrao() : '';
    AJ.filter((k) => k !== 'assunto').forEach((k) => { if (document.activeElement !== $('c-' + k)) $('c-' + k).value = aj[k] || ''; });
    $('c-planilha').disabled = !c.chamado;
    $('c-abrir').disabled = !c.chamado;
    const pb = $('c-planilha');
    pb.className = 'a-btn ' + (c.planilha ? 'a-btn--done' : 'a-btn--gh');
    pb.textContent = !c.planilha ? 'Preencher planilha' : c.planilha === 'copiada' ? 'Tentar de novo' : '✓ Na planilha';
  }
  const salvar = () => set('com_atual', { c, textoEditado, assuntoEditado, texto: $('c-texto').value, assunto: $('c-assunto').value });

  // Localidades (lista do OTRS)
  $('c-localidade').innerHTML = (R.LOCALIDADES || []).map((l) => `<option>${esc(l.trim())}</option>`).join('');

  CAMPOS.forEach((k) => $('c-' + k).addEventListener('input', () => {
    c[k] = $('c-' + k).value;
    if (c.fontes && k in c.fontes || ['nome', 'empresa', 'contato', 'email', 'descricao'].includes(k)) c.fontes[k] = c[k] ? 'editado' : '';
    c.planilha = false;
    render(); salvar();
  }));
  AJ.forEach((k) => $('c-' + k).addEventListener('input', () => {
    if (k === 'assunto') assuntoEditado = true; else aj[k] = $('c-' + k).value;
    set('com_ajustes', aj);
    render(); salvar();
  }));
  $('c-texto').addEventListener('input', () => { textoEditado = true; salvar(); });

  // ---------- etapas ----------
  function etapas(lista) { const ol = $('c-etapas'); ol.hidden = false; ol.innerHTML = lista.map((n, i) => `<li data-i="${i}">${esc(n)}<em></em></li>`).join(''); }
  function etapa(i, st, m = '') { const li = document.querySelector(`#c-etapas li[data-i="${i}"]`); if (li) { li.className = st; li.querySelector('em').textContent = m; } }

  // ---------- ações ----------
  $('c-capturar').onclick = async () => {
    $('c-capturar').classList.add('carregando');
    const r = await OTRS.ler().catch((e) => ({ ok: false, erro: e.message }));
    $('c-capturar').classList.remove('carregando');
    if (!r || !r.ok) return msg((r && r.erro) || 'Não leu o chamado', true);
    const agora = new Date();
    const { out, fonte } = extrairCliente(r.titulo, r.texto);
    c = {
      chamado: r.numero || r.ticketId || '',
      data: agora.toLocaleDateString('pt-BR'),
      hora: agora.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
      nome: out.nome || 'Não localizado',
      empresa: out.empresa || '',
      contato: out.contato || '',
      email: out.email || '',
      descricao: out.descricao || '',
      fontes: fonte,
      ticketId: r.ticketId,
      planilha: false
    };
    textoEditado = false; assuntoEditado = false;
    render(); salvar();
    msg(fonte.empresa ? 'Chamado capturado' : 'Capturado. Empresa não localizada: digite.', !fonte.empresa);
  };

  $('c-copiar').onclick = async () => {
    try { await navigator.clipboard.writeText($('c-texto').value); msg('Texto copiado'); } catch (_) { msg('Não copiou', true); }
  };

  // ---------- planilha ----------
  // Plano A: copia a linha como TABELA (texto + HTML). O Excel separa as 5 colunas; Chamado/Data/Hora como texto.
  function copiarLinha(vals) {
    const tsv = vals.join('\t');
    const html = '<table><tr>' + vals.map((v) => `<td style="mso-number-format:'\\@'">${esc(v)}</td>`).join('') + '</tr></table>';
    let ok = false;
    const h = (e) => { e.clipboardData.setData('text/plain', tsv); e.clipboardData.setData('text/html', html); e.preventDefault(); ok = true; };
    document.addEventListener('copy', h);
    try { document.execCommand('copy'); } catch (_) {}
    document.removeEventListener('copy', h);
    if (!ok) { try { navigator.clipboard.writeText(tsv); ok = true; } catch (_) {} }
    return ok;
  }

  async function abaPlanilha() {
    const tabs = await chrome.tabs.query({});
    return tabs.find((t) => /CSTI-CHAMADOS-COMERCIAL/i.test(t.title || '')) ||
      tabs.find((t) => /sharepoint\.com|officeapps\.live\.com/i.test(t.url || '') && /CSTI|COMERCIAL/i.test((t.title || '') + (t.url || ''))) || null;
  }

  // Lê/atua no quadro do Excel (todas as molduras): Caixa de Nome e barra de fórmulas.
  async function excel(tabId, acao) {
    const res = await chrome.scripting.executeScript({
      target: { tabId, allFrames: true },
      args: [acao],
      func: (acao) => {
        const nb = [...document.querySelectorAll('input')].find((i) =>
          /name ?box|caixa de nome/i.test((i.getAttribute('aria-label') || '') + ' ' + i.id + ' ' + (i.title || '')));
        if (!nb) return null;
        const fbEl = document.querySelector('#formulaBarTextDivId_textElement, [id*="formulaBarText"], [aria-label*="ormula bar" i], [aria-label*="arra de fórmulas" i]');
        if (acao === 'focar') { nb.focus(); nb.select && nb.select(); }
        return { nb: (nb.value || '').trim(), fb: fbEl ? (fbEl.innerText || fbEl.value || '').trim() : null, foco: document.activeElement === nb };
      }
    }).catch(() => []);
    return (res.find((r) => r && r.result) || {}).result || null;
  }

  const espera = (ms) => new Promise((r) => setTimeout(r, ms));

  // Plano B: preenche sozinho pelo controle do Chrome (teclas reais), na 1ª linha vazia da coluna A.
  async function preencherExcel(tab, vals) {
    if (!chrome.debugger) return { ok: false, erro: 'Este navegador não permite preencher sozinho.' };
    const alvo = { tabId: tab.id };
    const cmd = (m, p) => chrome.debugger.sendCommand(alvo, m, p || {});
    const tecla = async (key, code, kc, mod = 0, text) => {
      await cmd('Input.dispatchKeyEvent', { type: text ? 'keyDown' : 'rawKeyDown', key, code, windowsVirtualKeyCode: kc, nativeVirtualKeyCode: kc, modifiers: mod, text });
      await cmd('Input.dispatchKeyEvent', { type: 'keyUp', key, code, windowsVirtualKeyCode: kc, nativeVirtualKeyCode: kc, modifiers: mod });
    };
    const enter = () => tecla('Enter', 'Enter', 13, 0, '\r');
    const irPara = async (ref) => {
      const f = await excel(tab.id, 'focar');
      if (!f) throw new Error('Não achei a Caixa de Nome do Excel.');
      await cmd('Input.insertText', { text: ref });
      await enter();
      await espera(450);
      const r = await excel(tab.id, 'ler');
      if (!r || r.nb.toUpperCase() !== ref.toUpperCase()) throw new Error(`Não chegou em ${ref} (está em ${r ? r.nb : '?'}).`);
      return r;
    };
    await chrome.tabs.update(tab.id, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
    await espera(400);
    await chrome.debugger.attach(alvo, '1.3');
    try {
      // Última linha preenchida da coluna A: A1 + Ctrl+↓.
      await irPara('A1');
      await tecla('ArrowDown', 'ArrowDown', 40, 2);
      await espera(450);
      const fim = await excel(tab.id, 'ler');
      const n = parseInt(((fim && fim.nb) || '').replace(/^\D+/, ''), 10);
      if (!n) throw new Error('Não consegui ler a última linha.');
      const linhaAlvo = n >= 1048000 ? 2 : n + 1; // só cabeçalho: Ctrl+↓ vai até o fim da planilha
      const pos = await irPara('A' + linhaAlvo);
      if (pos.fb) throw new Error(`A${linhaAlvo} não está vazia.`);
      // Digita A→E. Chamado com apóstrofo (fica como texto: o Excel só guarda 15 dígitos).
      for (let k = 0; k < vals.length; k++) {
        const v = k === 0 ? "'" + vals[k] : vals[k];
        if (v) await cmd('Input.insertText', { text: v });
        await tecla('Delete', 'Delete', 46); // apaga sugestão do AutoCompletar
        if (k < vals.length - 1) await tecla('Tab', 'Tab', 9);
        else await enter();
        await espera(120);
      }
      await espera(500);
      // Conferência: volta em A{linha} e lê o Chamado.
      const conf = await irPara('A' + linhaAlvo);
      const okConf = conf.fb == null || conf.fb.replace(/^'/, '') === String(vals[0]);
      return { ok: okConf, linha: linhaAlvo, erro: okConf ? '' : `Conferência: A${linhaAlvo} ficou "${conf.fb}".` };
    } finally {
      try { await chrome.debugger.detach(alvo); } catch (_) {}
    }
  }

  $('c-planilha').onclick = async () => {
    if (!c.empresa) return msg('Preencha a Empresa', true);
    const vals = linha();
    const copiou = copiarLinha(vals); // plano A sempre pronto
    const hist = (await get('com_hist')) || [];
    set('com_hist', [{ quando: Date.now(), linha: vals }, ...hist].slice(0, 200));
    const plan = await abaPlanilha();
    if (!plan) {
      c.planilha = copiou ? 'copiada' : false; render(); salvar();
      return msg('Abra a planilha CSTI-CHAMADOS-COMERCIAL numa aba e clique de novo. A linha já está copiada.', true);
    }
    $('c-planilha').classList.add('carregando');
    let r;
    try { r = await preencherExcel(plan, vals); } catch (e) { r = { ok: false, erro: e.message }; }
    $('c-planilha').classList.remove('carregando');
    if (r.ok) {
      c.planilha = 'linha ' + r.linha; render(); salvar();
      msg(`Preenchido na linha ${r.linha}`);
    } else {
      c.planilha = copiou ? 'copiada' : false; render(); salvar();
      msg((r.erro || 'Não preencheu') + ' A linha está copiada: clique em A da linha vazia e Ctrl+V.', true);
    }
  };

  function textoHtml(t) {
    const l = String(t).split('\n');
    const prim = l.shift() || '';
    return '<p><strong>' + esc(prim) + '</strong><br>' + l.map(esc).join('<br>') + '</p>';
  }

  $('c-abrir').onclick = async () => {
    if (!c.empresa) return msg('Preencha a Empresa', true);
    const auto = false; // teste: nunca envia sozinho
    etapas(['Abrir Novo chamado (processo)', 'Preencher campos', 'Conferir e clicar em Enviar']);
    etapa(0, 'run');
    $('c-abrir').classList.add('carregando');
    const r = await OTRS.abrirProcesso(PROCESSO, {
      f: { localidade: aj.localidade, empresa: c.empresa, contato: c.contato },
      fixos: { tipo: aj.tipo, servicoSgf: aj.sgf, servico: aj.servico, sla: aj.sla, site: aj.site },
      assunto: $('c-assunto').value || assuntoPadrao(),
      texto: textoHtml($('c-texto').value),
      enviar: auto
    }).catch((e) => ({ ok: false, erro: e.message }));
    $('c-abrir').classList.remove('carregando');
    if (!r || r.erro) { etapa(0, 'erro', (r && r.erro) || 'falhou'); return msg((r && r.erro) || 'Não abriu', true); }
    etapa(0, 'ok', r.versao ? 'código v' + r.versao : '');
    const nomes = { tipo: 'Tipo', localidade: 'Localidade', fantasia: 'Nome fantasia', razao: 'Razão social', telefone: 'Telefone', servicoSgf: 'Serviço SGF', servico: 'Serviço', sla: 'SLA', site: 'Site', texto: 'Texto', assunto: 'Assunto', formulario: 'Formulário' };
    if (!r.ok) { etapa(1, 'erro', (r.falhas || []).map((f) => nomes[f] || f).join(', ')); msg('Alguns campos não foram preenchidos. Confira no OTRS.', true); }
    else etapa(1, 'ok');
    etapa(2, 'vez', 'confira e envie');
  };

  $('c-limpar').onclick = () => {
    c = { fontes: {} }; textoEditado = false; assuntoEditado = false;
    $('c-etapas').hidden = true;
    render(); salvar();
  };

  // ---------- início ----------
  (async () => {
    aj = { ...AJUSTES_PADRAO, ...((await get('com_ajustes')) || {}) };
    const s = await get('com_atual');
    if (s && s.c) {
      c = { fontes: {}, ...s.c }; textoEditado = !!s.textoEditado; assuntoEditado = !!s.assuntoEditado;
      if (textoEditado) $('c-texto').value = s.texto || '';
      if (assuntoEditado) $('c-assunto').value = s.assunto || '';
    }
    render();
    if ((await get('noc_modo')) === 'comercial') modo(true);
  })();

  self.__comercial = { extrairCliente }; // testes
})();
