/* changelog.js — o que mudou em cada versão (aparece no Guia). */
self.ARION_CHANGELOG = [
  {
    versao: "2.0.0-alpha.16",
    resumo: "Comercial preenche a planilha sozinho",
    itens: [
      "Comercial · Preencher planilha: com a CSTI-CHAMADOS-COMERCIAL aberta numa aba, a Central acha a 1ª linha vazia da coluna A e preenche CHAMADO, NOME DO CLIENTE, EMPRESA, DATA e HORA, nessa ordem. Depois confere o Chamado.",
      "Chamado entra como texto (o Excel guarda só 15 dígitos). Se falhar, a linha fica copiada como tabela para colar com Ctrl+V.",
      "Chrome/Edge: permissão nova de depuração (faixa amarela enquanto preenche). Firefox: só a cópia.",
    ],
  },
  {
    versao: "2.0.0-alpha.15",
    resumo: "Comercial (teste) e Tratativa de Qualidade",
    itens: [
      "Categorização · aba Comercial (teste): Capturar chamado (número, cliente, empresa, contato, e-mail, descrição, data e hora), Preencher planilha (copia a linha A–E) e Abrir chamado (Novo chamado de Restauração/Solicitação, preenche sem enviar).",
      "Atacado · Solicitação de Tratativa de Qualidade: categoriza pelo cliente do título, mantém o título em Título e Assunto e encaminha para NOC - QUALIDADE ATACADO.",
    ],
  },
  {
    versao: "2.0.0-alpha.14",
    resumo: "Categorizar mais rápido, Confins (CNF) e correções",
    itens: [
      "Categorizar mais rápido: espera o OTRS terminar em vez de pausas fixas e pula tentativas que não selecionaram. O tempo aparece no fim.",
      "Cliente novo Arcos Dourados - CNF (Confins, POP): escolhido sozinho com CNF ou Confins no chamado; no Encaminhar, escolha OPE - FIELD SERVICES ou NOC - SUPORTE AVANÇADO.",
      "Cadastro no CMDB: Empresa vem só da Rede parceira; Título e Assunto entram depois de clicar fora, sem o OTRS escrever por cima.",
      "Localidade: confere com a lista do OTRS (137) e aceita traço com ou sem espaço.",
      "Inspeção de Voos: planilha .csv com data e horário certos (antes adiantava ~3 h).",
      "Descrição da extensão atualizada.",
    ],
  },
  {
    versao: "2.0.0-alpha.13",
    resumo: "Cadastro no CMDB no Categorizar",
    itens: [
      "Categorizar: novo modelo Solicitação · Cadastro no CMDB. Reconhece \"CMDB\" no chamado.",
      "Localidade Não Geográficos (Urbanos); com a palavra \"aeroporto\", Não Geográficos (Aeroportos).",
      "Preenche Tipo Solicitação, Empresa (razão e fantasia), Serviço SGF e Serviço Internet, SLA 24 Horas 24x7 e Site NGO.",
      "Título e Assunto: Não Geográficos (Urbanos) - EMPRESA - SOLICITAÇÃO - INTERNET - CADASTRO NO CMDB.",
      "Encaminhar: nota e fila NOC - ACESSOS E CADASTROS.",
    ],
  },
  {
    versao: "2.0.0-alpha.12",
    resumo: "Cancelar Serviços (NGO) no Categorizar e barra só de ícones",
    itens: [
      "Categorizar: novo modelo Cancelar Serviços · NGO. Reconhece \"Cancelar Serviços do Pedido: N\" e lê Razão social, Nome fantasia, Telefone, CNPJ, Contato e produtos.",
      "POP (GRU, GIG, BSB, CNF, VCP, FLN, MEA, VIX, POA, FOR, Congonhas, Curitiba, Cuiabá, NAT): avisa e não categoriza.",
      "Fora dos POP: Localidade Não Geográficos (Urbanos), Enviar N1 = Sim e texto padrão.",
      "Título e Assunto = máscara: Não Geográficos (Urbanos) - RAZÃO SOCIAL - CANCELAMENTO - INTERNET - Pedido: N.",
      "Encaminhar: nota (ISP = Não) e fila NOC - CANCELAMENTOS NGO.",
      "Barra rápida: pílula só de ícones; a aba aberta mostra o nome. Site aberto: ponto verde.",
    ],
  },
  {
    versao: "2.0.0-alpha.11",
    resumo: "Barra de vidro, nomes novos e textos revisados",
    itens: [
      "Barra rápida de vidro: Início · ServiceAide (Copiar, Abrir, Voos) · OTRS (Categorizar). O grupo do site aberto fica verde.",
      "Nomes novos: Copiar Chamado, Categorização, Abertura de Chamados e Inspeção de Voos.",
      "Copiar Chamado: só a máscara, editável ao clicar. Copiar leva as edições; Limpar ao lado.",
      "Abertura de Chamados: engrenagem ao lado de Equipamento abre a lista de equipamentos. Telefone opcional.",
      "Categorização: FUST no grupo Projetos, Localidade 'Projeto FUST'.",
      "Textos revisados em todas as ferramentas.",
    ],
  },
  {
    versao: "2.0.0-alpha.10",
    resumo: "Firefox: NOC, Chamados e Voos acham os scripts da página",
    itens: [
      "Firefox: corrigido 'não encontrou o page.js'. Os scripts usam o caminho a partir da raiz da extensão.",
      "Vale para NOC (OTRS), Chamados e Voos (ServiceAide).",
    ],
  },
  {
    versao: "2.0.0-alpha.9",
    resumo: "Copiar do Chamados = Capturar + Copiar",
    itens: [
      "Chamados: o botão Copiar do Texto do chamado captura o chamado aberto no ServiceAide e copia em seguida.",
      "Sem ServiceAide aberto, copia o que está no painel e avisa.",
    ],
  },
  {
    versao: "2.0.0-alpha.8",
    resumo: "Texto do chamado no modelo da Máscara",
    itens: [
      "Chamados: Texto do chamado sai no mesmo modelo da máscara (Chamado, Atendente, Solicitante, Ramal, E-mail, Localização, Violação SLA, Descrição).",
      "Ao copiar, lê o número do chamado e o SLA no ServiceAide. Atendente vem das Configurações da Máscara.",
    ],
  },
  {
    versao: "2.0.0-alpha.7",
    resumo: "NOC no Firefox: leitura do chamado com plano B",
    itens: [
      "NOC: se a leitura principal voltar vazia (Firefox), lê o chamado direto da página.",
      "NOC: erros dentro do OTRS aparecem com o motivo, em vez de 'não tem TicketID'.",
    ],
  },
  {
    versao: "2.0.0-alpha.6",
    resumo: "Correção do NOC no Firefox",
    itens: [
      "Firefox: o NOC voltou a ler o OTRS. O pedido de acesso agora inclui só o OTRS.",
      "Firefox: o NOC avisa quando falta acesso ao OTRS, já ao abrir.",
      "Início: botão Permitir acesso quando falta liberar o OTRS e o ServiceAide.",
    ],
  },
  {
    versao: "2.0.0-alpha.5",
    resumo: "Trocar tema com prévia · 5 temas",
    itens: [
      "Início → ⋯ → Trocar tema: passe o mouse para ver os temas.",
      "Passar o mouse num tema aplica na hora e mostra a prévia das 4 ferramentas. Clique para usar.",
      "Temas: Claro, Escuro, Areia, Noite azul e Alto contraste.",
    ],
  },
  {
    versao: "2.0.0-alpha.4",
    resumo: "Localidade Não Geográficos · Máscara mais limpa · Localizações sugeridas",
    itens: [
      "NOC: Carrefour, McDonald's, FUST e Diversos usam a Localidade Não Geográficos (Urbanos). O Cliente vale só para a máscara.",
      "NOC: Algar mantém Projeto EILD Algar - UF.",
      "NOC: depois de escolher a Localidade, a Central clica fora para fechar a lista.",
      "Máscara: sem Grupo WhatsApp, Técnico e Enviar no WhatsApp. Dados capturados aparecem completos.",
      "Chamados: Localização sugere as já digitadas.",
      "Chamados: equipamento repetido (sem acento, maiúscula ou espaço extra) mostra Já existe.",
      "Campos de seleção: botão dentro do rótulo não abre mais a lista.",
    ],
  },
  {
    versao: "2.0.0-alpha.3",
    resumo: "Aviso automático de versão nova pelo GitHub",
    itens: [
      "Confere o GitHub a cada 6 horas e ao abrir o navegador.",
      "Versão nova: selo no ícone, notificação e aviso no Início com o botão Baixar.",
      "Sem configurar nada. Outro endereço: Início → ⋯ → Verificar atualização.",
    ],
  },
  {
    versao: "2.0.0-alpha.2",
    resumo: "Telas iguais ao protótipo · Menos botões · Mesmas funções",
    itens: [
      "Início: ⋯ no topo, ferramenta sugerida e próximo alarme dos Voos.",
      "Máscara: engrenagem para Configurações; dados resumidos com Editar; Copiar e Enviar no WhatsApp.",
      "NOC: Atacado / Suporte TI em um toque; Categorizar e Encaminhar lado a lado.",
      "Chamados: Solicitante e Chamado em dois cartões; Localizar dentro do Nome; ⋯ com Capturar, Equipamentos e Limpar.",
      "Voos: próximo alarme em destaque; cartão com Colar insp., Colar acomp. e Informe; abas Voos · Alarmes · Ajustes.",
      "Alarmes: Meus alarmes e Alarmes de voo; antecedência e som na mesma tela.",
    ],
  },
  {
    versao: "2.0.0-alpha.1",
    resumo: "Visual minimalista · Abas embaixo · Ferramenta sugerida",
    itens: [
      "Visual minimalista, tema claro por padrão.",
      "Abas embaixo: Início, Máscara, NOC, Chamados, Voos.",
      "Menu ⋯ no Início: tema, lateral/bandeja, abrir em aba, ajuda, relatar, atualização e limpar.",
      "Início mostra a ferramenta da aba aberta como Sugerida.",
      "Ação principal em preto. Laranja = próximo passo. Verde = concluído.",
      "Mesmas funções da 1.3.3.",
    ],
  },
  {
    versao: "1.3.3-teste",
    itens: [
      "NOC: escolha o tipo de chamado no topo (NOC Atacado ou Suporte TI (Engenharia)).",
      "NOC: novas máscaras — Cancelamento, Reincidência, Bradesco (Vivo e Telmex), McDonald's e Projeto Carrefour.",
      "NOC: \"Não Geográficos (Urbanos)\" abre a escolha do cliente. O identificador muda conforme o modelo (CI, BRAD, SIGLA, NP).",
      "NOC: Suporte TI (Engenharia) categoriza e encaminha para ENG - SISTEMAS.",
      "Voos · Alarme: listas separadas — Meus alarmes e Alarmes de voo.",
      "Voos · Alarme: alarme adiado aparece como Agendado.",
      "Voos · Alarme: 10 sons para escolher, com nomes simples, incluindo avião decolando.",
      "Máscara: removidos o Connecta (Smart IT), as permissões onbmc.com e a lista de nomes no campo Técnico.",
      "Todos os campos de seleção aceitam digitar para filtrar as opções.",
    ],
  },
  {
    versao: "1.3.2-teste",
    itens: [
      "Chamados: o e-mail digitado pelo usuário não é mais sobrescrito pelo e-mail do solicitante.",
      "Chamados: Departamento com sugestões ao digitar (41 departamentos do ServiceAide).",
    ],
  },
  {
    versao: "1.3.1-teste",
    itens: [
      "Voos · Alarme: botão + abre um modal para criar tarefas e lembretes (ex.: passagem de turno), com repetição diária ou seg a sex.",
      "Voos · Alarme: \"Partida HH:MM ↗\" leva ao voo e destaca, com um pulso, o botão de colar certo.",
      "Chamados: botão Localizar no Nome — avisa se encontrou nome e sobrenome e não repete a busca ao preencher.",
    ],
  },
  {
    versao: "1.3.0-teste",
    itens: [
      "Visual padronizado nas 4 ferramentas: mesmo cabeçalho, cores, fontes, botões e campos.",
      "Tema claro/escuro único, trocado no trilho (☀/☾).",
      "Fontes locais: não depende mais do Google Fonts nem de internet.",
      "Segurança: textos da planilha e das páginas são tratados antes de aparecer na tela.",
      "Biblioteca de planilhas atualizada (SheetJS 0.20.3).",
      "Dados de chamados e solicitantes apagados após 7 dias.",
      "Aviso de versão nova pela intranet (opcional).",
    ],
  },
  { versao: "1.2.0", itens: ["Botão para recolher a barra (Alt+0)."] },
  { versao: "1.1.0", itens: ["Modo bandeja ou fixado na lateral."] },
  { versao: "1.0.0", itens: ["Primeira versão: 4 extensões em uma, navegação por ícones e guia."] },
];
