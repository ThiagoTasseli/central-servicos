/* changelog.js — o que mudou em cada versão (aparece no Guia). */
self.ARION_CHANGELOG = [
  {
    versao: "2.0.0-alpha.4",
    resumo: "Localidade Não Geográficos · Máscara mais limpa · Localizações sugeridas",
    itens: [
      "NOC: Carrefour, McDonald's, FUST e Diversos usam a Localidade Não Geográficos (Urbanos). O Cliente vale só para a máscara.",
      "NOC: Algar mantém Projeto EILD Algar - UF.",
      "NOC: depois de escolher a Localidade, a Central clica fora para fechar a lista.",
      "Máscara: sem Grupo WhatsApp, Técnico e Enviar no WhatsApp. Dados capturados aparecem completos.",
      "Chamados: Localização sugere as já digitadas.",
      "Chamados: equipamento repetido (sem acento, maiúscula ou espaço extra) mostra Já existe.",
      "Campos de seleção: botão dentro do rótulo não abre mais a lista.",
    ],
  },
  {
    versao: "2.0.0-alpha.3",
    resumo: "Aviso automático de versão nova pelo GitHub",
    itens: [
      "Confere o GitHub a cada 6 horas e ao abrir o navegador.",
      "Versão nova: selo no ícone, notificação e aviso no Início com o botão Baixar.",
      "Sem configurar nada. Outro endereço: Início → ⋯ → Verificar atualização.",
    ],
  },
  {
    versao: "2.0.0-alpha.2",
    resumo: "Telas iguais ao protótipo · Menos botões · Mesmas funções",
    itens: [
      "Início: ⋯ no topo, ferramenta sugerida e próximo alarme dos Voos.",
      "Máscara: engrenagem para Configurações; dados resumidos com Editar; Copiar e Enviar no WhatsApp.",
      "NOC: Atacado / Suporte TI em um toque; Categorizar e Encaminhar lado a lado.",
      "Chamados: Solicitante e Chamado em dois cartões; Localizar dentro do Nome; ⋯ com Capturar, Equipamentos e Limpar.",
      "Voos: próximo alarme em destaque; cartão com Colar insp., Colar acomp. e Informe; abas Voos · Alarmes · Ajustes.",
      "Alarmes: Meus alarmes e Alarmes de voo; antecedência e som na mesma tela.",
    ],
  },
  {
    versao: "2.0.0-alpha.1",
    resumo: "Visual minimalista · Abas embaixo · Ferramenta sugerida",
    itens: [
      "Visual minimalista, tema claro por padrão.",
      "Abas embaixo: Início, Máscara, NOC, Chamados, Voos.",
      "Menu ⋯ no Início: tema, lateral/bandeja, abrir em aba, ajuda, relatar, atualização e limpar.",
      "Início mostra a ferramenta da aba aberta como Sugerida.",
      "Ação principal em preto. Laranja = próximo passo. Verde = concluído.",
      "Mesmas funções da 1.3.3.",
    ],
  },
  {
    versao: "1.3.3-teste",
    itens: [
      "NOC: escolha o tipo de chamado no topo (NOC Atacado ou Suporte TI (Engenharia)).",
      "NOC: novas máscaras — Cancelamento, Reincidência, Bradesco (Vivo e Telmex), McDonald's e Projeto Carrefour.",
      "NOC: \"Não Geográficos (Urbanos)\" abre a escolha do cliente. O identificador muda conforme o modelo (CI, BRAD, SIGLA, NP).",
      "NOC: Suporte TI (Engenharia) categoriza e encaminha para ENG - SISTEMAS.",
      "Voos · Alarme: listas separadas — Meus alarmes e Alarmes de voo.",
      "Voos · Alarme: alarme adiado aparece como Agendado.",
      "Voos · Alarme: 10 sons para escolher, com nomes simples, incluindo avião decolando.",
      "Máscara: removidos o Connecta (Smart IT), as permissões onbmc.com e a lista de nomes no campo Técnico.",
      "Todos os campos de seleção aceitam digitar para filtrar as opções.",
    ],
  },
  {
    versao: "1.3.2-teste",
    itens: [
      "Chamados: o e-mail digitado pelo usuário não é mais sobrescrito pelo e-mail do solicitante.",
      "Chamados: Departamento com sugestões ao digitar (41 departamentos do ServiceAide).",
    ],
  },
  {
    versao: "1.3.1-teste",
    itens: [
      "Voos · Alarme: botão + abre um modal para criar tarefas e lembretes (ex.: passagem de turno), com repetição diária ou seg a sex.",
      "Voos · Alarme: \"Partida HH:MM ↗\" leva ao voo e destaca, com um pulso, o botão de colar certo.",
      "Chamados: botão Localizar no Nome — avisa se encontrou nome e sobrenome e não repete a busca ao preencher.",
    ],
  },
  {
    versao: "1.3.0-teste",
    itens: [
      "Visual padronizado nas 4 ferramentas: mesmo cabeçalho, cores, fontes, botões e campos.",
      "Tema claro/escuro único, trocado no trilho (☀/☾).",
      "Fontes locais: não depende mais do Google Fonts nem de internet.",
      "Segurança: textos da planilha e das páginas são tratados antes de aparecer na tela.",
      "Biblioteca de planilhas atualizada (SheetJS 0.20.3).",
      "Dados de chamados e solicitantes apagados após 7 dias.",
      "Aviso de versão nova pela intranet (opcional).",
    ],
  },
  { versao: "1.2.0", itens: ["Botão para recolher a barra (Alt+0)."] },
  { versao: "1.1.0", itens: ["Modo bandeja ou fixado na lateral."] },
  { versao: "1.0.0", itens: ["Primeira versão: 4 extensões em uma, navegação por ícones e guia."] },
];
