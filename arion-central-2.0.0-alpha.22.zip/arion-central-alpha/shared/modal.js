/* modal.js — janela (modal) padrão da Central para cadastros e confirmações.
 * ArionModal.form({ titulo, texto, campos:[{id,label,value,placeholder}], ok }) → Promise<{id:valor}|null>
 * ArionModal.confirmar({ titulo, html, ok, perigo }) → Promise<boolean>
 * ArionModal.abrir({ titulo, html, aoAbrir(box, fechar) }) → Promise (resolve ao fechar)
 */
(function () {
  if (window.ArionModal) return;
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

  function abrir({ titulo, html, rodape, aoAbrir }) {
    return new Promise((resolve) => {
      const m = document.createElement('div');
      m.className = 'a-modal';
      m.setAttribute('role', 'dialog');
      m.setAttribute('aria-modal', 'true');
      m.innerHTML = `<div class="a-modal__box"><div class="a-modal__head"><h3>${esc(titulo)}</h3><button class="a-modal__x" type="button" aria-label="Fechar">✕</button></div><div class="a-modal__body">${html || ''}</div>${rodape ? `<div class="a-modal__foot">${rodape}</div>` : ''}</div>`;
      document.body.appendChild(m);
      let feito = false;
      const fechar = (v) => {
        if (feito) return; feito = true;
        document.removeEventListener('keydown', tecla, true);
        m.remove(); resolve(v);
      };
      const tecla = (e) => { if (e.key === 'Escape') { e.stopPropagation(); fechar(null); } };
      document.addEventListener('keydown', tecla, true);
      m.querySelector('.a-modal__x').onclick = () => fechar(null);
      m.addEventListener('mousedown', (e) => { if (e.target === m) fechar(null); });
      if (aoAbrir) aoAbrir(m.querySelector('.a-modal__box'), fechar);
    });
  }

  function form({ titulo, texto, campos, ok = 'Salvar' }) {
    const html = (texto ? `<p class="a-modal__txt">${texto}</p>` : '') + campos.map((c) =>
      `<div class="a-f"><label for="am-${c.id}">${esc(c.label)}</label>${c.area
        ? `<textarea id="am-${c.id}" rows="4" placeholder="${esc(c.placeholder || '')}">${esc(c.value || '')}</textarea>`
        : `<input id="am-${c.id}" type="text" autocomplete="off" value="${esc(c.value || '')}" placeholder="${esc(c.placeholder || '')}">`}</div>`).join('');
    const rodape = `<button class="a-btn a-btn--gh" data-r="0" type="button">Cancelar</button><button class="a-btn a-btn--pri" data-r="1" type="button">${esc(ok)}</button>`;
    return abrir({
      titulo, html, rodape,
      aoAbrir(box, fechar) {
        const val = () => Object.fromEntries(campos.map((c) => [c.id, box.querySelector('#am-' + c.id).value.trim()]));
        const enviar = () => {
          const v = val();
          const falta = campos.find((c) => c.obrigatorio !== false && !v[c.id]);
          if (falta) { const el = box.querySelector('#am-' + falta.id); el.closest('.a-f').classList.add('erro'); el.focus(); return; }
          fechar(v);
        };
        box.querySelector('[data-r="0"]').onclick = () => fechar(null);
        box.querySelector('[data-r="1"]').onclick = enviar;
        box.querySelectorAll('input').forEach((i) => i.addEventListener('keydown', (e) => { if (e.key === 'Enter') enviar(); }));
        const p = box.querySelector('input, textarea');
        if (p) setTimeout(() => { p.focus(); p.select && p.select(); }, 30);
      },
    });
  }

  function confirmar({ titulo, html, ok = 'Confirmar', perigo }) {
    const rodape = `<button class="a-btn a-btn--gh" data-r="0" type="button">Cancelar</button><button class="a-btn ${perigo ? 'a-btn--acc' : 'a-btn--pri'}" data-r="1" type="button">${esc(ok)}</button>`;
    return abrir({
      titulo, html: `<div class="a-modal__txt">${html}</div>`, rodape,
      aoAbrir(box, fechar) {
        box.querySelector('[data-r="0"]').onclick = () => fechar(false);
        box.querySelector('[data-r="1"]').onclick = () => fechar(true);
        setTimeout(() => box.querySelector('[data-r="1"]').focus(), 30);
      },
    }).then((v) => v === true);
  }

  window.ArionModal = { abrir, form, confirmar, esc };
})();
