/* encaminhar.js — aba "Encaminhar" da Categorização (alpha.19).
 * Encaminha o chamado aberto para QUALQUER fila do OTRS:
 *   1. Nota de encaminhamento (preenche e envia)   2. Mover para a fila (com confirmação).
 * As filas vêm do próprio OTRS (campo "- Mover -" do chamado) e ficam guardadas.
 */
(function () {
  const $ = (id) => document.getElementById(id);
  const R = self.Regras;
  const M = window.ArionModal;
  const get = (k) => new Promise((r) => chrome.storage.local.get(k, (v) => r(v[k])));
  const set = (k, v) => new Promise((r) => chrome.storage.local.set({ [k]: v }, r));
  const msg = (t, erro) => { try { window.__noc.toast(t, erro); } catch (_) {} };
  const tk = () => (window.__noc && window.__noc.ticket) || null;
  // Hífen, travessão e meia-risca contam como iguais ("METRO – FIELD" = "metro - field").
  const norm = (s) => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[\u2012-\u2015\u2212]/g, '-').replace(/\s+/g, ' ').toLowerCase();

  // Filas do OTRS (lista de 09/11). "Atualizar filas" lê de novo do chamado.
  const CONHECIDAS = [
    'COM - ATACADO',
    'COM - CIDADES PRIVADAS',
    'COM - ENTERPRISE',
    'COM - INFRAESTRUTURA',
    'COM - OPERADORA - CONTRATAÇÃO DE CIRCUITO',
    'ENG - REDES',
    'ENG - SISTEMAS',
    'ENG - TI',
    'FIN - FINANCEIRO',
    'FIN – BLOQUEIO FINANCEIRO',
    'IMPLANTAÇÃO',
    'METRO - ENGENHARIA',
    'METRO - SUPORTE AVANÇADO',
    'METRO – FIELD',
    'METRO – PENDENTE',
    'Monitoramento Análise N3',
    'Monitoramento Crítico',
    'Monitoramento Vip',
    'NOC - ACESSOS E CADASTROS',
    'NOC - ATACADO',
    'NOC - BLOQUEIO DE CLIENTES',
    'NOC - CANCELAMENTOS NGO',
    'NOC - N3 PENDENTES',
    'NOC - PENDENTES',
    'NOC - QUALIDADE ATACADO',
    'NOC - RETIRA EQUIPAMENTO',
    'NOC - SERVICE DESK',
    'NOC - SUPORTE AVANÇADO',
    'NOC – PENDENTE PAGAMENTO',
    'OPE - FIELD SERVICES',
    'OPE - PENDENTES',
    'PRÉ - PRÉ VENDA',
    'PÓS - AEROPORTOS',
    'PÓS - CANCELAMENTOS',
    'PÓS - NGO',
    'PÓS - OPERADORAS',
    'PÓS – MIGRAÇÃO / REPARO',
    'RH - RECURSOS HUMANOS',
  ];

  let filas = CONHECIDAS.slice();
  let st = { fila: '', etapa: '' };   // etapa: '' → 'nota' → 'ok'
  let notaEditada = false;
  let atualId = '';

  // ---------- modo ----------
  const bEnc = document.querySelector('#aTipo button[data-modo="encaminhar"]');
  const bCom = document.querySelector('#aTipo button[data-modo="comercial"]');
  function modo(on, salvar = true) {
    document.body.classList.toggle('modo-enc', on);
    $('encaminhar').hidden = !on;
    bEnc.classList.toggle('on', on);
    if (on) {
      document.body.classList.remove('modo-comercial');
      $('comercial').hidden = true;
      bCom.classList.remove('on');
      carregarFilas(false);
    }
    if (salvar) set('noc_modo', on ? 'encaminhar' : '');
  }
  bEnc.addEventListener('click', () => modo(true));
  bCom.addEventListener('click', () => modo(false, false));
  document.querySelectorAll('#aTipo button[data-tipo]').forEach((b) => b.addEventListener('click', () => modo(false)));

  // ---------- filas ----------
  async function carregarFilas(forcar) {
    const cache = await get('otrs_filas');
    if (cache && cache.lista && cache.lista.length) filas = cache.lista;
    $('e-n').textContent = `${filas.length} filas`;
    const t = tk();
    if (!t || !t.ticketId) return;
    if (!forcar && cache && cache.lista && Date.now() - (cache.ts || 0) < 12 * 3600e3) return;
    const r = await OTRS.filas(t.ticketId).catch((e) => ({ ok: false, erro: e.message }));
    if (r && r.ok && r.filas && r.filas.length) {
      filas = r.filas;
      await set('otrs_filas', { lista: filas, ts: Date.now() });
      $('e-n').textContent = `${filas.length} filas`;
      if (forcar) msg(`${filas.length} filas lidas do OTRS`);
    } else if (forcar) msg((r && r.erro) || 'Não consegui ler as filas do chamado', true);
  }
  $('e-recarregar').onclick = () => carregarFilas(true);

  // ---------- busca (igual à Localidade) ----------
  const inp = $('e-fila'), ul = $('e-list');
  let ativo = 0, achadas = [];
  function sugerir() {
    const q = norm(inp.value.trim());
    achadas = q ? filas.filter((f) => norm(f).includes(q)).slice(0, 12) : filas.slice(0, 12);
    ativo = 0;
    ul.innerHTML = achadas.length
      ? achadas.map((f, i) => {
          const n = norm(f), k = q ? n.indexOf(q) : -1;
          const html = k >= 0 ? M.esc(f.slice(0, k)) + '<b>' + M.esc(f.slice(k, k + q.length)) + '</b>' + M.esc(f.slice(k + q.length)) : M.esc(f);
          return `<li role="option" data-i="${i}" class="${i === 0 ? 'on' : ''}">${html}</li>`;
        }).join('')
      : '<li class="vazio">Nenhuma fila com esse nome</li>';
    ul.hidden = false;
  }
  function escolher(f) {
    inp.value = f;
    ul.hidden = true;
    if (st.fila !== f) { st = { fila: f, etapa: '' }; salvar(); }
    refazerNota(true);
    render();
  }
  inp.addEventListener('focus', sugerir);
  inp.addEventListener('input', () => { sugerir(); if (st.fila && inp.value !== st.fila) { st = { fila: '', etapa: '' }; render(); } });
  inp.addEventListener('keydown', (e) => {
    if (ul.hidden) return;
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      ativo = Math.max(0, Math.min(achadas.length - 1, ativo + (e.key === 'ArrowDown' ? 1 : -1)));
      ul.querySelectorAll('li').forEach((li, i) => li.classList.toggle('on', i === ativo));
    } else if (e.key === 'Enter' && achadas[ativo]) { e.preventDefault(); escolher(achadas[ativo]); }
    else if (e.key === 'Escape') ul.hidden = true;
  });
  ul.addEventListener('mousedown', (e) => { const li = e.target.closest('li[data-i]'); if (li) { e.preventDefault(); escolher(achadas[+li.dataset.i]); } });
  inp.addEventListener('blur', () => setTimeout(() => (ul.hidden = true), 120));

  // ---------- nota ----------
  const notaPadrao = (f) => `Arion - Central de Atendimento\nTicket encaminhado para a equipe: ${f || '<FILA>'}\nGentileza prosseguir com a tratativa.`;
  function refazerNota(forcar) {
    if (notaEditada && !forcar) return;
    notaEditada = false;
    $('e-nota').value = notaPadrao(st.fila);
  }
  $('e-nota').addEventListener('input', () => (notaEditada = true));
  $('e-refaz').onclick = () => refazerNota(true);
  const notaHtml = () => $('e-nota').value.split('\n').map((l) => l.trim()).filter(Boolean)
    .map((l, i) => i === 0 ? `<p><strong>${M.esc(l)}</strong></p>` : `<p>${M.esc(l)}</p>`).join('');

  // ---------- estado por chamado ----------
  const chave = () => 'enc_' + (tk() && tk().ticketId);
  const salvar = () => tk() && set(chave(), st);
  async function trocouTicket() {
    const t = tk();
    const id = t && t.ticketId ? t.ticketId : '';
    if (id === atualId) return;
    atualId = id;
    st = (id && (await get(chave()))) || { fila: '', etapa: '' };
    inp.value = st.fila || '';
    refazerNota(true);
    render();
    if (id && !$('encaminhar').hidden) carregarFilas(false);
  }

  function render() {
    const t = tk();
    $('e-dot').classList.toggle('a-dot--off', !t);
    $('e-ctx-t').textContent = t ? `Ticket#${t.numero || t.ticketId}` : 'Abra o chamado no OTRS';
    const f = st.fila;
    const p = [
      ['Nota de encaminhamento', st.etapa === 'nota' || st.etapa === 'ok' ? 'ok' : f ? 'vez' : ''],
      [`Mover para ${f || 'a fila'}`, st.etapa === 'ok' ? 'ok' : st.etapa === 'nota' ? 'vez' : ''],
    ];
    $('e-passos').innerHTML = p.map(([t2, c], i) => `<li class="${c}"><i>${c === 'ok' ? '✓' : i + 1}</i>${M.esc(t2)}</li>`).join('');
    const b = $('e-btn');
    b.disabled = !t || !f || st.etapa === 'ok';
    b.className = 'a-btn ' + (st.etapa === 'ok' ? 'a-btn--done' : st.etapa === 'nota' ? 'a-btn--acc' : 'a-btn--pri');
    b.textContent = st.etapa === 'ok' ? `Encaminhado para ${f}` : st.etapa === 'nota' ? `Mover para ${f}` : 'Encaminhar';
  }

  // ---------- ação ----------
  $('e-btn').onclick = async () => {
    const t = tk();
    if (!t || !st.fila) return;
    if (!filas.includes(st.fila)) return msg('Escolha uma fila da lista', true);
    const b = $('e-btn');

    if (st.etapa === '') {
      const ok = await M.confirmar({
        titulo: 'Encaminhar o chamado?',
        html: `1. Envia a nota de encaminhamento.<br>2. Depois você confirma o Mover para <b>${M.esc(st.fila)}</b>.`,
        ok: 'Enviar nota',
      });
      if (!ok) return;
      b.disabled = true; b.textContent = 'Enviando nota…';
      const r = await OTRS.nota(t.ticketId, { assunto: R.ASSUNTO_NOTA, texto: notaHtml(), enviar: true, isp: false })
        .catch((e) => ({ ok: false, erro: e.message }));
      if (!r || r.erro || !r.ok) { render(); return msg((r && (r.erro || (r.falhas || []).join(', '))) || 'Nota não preenchida', true); }
      st.etapa = 'nota'; await salvar(); render();
      msg(r.enviado ? 'Nota enviada. Agora confirme o Mover.' : 'Nota preenchida: confira e clique em Enviar no OTRS.');
      return;
    }

    if (st.etapa === 'nota') {
      const ok = await M.confirmar({
        titulo: `Mover para ${st.fila}?`,
        html: 'O chamado sai da fila atual. <b>Não tem desfazer.</b>',
        ok: 'Mover', perigo: true,
      });
      if (!ok) return;
      b.disabled = true; b.textContent = 'Movendo…';
      const r = await OTRS.mover(t.ticketId, st.fila).catch((e) => ({ ok: false, erro: e.message }));
      if (!r || !r.ok) { render(); return msg((r && (r.erro || (r.falhas || []).join(', '))) || 'Não moveu', true); }
      st.etapa = 'ok'; await salvar(); render();
      msg(`Movido para ${st.fila}`);
    }
  };

  // ---------- início ----------
  setInterval(trocouTicket, 800);
  refazerNota(true);
  render();
  get('noc_modo').then((m) => { if (m === 'encaminhar') modo(true, false); });
})();
