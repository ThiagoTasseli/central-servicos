/* alpha-voos.js — visual minimalista (Alpha) da Central de Voos.
 * Lê o estado do popup.js (filteredFlights, customAlarms…) e só desenha:
 * próximo alarme, contadores das abas, subtítulo e antecedência.
 */
(function () {
  const $ = (id) => document.getElementById(id);
  const A = self.Alarms;
  const DIAS = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];
  const MESES = ["jan", "fev", "mar", "abr", "mai", "jun", "jul", "ago", "set", "out", "nov", "dez"];
  const esc = (t) => String(t ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const hhmm = (ts) => new Date(ts).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });

  // Importar planilha pelo ícone do cabeçalho
  $("a-upload").addEventListener("click", () => $("file-input").click());

  // Antecedência padrão (15 / 10 min antes) abre o ajuste
  $("a-antec").addEventListener("click", () => {
    const box = $("a-antec-box");
    box.hidden = !box.hidden;
    $("a-antec").setAttribute("aria-expanded", String(!box.hidden));
  });

  function emQuanto(ms) {
    const min = Math.round(ms / 60000);
    if (min < 1) return "agora";
    if (min < 60) return `em ${min} min`;
    const h = Math.floor(min / 60), m = min % 60;
    return `em ${h} h${m ? " " + m + " min" : ""}`;
  }

  function proximo() {
    const agora = Date.now();
    const lista = [];
    try {
      A.computeAlarmEntries(filteredFlights, currentAlarmSettings, currentAlarmOverrides)
        .filter((e) => e.enabled && e.alarmeTimestamp > agora)
        .forEach((e) => lista.push({ ts: e.alarmeTimestamp, titulo: e.kind === "inspecao" ? "Inspeção" : "Acompanhamento",
          sub: `${[e.empresa, e.numeroVoo].filter(Boolean).join(" ")} · partida ${e.horarioPartida}`, flightId: e.flightId, kind: e.kind }));
    } catch (_) {}
    try {
      customAlarms.forEach((a) => {
        const ts = A.customFireTimestamp(a, agora);
        if (ts && ts > agora) lista.push({ ts, titulo: a.titulo, sub: (A.TIPO_LABEL[a.tipo] || "Tarefa") + (a.obs ? " · " + a.obs : "") });
      });
    } catch (_) {}
    return lista.sort((x, y) => x.ts - y.ts)[0] || null;
  }

  function contar() {
    let n = 0;
    try {
      n += A.computeAlarmEntries(filteredFlights, currentAlarmSettings, currentAlarmOverrides).filter((e) => A.alarmStatus(e) === "agendado").length;
      n += customAlarms.filter((a) => A.customAlarmStatus(a) === "agendado").length;
    } catch (_) {}
    return n;
  }

  function render() {
    // Subtítulo: "Sáb, 24 out · planilha.xlsx"
    try {
      const [y, m, d] = String(selectedDate).split("-").map(Number);
      const dt = new Date(y, m - 1, d);
      const data = `${DIAS[dt.getDay()]}, ${d} ${MESES[m - 1]}`;
      $("a-file").textContent = data + (currentFileName ? " · " + currentFileName : "");
    } catch (_) {}

    // Contadores das abas
    try { $("a-cnt-voos").textContent = currentFileName ? " · " + filteredFlights.length : ""; } catch (_) {}
    const n = contar();
    $("a-cnt-alarmes").textContent = n ? " · " + n : "";

    // Próximo alarme
    const p = proximo();
    const box = $("a-next");
    box.hidden = !p;
    if (p) {
      box.innerHTML = `<div class="a-next__lab">Próximo alarme · ${emQuanto(p.ts - Date.now())}</div>
        <div class="a-next__big">${hhmm(p.ts)} ${esc(p.titulo)}</div>
        <div class="a-next__sub">${esc(p.sub)}</div>`;
      box.classList.toggle("a-next--go", !!p.flightId);
      box.onclick = p.flightId ? () => goToFlight(p.flightId, p.kind) : null;
    }

    // Antecedência
    try { $("a-antec").textContent = `${currentAlarmSettings.minutosInspecao ?? 15} / ${currentAlarmSettings.minutosAcompanhamento ?? 10} min antes`; } catch (_) {}
  }

  // Redesenha quando a lista ou os alarmes mudam, e a cada 20 s (contagem "em X min").
  const obs = new MutationObserver(() => render());
  ["flight-list", "alerts-list", "flight-alerts-list"].forEach((id) => obs.observe($(id), { childList: true }));
  setInterval(render, 20000);
  setTimeout(render, 300);
})();

/* alpha.19 — Ajustes abrem em modal, por cima da aba atual. */
(function () {
  const btn = document.getElementById("tab-config-btn");
  const painel = document.getElementById("tab-config-panel");
  if (!btn || !painel) return;
  const head = document.createElement("div");
  head.className = "a-modal__head";
  head.innerHTML = '<h3>Ajustes</h3><button class="a-modal__x" type="button" aria-label="Fechar">✕</button>';
  painel.prepend(head);
  const aberto = () => painel.classList.contains("a-cfg-modal");
  const abrir = (on) => {
    painel.classList.toggle("a-cfg-modal", on);
    painel.hidden = !on;
    painel.setAttribute("role", on ? "dialog" : "tabpanel");
  };
  btn.addEventListener("click", (e) => { e.stopImmediatePropagation(); e.preventDefault(); abrir(!aberto()); }, true);
  head.querySelector("button").addEventListener("click", () => abrir(false));
  document.getElementById("settings-save")?.addEventListener("click", () => setTimeout(() => abrir(false), 900));
  document.addEventListener("mousedown", (e) => { if (aberto() && !painel.contains(e.target) && e.target !== btn) abrir(false); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && aberto()) abrir(false); });
  head.hidden = false;
})();
