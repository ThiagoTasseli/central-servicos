/* leitor.js — Painel NOC: lê o "Painel das Filas" do OTRS (Action=AgentKPIWidget).
 * Só LÊ a tela. Não clica, não envia, não muda nada no OTRS.
 * Quem recarrega a aba a cada 30 s é a tela da TV (chrome.tabs.reload).
 * Grava em chrome.storage.local:
 *   painel_leitura → { ts, grupos: { "POOL DE ATENDIMENTO": [{rotulo, n, tipo}] }, novos: { chave: ts }, erro }
 *   painel_hist    → [{ ts, v: { chave: n } }]  (últimas 2 h, 1 ponto por minuto)
 */
(() => {
  if (window.__arionPainelLeitor) return;
  window.__arionPainelLeitor = true;

  const HIST_MS = 2 * 60 * 60 * 1000;
  const PASSO_MS = 60 * 1000;
  const NOVO_MS = 10 * 60 * 1000;
  const norm = (s) => String(s || "").replace(/\s+/g, " ").replace(/:\s*$/, "").trim();
  const chave = (g, r) => `${g}|${r}`;

  function login() {
    return !!document.querySelector("#LoginBox, form#Login, input#User[name='User']");
  }

  function pronto() {
    const gs = document.querySelectorAll("#GroupingTicket > div");
    if (!gs.length) return false;
    return document.querySelectorAll("#GroupingTicket .Loader:not(.Hidden)").length === 0;
  }

  function ler() {
    const grupos = {};
    document.querySelectorAll("#GroupingTicket > div").forEach((g) => {
      const nome = norm(g.querySelector(".GroupingHeader h1")?.textContent).toUpperCase();
      if (!nome) return;
      const caixas = [];
      g.querySelectorAll("li.SeriesBox ul.Widget > li").forEach((li) => {
        const t = li.querySelector("[id='Title'] span") || li.querySelector("[id='Title']");
        const rotulo = norm(t?.textContent);
        if (!rotulo) return;
        let el = li.querySelector("h1.NumberGraphicResult");
        let tipo = "num";
        if (!el) { el = li.querySelector("text.c3-gauge-value"); tipo = "gauge"; }
        const bruto = norm(el?.textContent);
        const m = bruto.match(/-?\d+/);
        caixas.push({ rotulo, n: m ? parseInt(m[0], 10) : null, tipo, bruto });
      });
      grupos[nome] = caixas;
    });
    return grupos;
  }

  async function gravar(grupos) {
    const ts = Date.now();
    const o = await chrome.storage.local.get(["painel_leitura", "painel_hist"]);
    const ant = o.painel_leitura && o.painel_leitura.grupos ? o.painel_leitura : null;

    // Chamado novo: a caixa do POOL subiu em relação à leitura anterior.
    const novos = {};
    const antNovos = (ant && ant.novos) || {};
    for (const [g, cx] of Object.entries(grupos)) {
      const anterior = ant && ant.grupos[g] ? ant.grupos[g] : [];
      for (const c of cx) {
        const k = chave(g, c.rotulo);
        const p = anterior.find((x) => x.rotulo === c.rotulo);
        if (/POOL/.test(g) && p && c.n != null && p.n != null && c.n > p.n) novos[k] = ts;
        else if (antNovos[k] && ts - antNovos[k] < NOVO_MS && c.n) novos[k] = antNovos[k];
      }
    }

    // Histórico para a linha de tendência.
    let hist = Array.isArray(o.painel_hist) ? o.painel_hist : [];
    hist = hist.filter((h) => ts - h.ts < HIST_MS);
    const v = {};
    for (const [g, cx] of Object.entries(grupos)) for (const c of cx) if (c.n != null) v[chave(g, c.rotulo)] = c.n;
    if (!hist.length || ts - hist[hist.length - 1].ts >= PASSO_MS) hist.push({ ts, v });
    else hist[hist.length - 1] = { ts: hist[hist.length - 1].ts, v };

    await chrome.storage.local.set({
      painel_leitura: { ts, grupos, novos, erro: "" },
      painel_hist: hist,
    });
  }

  async function erro(msg) {
    const o = await chrome.storage.local.get("painel_leitura");
    const l = o.painel_leitura || {};
    await chrome.storage.local.set({ painel_leitura: { ...l, erro: msg, tsErro: Date.now() } });
  }

  const ini = Date.now();
  (function tentar() {
    if (login()) return erro("login");
    if (pronto()) {
      // pequena folga para o último número desenhar
      return setTimeout(() => gravar(ler()).catch(() => {}), 400);
    }
    if (Date.now() - ini > 25000) return erro(document.querySelector("#GroupingTicket") ? "carga" : "tela");
    setTimeout(tentar, 500);
  })();
})();
