/* avisos.js — Tela de avisos: o Canva em tela cheia na TV do meio.
 * A Central passa os slides pelo link (…/view?embed#N), no tempo escolhido, e recarrega
 * o Canva a cada volta (ou de X em X min). Não altera nada no Canva.
 * Total de slides: lido do próprio Canva (canva-leitor.js); se não der, vale o campo "Slides".
 */
(() => {
  const P = self.PAINEL;
  const $ = (id) => document.getElementById(id);
  const root = document.documentElement;
  let cfg = { link: "", tempo: 20, slides: 4, recarregar: "volta", faixa: true };
  let leitura = null;
  let n = 1, inicioSlide = 0, ultimoReload = 0;
  let canva = { total: 0, atual: 0, visto: 0 };   // o que o Canva informou (canva-leitor.js)

  // Aceita o link de incorporação ou o código <iframe> inteiro que o Canva mostra.
  function limparLink(v) {
    v = String(v || "").trim();
    const m = v.match(/src=["']([^"']+)["']/i);
    if (m) v = m[1];
    if (v.startsWith("//")) v = "https:" + v;
    return v.replace(/#.*$/, "");
  }
  const valido = (u) => /^https:\/\/([\w-]+\.)*canva\.(com|link|site)\//i.test(u);
  const lido = () => canva.total > 0 && Date.now() - canva.visto < 120000;
  const total = () => (lido() ? canva.total : Math.max(1, +cfg.slides || 1));

  function aplicar() {
    root.classList.toggle("com-faixa", !!cfg.faixa);
    for (const [id, v] of [["c-tempo", String(cfg.tempo)], ["c-rec", String(cfg.recarregar)], ["c-faixa", cfg.faixa ? "1" : "0"]])
      $(id).querySelectorAll("button").forEach((b) => b.classList.toggle("on", b.dataset.v === v));
    $("vazio").hidden = !!cfg.link;
    $("frames").hidden = !cfg.link;
    $("pg").hidden = !cfg.link;
  }
  function salvar(m) { cfg = { ...cfg, ...m }; chrome.storage.local.set({ painel_avisos: cfg }); aplicar(); }

  // ---------- Slides ----------
  // Um iframe por slide (…#1, #2, #3…), empilhados. O próximo carrega por trás enquanto o atual
  // está na tela e entra com fade quando estiver pronto: sem tela branca na troca.
  const frames = {};             // k → { el, pronto, ts }
  let esperando = 0;             // desde quando a troca espera o próximo ficar pronto
  const FOLGA = 1500;            // depois do "load", tempo para o Canva desenhar o slide

  function frame(k) {
    if (frames[k]) return frames[k];
    const f = document.createElement("iframe");
    f.title = `Aviso ${k}`;
    f.allow = "fullscreen; autoplay";
    $("frames").appendChild(f);
    const o = { el: f, pronto: false, ts: 0 };
    f.addEventListener("load", () => {
      if (!/canva\./i.test(f.src)) return;
      setTimeout(() => { o.pronto = true; }, FOLGA);
    });
    return (frames[k] = o);
  }
  // Carrega (ou recarrega) o slide k por trás. Nunca mexe no slide que está na tela.
  function carregar(k) {
    const o = frame(k);
    o.pronto = false;
    o.ts = Date.now();
    o.el.src = "about:blank";
    setTimeout(() => { o.el.src = `${cfg.link}#${k}`; }, 60);
    if (k !== n || !o.el.classList.contains("on")) ultimoReload = Date.now();
  }
  function mostrar(k) {
    Object.entries(frames).forEach(([i, o]) => o.el.classList.toggle("on", +i === k));
    n = k;
    inicioSlide = Date.now();
    esperando = 0;
    preparar(prox(k));
    tique();
  }
  const prox = (k) => (k >= total() ? 1 : k + 1);
  // Deixa o próximo slide pronto. "A cada volta": sempre recarrega (sai atualizado);
  // 5/15/30 min: só recarrega se passou do tempo.
  function preparar(k) {
    if (k === n && total() > 1) return;
    const o = frames[k];
    const velho = !o || !o.ts || (cfg.recarregar === "volta" ? true : Date.now() - o.ts >= cfg.recarregar * 60000);
    if (velho) carregar(k);
  }
  function limparFrames() {
    Object.keys(frames).forEach((k) => { frames[k].el.remove(); delete frames[k]; });
  }
  function aparar() {   // o Canva perdeu slides: remove os que sobraram
    Object.keys(frames).forEach((k) => { if (+k > total()) { frames[k].el.remove(); delete frames[k]; } });
  }
  function iniciar() {
    limparFrames();
    if (!cfg.link) return;
    carregar(1);
    mostrar(1);   // o 1º aparece direto (preto até carregar)
  }
  function ir(k) {
    if (!cfg.link) return;
    const o = frames[k];
    if (!o || !o.ts) carregar(k);
    trocarPara = k;
    esperando = Date.now();
  }
  let trocarPara = 0;
  function proximo() { ir(prox(n)); }

  window.addEventListener("message", (e) => {
    const d = e.data;
    if (!d || !d.arionCanva || !Object.values(frames).some((o) => o.el.contentWindow === e.source)) return;
    const antes = canva.total;
    canva = { total: d.total || canva.total, atual: d.atual || 0, visto: Date.now() };
    $("c-auto").textContent = canva.total ? `${canva.total} lidos do Canva` : "";
    if (antes && canva.total < antes) aparar();
  });

  function faixa() {
    const soma = (g) => g ? g.caixas.filter((c) => c.tipo !== "gauge").reduce((s, c) => s + (c.n || 0), 0) : "–";
    const gp = P.grupo(leitura, /POOL/), gc = P.grupo(leitura, /CENTRAL DE SERV/);
    const novos = leitura && leitura.novos ? Object.entries(leitura.novos).filter(([k]) => /POOL/.test(k)).map(([, t]) => t) : [];
    const qp = $("q-pool");
    qp.className = "q" + (novos.length ? " novo" : "");
    qp.innerHTML = `POOL <b>${soma(gp)}</b>` + (novos.length ? ` · chegou ${P.hhmm(Math.max(...novos))}` : "");
    $("q-cen").innerHTML = `CENTRAL DE SERVIÇOS <b>${soma(gc)}</b>`;
  }

  function tique() {
    const agora = Date.now();
    if (cfg.link) {
      const per = cfg.tempo * 1000;
      if (!trocarPara && agora - inicioSlide >= per && total() > 1) ir(prox(n));
      if (!trocarPara && total() === 1 && cfg.recarregar !== "volta" && agora - (frames[1] ? frames[1].ts : 0) >= cfg.recarregar * 60000) carregar(1);
      if (trocarPara) {
        const o = frames[trocarPara];
        if ((o && o.pronto) || agora - esperando > 20000) { const k = trocarPara; trocarPara = 0; mostrar(k); return; }
      }
      const falta = Math.max(0, Math.ceil((per - (agora - inicioSlide)) / 1000));
      $("prog-i").style.width = Math.min(100, ((agora - inicioSlide) / per) * 100) + "%";
      $("pg").textContent = trocarPara ? `Slide ${n} de ${total()} · carregando o próximo…` : `Slide ${n} de ${total()} · troca em ${falta} s`;
    } else $("prog-i").style.width = "0";
    const velho = !leitura || !leitura.ts || agora - leitura.ts > 120000;
    $("st").className = "st" + (velho ? " off" : "");
    const otrs = leitura && leitura.ts ? `OTRS ${P.hhmm(leitura.ts)}` : "OTRS sem leitura";
    $("st-txt").textContent = cfg.link ? `${otrs} · Canva atualizado ${P.hhmm(ultimoReload)}` : otrs;
  }

  // ---------- Controles ----------
  function abrirCtl(on) {
    $("ctl").hidden = !on;
    if (on) {
      $("c-link").value = cfg.link; $("c-slides").value = cfg.slides; $("c-link-msg").textContent = "";
      $("c-auto").textContent = lido() ? `${canva.total} lidos do Canva` : "";
      setTimeout(() => $("c-link").focus(), 30);
    }
  }
  $("c-fechar").onclick = () => abrirCtl(false);
  $("ctl").addEventListener("click", (e) => { if (e.target.id === "ctl") abrirCtl(false); });
  $("c-tempo").onclick = (e) => { if (e.target.dataset.v) { salvar({ tempo: +e.target.dataset.v }); inicioSlide = Date.now(); } };
  $("c-rec").onclick = (e) => { const v = e.target.dataset.v; if (v) salvar({ recarregar: v === "volta" ? "volta" : +v }); };
  $("c-faixa").onclick = (e) => e.target.dataset.v && salvar({ faixa: e.target.dataset.v === "1" });
  $("c-salvar").onclick = () => {
    const u = limparLink($("c-link").value);
    if (u && !valido(u)) { $("c-link-msg").textContent = "Esse link não é do Canva. Use Compartilhar › Mais › Incorporar."; return; }
    const mudou = u !== cfg.link;
    salvar({ link: u, slides: Math.max(1, Math.min(50, +$("c-slides").value || cfg.slides || 4)) });
    if (mudou) { canva = { total: 0, atual: 0, visto: 0 }; iniciar(); }
    abrirCtl(false);
  };
  // Recarregar agora: atualiza por trás todos os slides que não estão na tela.
  const recarregarTudo = () => { for (let k = 1; k <= total(); k++) if (k !== n) carregar(k); if (total() === 1) carregar(1); };
  $("c-agora").onclick = () => { recarregarTudo(); abrirCtl(false); };
  $("c-cheia").onclick = () => { document.fullscreenElement ? document.exitFullscreen() : root.requestFullscreen().catch(() => {}); abrirCtl(false); };
  document.addEventListener("keydown", (e) => {
    if (e.ctrlKey || e.altKey || e.metaKey || e.target.tagName === "INPUT") { if (e.key === "Escape") abrirCtl(false); return; }
    const k = e.key.toLowerCase();
    if (k === "c") abrirCtl($("ctl").hidden);
    else if (k === "escape") abrirCtl(false);
    else if (k === "f") $("c-cheia").onclick();
    else if (k === "r") recarregarTudo();
    else if (k === "arrowright") proximo();
    else if (k === "arrowleft") ir(n > 1 ? n - 1 : total());
  });

  // ---------- Início ----------
  chrome.storage.local.get(["painel_avisos", "painel_leitura"], (o) => {
    cfg = { ...cfg, ...(o.painel_avisos || {}) };
    if (cfg.link) cfg.link = limparLink(cfg.link);
    leitura = o.painel_leitura || null;
    aplicar(); faixa();
    if (cfg.link) iniciar(); else { tique(); abrirCtl(true); }
  });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== "local") return;
    if (ch.painel_leitura) { leitura = ch.painel_leitura.newValue || null; faixa(); }
  });
  setInterval(tique, 500);
})();
