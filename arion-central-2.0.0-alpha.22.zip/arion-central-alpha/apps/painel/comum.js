/* comum.js — Painel NOC: funções usadas pela TV e pela ferramenta na Central. */
(function () {
  const KPI_URL = "https://suporte.grupoarion.com.br/otrs/index.pl?Action=AgentKPIWidget";
  const ehKpi = (u) => /suporte\.grupoarion\.com\.br\/.*Action=AgentKPIWidget/.test(u || "");

  function grupo(leitura, re) {
    if (!leitura || !leitura.grupos) return null;
    const k = Object.keys(leitura.grupos).find((n) => re.test(n));
    return k ? { nome: k, caixas: leitura.grupos[k] } : null;
  }

  // "Ticket Sem Atualizar + de 24 Hrs - PENDENTES" → "SEM ATUALIZAR + 24 H · PENDENTES"
  function rotulo(r) {
    let s = String(r || "").toUpperCase();
    const m = s.match(/SEM ATUALIZAR\s*\+\s*(?:DE\s*)?(\d+)\s*H\w*\s*-\s*(.+)/);
    if (m) return `SEM ATUALIZAR + ${m[1]} H · ${m[2].trim()}`;
    return s.replace(/\+ DE (\d+) MINUTOS?/, "+ DE $1 MIN");
  }

  // Nome para a TV: letras normais, siglas em maiúsculas. "MONITORAMENTO ANÁLISE N3" → "Monitoramento Análise N3"
  const SIGLAS = /^(NOC|OPE|N3|N2|N1|GMUD|VIP|TI|SD|CNF|NGO)$/;
  const MINUS = ["de", "da", "do", "das", "dos", "e", "h", "min"];
  function nomeTv(r) {
    return rotulo(r).toLowerCase().replace(/(^|[\s(·+\-–])([a-zà-ú0-9]+)/g, (m, a, w) =>
      a + (SIGLAS.test(w.toUpperCase()) ? w.toUpperCase() : (a.trim() !== "" || a === " ") && MINUS.includes(w) && a !== "" ? w : w[0].toUpperCase() + w.slice(1)));
  }

  function hhmm(ts, seg) {
    const d = new Date(ts);
    const p = (n) => String(n).padStart(2, "0");
    return `${p(d.getHours())}:${p(d.getMinutes())}` + (seg ? `:${p(d.getSeconds())}` : "");
  }

  async function abaKpi() {
    const tabs = await chrome.tabs.query({ url: "*://suporte.grupoarion.com.br/*" });
    return tabs.find((t) => ehKpi(t.url) || ehKpi(t.pendingUrl)) || null;
  }

  // Sigla da caixa da PASSAGEM DE TURNO: "CNF - CONFINS" → "CNF"; "METRÔ" → "METRÔ"
  const sigla = (r) => String(r || "").split(/\s+-\s+/)[0].trim().toUpperCase();

  self.PAINEL = { KPI_URL, ehKpi, grupo, rotulo, nomeTv, hhmm, abaKpi, sigla };
})();
