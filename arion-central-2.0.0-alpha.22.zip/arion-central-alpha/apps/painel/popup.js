/* popup.js — Painel NOC na Central: atalho para a TV e texto da passagem de turno. */
(() => {
  const P = self.PAINEL;
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  let leitura = null;
  let turno = { analistas: [], ultimo: "", tickets: [] };
  let editado = false;

  function toast(m) {
    const t = $("toast");
    t.textContent = m; t.hidden = false;
    clearTimeout(toast.t); toast.t = setTimeout(() => (t.hidden = true), 2200);
  }
  const guardar = () => chrome.storage.local.set({ painel_turno: turno });

  // ---------- Números ----------
  function soma(g) { return g ? g.caixas.filter((c) => c.tipo !== "gauge").reduce((s, c) => s + (c.n || 0), 0) : "–"; }
  function siglas() {
    const g = P.grupo(leitura, /PASSAGEM/);
    return g ? g.caixas.map((c) => ({ s: P.sigla(c.rotulo), n: c.n || 0 })) : [];
  }
  function mostrarLeitura() {
    const st = $("st"), txt = $("st-txt");
    if (!leitura || !leitura.ts) {
      st.className = "p-st"; txt.textContent = leitura && leitura.erro === "login" ? "OTRS deslogado" : "Sem leitura";
    } else {
      const velho = Date.now() - leitura.ts > 120000;
      st.className = "p-st " + (velho ? "off" : "ok");
      txt.textContent = (velho ? "Lido às " : "OTRS ") + P.hhmm(leitura.ts);
    }
    $("t-pool").textContent = soma(P.grupo(leitura, /POOL/));
    $("t-cen").textContent = soma(P.grupo(leitura, /CENTRAL DE SERV/));
    const ss = siglas();
    $("siglas").innerHTML = ss.length
      ? ss.map((x) => `<span class="s${x.n ? " on" : ""}">${esc(x.s)} ${x.n}</span>`).join("")
      : `<span class="a-empty">Clique em Ler agora para trazer os números.</span>`;
    $("total").textContent = ss.length ? `Total ${ss.reduce((a, x) => a + x.n, 0)}` : "";
    if (!editado) $("texto").value = texto();
  }

  // Abre o Painel das Filas em segundo plano, espera a leitura e fecha a aba (se foi aberta aqui).
  async function lerAgora() {
    const b = $("b-ler");
    b.disabled = true; b.textContent = "Lendo…";
    const ini = Date.now();
    let t = await P.abaKpi(), abriu = false;
    try {
      if (t) await chrome.tabs.reload(t.id);
      else { t = await chrome.tabs.create({ url: P.KPI_URL, active: false }); abriu = true; }
      const ok = await new Promise((res) => {
        const fim = setTimeout(() => { chrome.storage.onChanged.removeListener(f); res(false); }, 30000);
        function f(ch, area) {
          const v = area === "local" && ch.painel_leitura && ch.painel_leitura.newValue;
          if (v && (v.ts > ini || v.tsErro > ini)) { clearTimeout(fim); chrome.storage.onChanged.removeListener(f); res(v); }
        }
        chrome.storage.onChanged.addListener(f);
      });
      if (!ok) toast("O OTRS não respondeu. Confira se está logado.");
      else if (ok.erro === "login" && !(ok.ts > ini)) toast("OTRS deslogado. Entre no OTRS e tente de novo.");
      else toast("Números atualizados");
    } catch (_) {
      toast("Não consegui abrir o OTRS");
    } finally {
      if (abriu && t) chrome.tabs.remove(t.id).catch(() => {});
      b.disabled = false; b.textContent = "Ler agora";
    }
  }

  // ---------- Analistas ----------
  function desenharAnalistas() {
    const l = turno.analistas;
    $("analista").innerHTML = (l.length ? "" : `<option value="">Cadastre um analista</option>`) +
      l.map((a) => `<option${a === turno.ultimo ? " selected" : ""}>${esc(a)}</option>`).join("");
  }
  $("analista").addEventListener("change", () => { turno.ultimo = $("analista").value; guardar(); refazer(); });
  // Cadastro de analistas: modal (adicionar e remover).
  $("b-add-an").onclick = () => {
    const M = window.ArionModal;
    M.abrir({
      titulo: "Analistas",
      html: `<div class="p-linha"><input id="am-an" class="a-in" type="text" placeholder="Nome do analista" autocomplete="off"><button class="a-chip" id="am-add" type="button">Adicionar</button></div><ul class="p-an" id="am-list"></ul>`,
      aoAbrir(box) {
        const lista = () => {
          box.querySelector("#am-list").innerHTML = turno.analistas.length
            ? turno.analistas.map((a, i) => `<li><span>${M.esc(a)}</span><button type="button" data-i="${i}" aria-label="Remover">✕</button></li>`).join("")
            : `<li class="a-empty">Nenhum analista cadastrado.</li>`;
        };
        const add = () => {
          const n = box.querySelector("#am-an").value.trim().replace(/\s+/g, " ");
          if (!n) return;
          if (!turno.analistas.includes(n)) turno.analistas.push(n);
          turno.analistas.sort((a, b) => a.localeCompare(b, "pt-BR"));
          turno.ultimo = n;
          box.querySelector("#am-an").value = "";
          guardar(); desenharAnalistas(); refazer(); lista();
        };
        box.querySelector("#am-add").onclick = add;
        box.querySelector("#am-an").addEventListener("keydown", (e) => e.key === "Enter" && add());
        box.querySelector("#am-list").addEventListener("click", (e) => {
          const b = e.target.closest("[data-i]"); if (!b) return;
          const [rem] = turno.analistas.splice(+b.dataset.i, 1);
          if (turno.ultimo === rem) turno.ultimo = turno.analistas[0] || "";
          guardar(); desenharAnalistas(); refazer(); lista();
        });
        lista();
        setTimeout(() => box.querySelector("#am-an").focus(), 30);
      },
    });
  };

  // ---------- Chamados (continuidade / crítico) ----------
  function desenharTickets() {
    const l = turno.tickets;
    $("n-tk").textContent = l.length ? `${l.length}` : "";
    $("tks").innerHTML = l.length ? l.map((t, i) => `
      <div class="p-tk" data-i="${i}">
        <div class="h"><b>#${esc(t.num)}</b><small title="${esc(t.titulo)}">${esc(t.titulo)}</small><button type="button" data-x="${i}" title="Remover (fechado)">✕</button></div>
        <div class="p-tg"><button type="button" data-c="cont" class="${t.cont ? "on" : ""}">Continuidade</button><button type="button" data-c="crit" class="r${t.crit ? " on" : ""}">Crítico</button></div>
        <textarea data-s="${i}" placeholder="Status (vai no >STATUS)">${esc(t.status || "")}</textarea>
      </div>`).join("") : `<span class="a-empty">Nenhum chamado. Adicione pelo Ticket# e título.</span>`;
  }
  $("tks").addEventListener("click", (e) => {
    const x = e.target.closest("[data-x]");
    if (x) { turno.tickets.splice(+x.dataset.x, 1); guardar(); desenharTickets(); return refazer(); }
    const c = e.target.closest("[data-c]");
    if (c) {
      const t = turno.tickets[+c.closest(".p-tk").dataset.i];
      t[c.dataset.c] = !t[c.dataset.c];
      guardar(); desenharTickets(); refazer();
    }
  });
  $("tks").addEventListener("input", (e) => {
    if (e.target.dataset.s == null) return;
    turno.tickets[+e.target.dataset.s].status = e.target.value;
    guardar(); refazer();
  });
  function addTicket() {
    const num = $("tk-num").value.replace(/\D/g, "");
    const titulo = $("tk-tit").value.trim();
    if (!num || !titulo) return toast("Preencha Ticket# e título");
    if (turno.tickets.some((t) => t.num === num)) return toast("Chamado já está na lista");
    turno.tickets.push({ num, titulo, cont: true, crit: false, status: "" });
    $("tk-num").value = ""; $("tk-tit").value = "";
    guardar(); desenharTickets(); refazer();
  }
  $("b-add-tk").onclick = addTicket;
  $("tk-tit").addEventListener("keydown", (e) => e.key === "Enter" && addTicket());

  // ---------- Texto do WhatsApp ----------
  function lista(a) { return a.length <= 1 ? a.join("") : a.slice(0, -1).join(", ") + " e " + a[a.length - 1]; }
  function texto(agora = new Date()) {
    const p = (n) => String(n).padStart(2, "0");
    const data = `${p(agora.getDate())}/${p(agora.getMonth() + 1)}/${agora.getFullYear()}`;
    const ss = siglas();
    const com = ss.filter((x) => x.n), sem = ss.filter((x) => !x.n).map((x) => x.s);
    const cont = turno.tickets.filter((t) => t.cont);
    const crit = turno.tickets.filter((t) => t.crit);
    const comStatus = turno.tickets.filter((t) => (t.status || "").trim());
    let s = `> PASSAGEM DE TURNO – NOC\nData: ${data} | Horário: ${P.hhmm(agora)}\nAnalista: ${turno.ultimo || "—"}\n\n`;
    s += `> OTRS – CHAMADOS ABERTOS\n\nTotal: ${ss.length ? com.reduce((a, x) => a + x.n, 0) : "—"}\n\n`;
    if (com.length) s += com.map((x) => `* ${x.s}: ${x.n}`).join("\n") + "\n\n";
    if (sem.length) s += `Demais localidades sem chamados abertos:\n${lista(sem)}\n\n`;
    s += `> CHAMADOS PARA CONTINUIDADE\n\n${cont.length ? cont.map((t) => `Ticket#${t.num} — ${t.titulo}`).join("\n\n") : "Nenhum"}\n\n`;
    s += `> INCIDENTE CRÍTICO EM ABERTO\n\n${crit.length ? crit.map((t) => t.titulo).join("\n") : "Nenhum"}`;
    if (comStatus.length) s += `\n\n>STATUS:\n\n` + comStatus.map((t) => `${t.titulo}: ${t.status.trim()}`).join("\n\n");
    return s;
  }
  function refazer() { editado = false; $("texto").value = texto(); $("hora").textContent = `gerado às ${P.hhmm(Date.now())}`; }
  $("texto").addEventListener("input", () => (editado = true));
  $("b-refaz").onclick = refazer;
  $("b-copiar").onclick = async () => {
    if (!editado) refazer();
    try { await navigator.clipboard.writeText($("texto").value); toast("Copiado. Cole no WhatsApp."); }
    catch (_) { $("texto").select(); document.execCommand("copy"); toast("Copiado"); }
  };

  // ---------- TV ----------
  $("b-tv").onclick = async () => { /* abre/foca a aba do Painel */
    const url = chrome.runtime.getURL("apps/painel/tv.html");
    const t = (await chrome.tabs.query({})).find((x) => (x.url || "").startsWith(url));
    if (t) { chrome.tabs.update(t.id, { active: true }); chrome.windows.update(t.windowId, { focused: true }).catch(() => {}); }
    else chrome.tabs.create({ url });
  };
  $("b-ler").onclick = lerAgora;
  $("b-avisos").onclick = async () => {
    const url = chrome.runtime.getURL("apps/painel/avisos.html");
    const t = (await chrome.tabs.query({})).find((x) => (x.url || "").startsWith(url));
    if (t) { chrome.tabs.update(t.id, { active: true }); chrome.windows.update(t.windowId, { focused: true }).catch(() => {}); }
    else chrome.windows.create({ url, type: "normal" });
  };

  // ---------- Início ----------
  chrome.storage.local.get(["painel_leitura", "painel_turno"], (o) => {
    leitura = o.painel_leitura || null;
    turno = { ...turno, ...(o.painel_turno || {}) };
    desenharAnalistas(); desenharTickets(); mostrarLeitura(); refazer();
  });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === "local" && ch.painel_leitura) { leitura = ch.painel_leitura.newValue || null; mostrarLeitura(); }
  });
  setInterval(mostrarLeitura, 30000);
})();
