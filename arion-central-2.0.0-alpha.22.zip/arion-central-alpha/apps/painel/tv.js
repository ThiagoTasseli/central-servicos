/* tv.js — Painel NOC na TV.
 * Lê painel_leitura/painel_hist (gravados pelo leitor.js na aba do OTRS)
 * e recarrega essa aba a cada N segundos. Só leitura no OTRS.
 */
(() => {
  const P = self.PAINEL;
  const $ = (id) => document.getElementById(id);
  const root = document.documentElement;
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

  let cfg = { tema: "dark", intervalo: 30, tendencia: true };
  let leitura = null, hist = [];
  let timer = null, ultimoReload = 0;

  // ---------- Configuração ----------
  function aplicarCfg() {
    root.setAttribute("data-tv", cfg.tema === "light" ? "light" : "dark");
    root.classList.toggle("sem-tend", !cfg.tendencia);
    $("leg").textContent = cfg.tendencia ? "Linha: últimas 2 horas · Laranja: chegou chamado novo" : "Laranja: chegou chamado novo";
    for (const [id, v] of [["c-tema", cfg.tema], ["c-int", String(cfg.intervalo)], ["c-tend", cfg.tendencia ? "1" : "0"]])
      $(id).querySelectorAll("button").forEach((b) => b.classList.toggle("on", b.dataset.v === v));
    agendar();
  }
  function salvar(mud) {
    cfg = { ...cfg, ...mud };
    chrome.storage.local.set({ painel_cfg: cfg });
    aplicarCfg();
  }

  // ---------- Aba do OTRS ----------
  async function garantirAba() {
    const t = await P.abaKpi();
    if (t) return t;
    return chrome.tabs.create({ url: P.KPI_URL, active: false, pinned: true });
  }
  async function recarregar() {
    try {
      const t = await P.abaKpi();
      if (!t) await garantirAba();
      else chrome.tabs.reload(t.id);
      ultimoReload = Date.now();
    } catch (_) {}
  }
  function agendar() {
    clearInterval(timer);
    timer = setInterval(recarregar, cfg.intervalo * 1000);
  }

  // ---------- Desenho ----------
  function serie(k, n) {
    const pts = hist.map((h) => h.v[k]).filter((v) => typeof v === "number");
    pts.push(n);
    return pts.length > 1 ? pts : [n, n];
  }
  function spark(pts) {
    const w = 110, h = 38, mx = Math.max(1, ...pts);
    const s = pts.map((p, i) => `${(i * w / (pts.length - 1)).toFixed(1)},${(h - 3 - (p / mx) * (h - 8)).toFixed(1)}`).join(" ");
    return `<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true"><polyline points="${s}"/></svg>`;
  }
  function card(g, c) {
    const k = `${g}|${c.rotulo}`;
    const n = c.n == null ? "–" : c.n;
    const r = P.rotulo(c.rotulo);
    const novo = leitura.novos && leitura.novos[k];
    const cls = ["k"];
    if (novo) cls.push("novo");
    else if (/SEM ATUALIZAR/.test(r) && c.n) cls.push("warn");
    else if (/CR[IÍ]TICO/.test(r) && c.n) cls.push("crit");
    if (!c.n) cls.push("z");
    const em = novo ? `<em>chegou ${P.hhmm(novo)}</em>` : "";
    return `<div class="${cls.join(" ")}"><span>${esc(P.nomeTv(c.rotulo))}${em}</span><div class="row"><b>${n}</b>${spark(serie(k, c.n || 0))}</div></div>`;
  }
  function total(cx) {
    return cx.filter((c) => c.tipo !== "gauge").reduce((s, c) => s + (c.n || 0), 0);
  }
  function bloco(re, gid, tid, msg) {
    const g = P.grupo(leitura, re);
    if (!g) { $(gid).innerHTML = `<div class="vazio">${msg}</div>`; $(tid).textContent = "–"; return; }
    const cx = [...g.caixas].sort((a, b) => (a.tipo === "gauge") - (b.tipo === "gauge"));
    $(gid).innerHTML = cx.map((c) => card(g.nome, c)).join("");
    $(tid).textContent = total(g.caixas);
  }
  function desenhar() {
    if (!leitura || !leitura.grupos) {
      const m = "Aguardando o Painel das Filas do OTRS.<br>Confira se o OTRS está logado neste Chrome.";
      $("g-pool").innerHTML = `<div class="vazio">${m}</div>`;
      $("g-cen").innerHTML = "";
      return;
    }
    bloco(/POOL/, "g-pool", "t-pool", "Grupo POOL DE ATENDIMENTO não encontrado no OTRS.");
    bloco(/CENTRAL DE SERV/, "g-cen", "t-cen", "Grupo CENTRAL DE SERVIÇOS não encontrado no OTRS.");
  }

  // ---------- Relógio e queda ----------
  function tique() {
    const agora = Date.now();
    $("clk").textContent = P.hhmm(agora);
    const st = $("st"), txt = $("st-txt"), q = $("queda");
    const limite = Math.max(90, cfg.intervalo * 3) * 1000;
    if (!leitura || !leitura.ts) {
      st.className = "st esp";
      txt.textContent = leitura && leitura.erro === "login" ? "OTRS deslogado neste Chrome" : "Aguardando o OTRS…";
      q.hidden = !(leitura && leitura.erro === "login");
      q.textContent = "OTRS deslogado. Entre no OTRS neste Chrome.";
      return;
    }
    const velho = agora - leitura.ts > limite || (leitura.erro && leitura.tsErro > leitura.ts);
    root.classList.toggle("velho", !!velho);
    st.className = "st" + (velho ? " off" : "");
    txt.textContent = `OTRS ${P.hhmm(leitura.ts, true)} · a cada ${cfg.intervalo} s`;
    q.hidden = !velho;
    if (velho) q.textContent = (leitura.erro === "login" ? "OTRS deslogado · " : "") + `OTRS sem atualizar desde ${P.hhmm(leitura.ts)}`;
  }

  // ---------- Controles ----------
  function abrirCtl(on) {
    $("ctl").hidden = !on;
    if (on) $("c-info").textContent = leitura && leitura.ts ? `Última leitura: ${P.hhmm(leitura.ts, true)}. Última recarga: ${ultimoReload ? P.hhmm(ultimoReload, true) : "—"}.` : "Sem leitura do OTRS ainda.";
  }
  $("b-ctl").onclick = () => abrirCtl(true);
  $("c-fechar").onclick = () => abrirCtl(false);
  $("ctl").addEventListener("click", (e) => { if (e.target.id === "ctl") abrirCtl(false); });
  $("b-tema").onclick = () => salvar({ tema: cfg.tema === "dark" ? "light" : "dark" });
  $("c-tema").onclick = (e) => e.target.dataset.v && salvar({ tema: e.target.dataset.v });
  $("c-int").onclick = (e) => e.target.dataset.v && salvar({ intervalo: +e.target.dataset.v });
  $("c-tend").onclick = (e) => e.target.dataset.v && salvar({ tendencia: e.target.dataset.v === "1" });
  $("c-agora").onclick = () => { recarregar(); abrirCtl(false); };
  $("c-otrs").onclick = async () => { const t = await garantirAba(); chrome.tabs.update(t.id, { active: true }); };
  $("c-cheia").onclick = () => { document.fullscreenElement ? document.exitFullscreen() : root.requestFullscreen().catch(() => {}); abrirCtl(false); };
  document.addEventListener("keydown", (e) => {
    if (e.ctrlKey || e.altKey || e.metaKey) return;
    const k = e.key.toLowerCase();
    if (k === "c") abrirCtl($("ctl").hidden);
    else if (k === "t") salvar({ tema: cfg.tema === "dark" ? "light" : "dark" });
    else if (k === "escape") abrirCtl(false);
    else if (k === "f") $("c-cheia").onclick();
  });

  // ---------- Início ----------
  chrome.storage.local.get(["painel_cfg", "painel_leitura", "painel_hist"], (o) => {
    cfg = { ...cfg, ...(o.painel_cfg || {}) };
    leitura = o.painel_leitura || null;
    hist = o.painel_hist || [];
    aplicarCfg();
    desenhar();
    tique();
    garantirAba().then(() => { if (!leitura || Date.now() - (leitura.ts || 0) > cfg.intervalo * 1000) recarregar(); }).catch(() => {});
  });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== "local") return;
    if (ch.painel_leitura) leitura = ch.painel_leitura.newValue || null;
    if (ch.painel_hist) hist = ch.painel_hist.newValue || [];
    if (ch.painel_cfg && ch.painel_cfg.newValue) { cfg = { ...cfg, ...ch.painel_cfg.newValue }; aplicarCfg(); }
    if (ch.painel_leitura || ch.painel_hist) { desenhar(); tique(); }
  });
  setInterval(tique, 1000);
})();
