/* canva-leitor.js — roda só dentro da Tela de avisos da Central (iframe do Canva).
 * Só LÊ: procura o contador de páginas do visualizador ("1 / 4", "Página 1 de 4")
 * e avisa a Tela de avisos. Não clica e não altera nada no Canva.
 */
(() => {
  if (window.top === window) return;                    // aberto direto numa aba: não faz nada
  let pai = "";
  try { pai = (location.ancestorOrigins && location.ancestorOrigins[0]) || ""; } catch (_) {}
  if (pai && !/^(chrome|moz)-extension:/.test(pai)) return;   // só dentro da Central

  const RE1 = /^\s*(\d{1,3})\s*\/\s*(\d{1,3})\s*$/;
  const RE2 = /(?:p[aá]gina|page|slide)\s*(\d{1,3})\s*(?:de|of)\s*(\d{1,3})/i;
  let ultimo = "";

  function ler() {
    let atual = 0, total = 0;
    const els = document.querySelectorAll("button, span, div, p, [aria-label]");
    for (const el of els) {
      const al = el.getAttribute && el.getAttribute("aria-label");
      let m = al && al.match(RE2);
      if (!m && el.childElementCount === 0) { const t = el.textContent || ""; m = t.length < 20 && (t.match(RE1) || t.match(RE2)); }
      if (m) {
        const a = +m[1], t = +m[2];
        if (t >= 1 && a >= 1 && a <= t && t > total) { atual = a; total = t; }
      }
    }
    const h = parseInt((location.hash || "").replace("#", ""), 10) || 0;
    const msg = { arionCanva: 1, total, atual: atual || h || 1, hash: h };
    const k = JSON.stringify(msg);
    if (k !== ultimo) { ultimo = k; window.parent.postMessage(msg, "*"); }
  }
  setInterval(ler, 1000);
  window.addEventListener("hashchange", ler);
  window.addEventListener("message", (e) => { if (e.data && e.data.arionPing) { ultimo = ""; ler(); } });
})();
